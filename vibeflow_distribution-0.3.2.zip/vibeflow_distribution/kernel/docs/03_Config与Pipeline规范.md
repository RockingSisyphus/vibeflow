# 03. Config 与 Pipeline 规范

配置文件使用 `.jsonc`，支持 `//` 行注释和 `/* ... */` 块注释。不支持 trailing comma。

## 标准结构

```jsonc
{
  "global_config": {},
  "base_lib": {
    "paths": [],
    "modules": []
  },
  "plugins": [],
  "pipeline": {
    "inputs": [],
    "max_steps": 1000,
    "nodes": [],
    "edges": []
  },
  "nodeset_imports": [],
  "policy": {}
}
```

也兼容简写：

```jsonc
{
  "nodes": []
}
```

推荐长期项目使用标准结构。

## 顶层资源声明

`global_config`、`base_lib`、`plugins` 是 config 资源元数据，不是主流程 node。它们不会进入 `GraphConfig.nodes`、execution plan、`effective_edges` 或孤儿节点/可达性等 flow health 检查。Mermaid 会把它们画成独立资源区。

```jsonc
{
  "global_config": {"config": {"tenant": "demo"}, "allow_config_override": false},
  "base_lib": {
    "paths": ["../base_lib"],
    "modules": [
      {
        "module": "base_lib.math_tools",
        "status": "implemented",
        "display_name": "Math Tools",
        "category": "math",
        "description": "Pure arithmetic helpers.",
        "version": "0.1.0"
      },
      {
        "module": "base_lib.future_tools",
        "status": "planned",
        "display_name": "Future Tools",
        "category": "math",
        "description": "planned helper library",
        "version": "0.1.0"
      }
    ]
  },
  "plugins": [
    {
      "module": "../plugins/policy.py",
      "class": "PolicyPlugin",
      "type": "policy",
      "display_name": "Project Policy",
      "category": "policy",
      "description": "Project policy extension used by this config.",
      "version": "0.1.0",
      "config": {"level": "strict"}
    },
    {
      "name": "future_runtime_plugin",
      "type": "runtime",
      "status": "planned",
      "display_name": "Future Runtime Plugin",
      "category": "runtime",
      "description": "planned runtime hook",
      "version": "0.1.0"
    }
  ],
  "pipeline": {"nodes": []}
}
```

- `global_config` 必须是对象。运行时会把实际配置作为 `params["_global"]` 传给每个普通 node。
- `global_config` 中和 node config schema 同名的键会覆盖 node 的实际 params；其他键只通过 `_global` 传递。
- 推荐写成 `{"config": {...}, "allow_config_override": false}`。无论 `allow_config_override` 是否为 `true`，同名键都会覆盖局部 config；当它为 `false` 且发生覆盖时，健康检查给 warning。
- `base_lib.paths` 是相对当前 config 文件的搜索路径。
- `base_lib.modules` 可写字符串简写，等价于 `{"module": "...", "status": "implemented"}`，但会缺少图审查元数据并触发 warning；推荐始终写对象形式。
- `plugins[].config` 和 `plugins[].settings` 都可传插件设置，值必须是对象；插件实例会收到 `plugin.config`，如果实现了 `configure(config)` 会在加载时被调用。
- `plugins[]` 和 `base_lib.modules[]` 的对象形式都应写 `display_name` 和 `description`，可选写 `category` 和 `version`。缺少 plugin/base_lib 可读名或说明会分别产生 `CONFIG.SMELL.MISSING_PLUGIN_*` 或 `CONFIG.SMELL.MISSING_BASE_LIB_*` warning，即使 `PLUGIN_INFO` / `BASE_LIB_INFO` 已完整。
- `status` 只允许 `implemented` 或 `planned`，默认 `implemented`。
- `planned` 资源可以不存在、不会加载、不会执行，只用于规划、inspect 和 Mermaid 展示。
- implemented base_lib 必须提供 `BASE_LIB_INFO`；implemented plugin 必须提供 `PLUGIN_INFO`。

只有顶层 `base_lib.modules` 中声明为 `implemented` 的模块会进入 base_lib allowlist。implemented node 如果导入未声明或只声明为 `planned` 的 base_lib，会被健康检查拒绝。

nodeset 也可以声明自己的 `global_config`。外部 nodeset JSONC 文件的顶层 `global_config` 会作为该文件内 nodeset 的默认内部配置。调用 nodeset 时，调用节点上的 `config` 会覆盖 nodeset 内部 `global_config`，再覆盖内部 node 局部 config；调用节点上的 `allow_config_override` 控制这些覆盖是否产生 warning。

## node 调用

```jsonc
{
  "id": "add",
  "type_used": "demo.add",
  "display_name": "Add Delta",
  "description": "Adds a configured delta to the incoming value.",
  "style": {
    "fill": "#f8fafc",
    "stroke": "#475569",
    "text": "#111827"
  },
  "similar_to": {
    "node": "base_add",
    "relationship": "variant",
    "reason": "Same pure implementation shape, different call-site contract."
  },
  "join_policy": "safe_any",
  "requires": [{"type": "value.in", "cardinality": "exactly_one", "display_name": "Value In"}],
  "provides": [{"key": "value.out", "type": "value.out", "display_name": "Value Out"}],
  "config": {"delta": 3}
}
```

字段说明：

- `id`：本次调用的 node id，在当前 pipeline 内必须唯一。
- `type_used`：本次调用使用的实现类型键，可以是 Python node 的 `NodeInfo.type_key`、独立 nodeset 文件的 `type_key`，或系统类型如 `vibeflow.loop.while`。
- `status`：可选，`implemented` 或 `planned`，默认 `implemented`。
- `flow_kind`：只允许 planned node 使用；implemented node 的 flow_kind 来自 registry 中的 `NODE_INFO`。
- `display_name`：本次调用的易读名，用于 Mermaid/SVG label。调用点没写会产生 `GRAPH.SMELL.MISSING_NODE_DISPLAY_NAME` warning。
- `description`：本次调用的说明，用于 Mermaid/SVG label。调用点没写会产生 `GRAPH.SMELL.MISSING_NODE_DESCRIPTION` warning。
- `style`：可选可视化颜色对象，只允许 `fill`、`stroke`、`text` 三个 `#RRGGBB` hex 颜色。
- `similar_to`：可选相似性声明，表示本调用点是同作用域另一个 node 的 `variant` 或 `copy`；对象内必须写 `node`、`relationship` 和 `reason`。
- `requires`：本次调用按逻辑 `type` 消费的数据，必须写对象并显式声明 `cardinality` 和 `display_name`。
- `provides`：本次调用输出的数据，必须写对象并同时声明唯一 `key`、逻辑 `type` 和 `display_name`。
- `config`：本次调用覆盖注册默认值的配置。
- `node_configs`：调用 nodeset 或 `vibeflow.loop.while` 时，用来覆盖内部 node 配置；loop 路径段会进入该 loop 的 `loop.body`。
- `allow_config_override`：调用 nodeset 时控制同名配置覆盖是否产生 warning；默认 `false`，不阻止实际覆盖。
- `join_policy`：可选调度语义，`safe_any`、`any_active` 或 `all`；默认 `safe_any`，不进入运行时 `params`。
- `async`：可选，`detached` 或 `result_key`；只用于显式后台 side task。
- `result_key`：仅当 `async: "result_key"` 时必填，表示 future 结果写入的唯一 key，且必须在 `provides` 中声明。

`id` 是运行时图中的唯一节点名，不等于实现类型。同一个 `type_used` 可以在同一 pipeline 中调用多次，但每次必须有不同 `id`。输出 `key` 全图唯一；输出 `type` 可以重复，下游按 `type` 消费。

`config` 必须是对象。调用处 config 会覆盖 registry 默认值，但不能出现 registry schema 未声明的字段。

`display_name`、`description`、`style`、`similar_to` 是调用点元数据，不会进入运行时 `params`。如果 node 运行时确实需要同名参数，必须写进 `"config": {...}`。旧调用字段 `name`、`type` 和 `registry_key` 不再接受。

`similar_to.node` 必须指向同一 pipeline 或同一 nodeset 内已存在的 node，不能指向自己；`relationship` 只允许 `variant` 或 `copy`；`reason` 必须非空。它只用于有意重复实现的健康检查豁免：A 指向 B、B 指向 A，或 A/B 共同指向同一个 base 时，会跳过对应 `GRAPH.SMELL.DUPLICATE_LOGIC` pair；未声明覆盖的重复 pair 仍会 warning。这个字段不改变编译、运行、拓扑、契约或 Mermaid 连边。

Mermaid/SVG label 默认以可读性优先，使用纯文本分区展示：节点首行是 `display_name`，缺省时回退到注册类 `NODE_INFO.display_name` 或 `id`；随后显示 `id:`、`type_used:`，nodeset/loop 还会显示 `type_key:` / `body:`，再用 `---------- meta ----------`、`---------- status ----------`、`---------- nodeset ----------` 等分区展示说明。`requires/provides` 不再塞进节点内；数据契约显示在连边 label 上，先显示 contract `display_name`，再显示 id/key/type 信息。长说明会确定性换行并在必要时截断。SVG 渲染使用更大的 node spacing、rank spacing、wrapping width 和 diagram padding，并在保持 `htmlLabels=false` 的前提下增强原生 SVG 文本：标题加粗、字段名前缀加粗、字段行左对齐、分区行加粗弱化。普通图和展开审查图都按可读优先生成。

自定义 `style` 会作为节点级样式覆盖系统 class 的 fill/stroke/text 颜色，包括 health error/warning、planned node、document、nodeset、loop、external dependency 等节点；节点形状、finding 注释和 planned 虚线等非颜色语义仍保留。自定义色仍不能使用 VibeFlow 系统保留色。

系统颜色是保留语义色，不能作为自定义 `style.fill`、`style.stroke` 或 `style.text` 使用；大小写不敏感。使用时 schema 会报 `CONFIG.SCHEMA.NODE_STYLE_RESERVED_COLOR`。

| 系统样式 | fill | stroke | text |
| --- | --- | --- | --- |
| 普通 node `defaultNode` | `#ECECFF` | `#9370DB` | `#333333` |
| planned node / planned resource | `#fef08a` | `#ca8a04` | `#713f12` |
| plugin resource | `#eff6ff` | `#2563eb` | `#1e3a8a` |
| base_lib resource | `#ecfdf5` | `#059669` | `#064e3b` |
| health error | `#fee2e2` | `#dc2626` | `#7f1d1d` |
| health warning | `#fef3c7` | `#d97706` | `#78350f` |
| external dependency | `#e0f2fe` | `#0284c7` | `#0c4a6e` |
| document node | `#f0fdf4` | `#16a34a` | `#14532d` |
| nodeset node | `#ede9fe` | `#7c3aed` | `#3b0764` |

## 严格 key/type 与 inbox 数据流

旧字符串形式不再支持：

```jsonc
"requires": ["value.in"],
"provides": ["value.out"],
"inputs": ["value.in"]
```

必须写成：

```jsonc
"inputs": [{"key": "value.in", "type": "value.in", "display_name": "Value In"}],
"outputs": [{"type": "value.out", "cardinality": "exactly_one", "display_name": "Value Out"}],
"requires": [{"type": "value.in", "cardinality": "exactly_one", "display_name": "Value In"}],
"provides": [{"key": "value.out", "type": "value.out", "display_name": "Value Out"}]
```

- `key` 是唯一数据地址，用于 node 返回 mapping、trace、调试和来源记录。
- `type` 是逻辑数据类型，可以重复，用于表达多个互斥分支产出同一种逻辑结果。
- `cardinality` 只允许 `exactly_one`、`optional_one`、`all`。
- runtime 使用 node inbox / edge payload。node 只能收到直接 incoming edge 投递的数据，不会跨多跳从全局 Context 读取早期输出。
- node 收到 envelope：`inputs["value.in"]["value"]` 是业务值，`inputs["value.in"]["key"]` 是实际来源 key。
- `pipeline.outputs` 决定最终 run result 保留哪些 envelope；未声明的中间值会释放。

## terminal start/end

每个可执行 pipeline 和 nodeset 内部 pipeline 都应有 terminal start/end：

```jsonc
{
  "pipeline": {
    "inputs": [{"key": "value.in", "type": "value.in"}],
    "outputs": [{"type": "value.out", "cardinality": "exactly_one"}],
    "nodes": [
      {"id": "start", "type_used": "demo.start", "display_name": "Start", "description": "Starts the demo pipeline."},
      {"id": "input", "type_used": "demo.input", "display_name": "Read Input", "description": "Reads the incoming value.", "requires": [{"type": "value.in", "cardinality": "exactly_one", "display_name": "Value In"}], "provides": [{"key": "value.in.input", "type": "value.in", "display_name": "Value In"}]},
      {"id": "add", "type_used": "demo.add", "display_name": "Add Delta", "description": "Adds a configured delta.", "requires": [{"type": "value.in", "cardinality": "exactly_one", "display_name": "Value In"}], "provides": [{"key": "value.out", "type": "value.out", "display_name": "Value Out"}]},
      {"id": "end", "type_used": "demo.end", "display_name": "End", "description": "Consumes the final output.", "requires": [{"type": "value.out", "cardinality": "exactly_one", "display_name": "Value Out"}]}
    ],
    "edges": [["start", "input"], ["input", "add"], ["add", "end"]]
  }
}
```

`io` 不是 start/end。推荐结构是：

```text
terminal start -> io input -> process... -> io output -> terminal end
```

## edge

二元数组形式：

```jsonc
["seed", "add"]
```

对象形式：

```jsonc
{"from": "route", "to": "retry", "when": "flow.route == 'again'"}
```

规则：

- `pipeline.edges` 是唯一控制流来源。
- `requires/provides` 不会自动推导控制流或诊断边；没有显式 edge，就没有图上的边。图上只会在已有连边上标出能匹配到的 contract。
- `when` 只支持小表达式：`key == 'value'`、`key != 'value'`、`flag == true`、`flag == false`。字符串可以用单引号或双引号；布尔值必须小写 `true` / `false`。
- 从 `decision` 出发的 edge 必须写 `when`。

edge 只能连接当前 pipeline 内已经声明的 node。对象形式也兼容 `source` / `target` 字段名：

```jsonc
{"source": "route", "target": "end", "when": "flow.route == 'done'"}
```

## nodeset 导入与引用解析

nodeset 必须放在独立 JSONC 文件中，根对象使用 `type_key` 定义实现类型键。主 config 和 nodeset 文件通过 `nodeset_imports` 导入其他 nodeset 文件：

```jsonc
{
  "nodeset_imports": [{"path": "nodesets/demo_add_one.jsonc"}]
}
```

不再支持主 config 内联 `nodesets: [...]`，也不再支持 `nodeset_imports[].names`。每个导入文件只定义一个 nodeset；如果需要多个 nodeset，就拆成多个文件。

VibeFlow 会先为所有导入的 nodeset 建立符号表，再解析各 nodeset 的内部 pipeline。因此调用点 `type_used` 和 `vibeflow.loop.while.loop.body` 都直接引用 nodeset `type_key`，不需要 `nodeset.` 前缀，也不依赖声明顺序。

nodeset 调用和 `loop.body` 都构成 nodeset dependency。直接或间接递归会报 `NODESET.RECURSION`；不要用 nodeset 互相调用或 loop body 自引用来表达循环，真实循环只能由 `vibeflow.loop.while` 这个节点的执行语义承担。

大型项目应放心按 `NODESET.SMELL.TOO_WIDE` 建议拆成更多小 nodeset。parser 按符号表解析每个 nodeset 一次，不依赖前缀重解析；如果怀疑配置读取或解析慢，可临时运行：

```bash
VIBEFLOW_CONFIG_TRACE=1 python run.py validate --config project/configs/main.jsonc
```

trace 会输出 import 文件、展开后的 nodeset 数、每个 nodeset 解析耗时、引用到的 nodeset 和总耗时。

## cycle

普通 `pipeline.edges` 和 nodeset 内部 `pipeline.edges` 不允许形成环。旧 `pipeline.loops` 已移除，显式 edge 回环也会被 `GRAPH.CYCLE.FORBIDDEN` 拒绝；需要循环时使用 `vibeflow.loop.while`。

`decision` 只负责分支选择，例如：

```jsonc
{
  "pipeline": {
    "inputs": [{"key": "value.in", "type": "value.in", "display_name": "Value In"}],
    "outputs": [{"type": "value.out", "cardinality": "exactly_one", "display_name": "Value Out"}],
    "max_steps": 1000,
    "nodes": [
      {"id": "start", "type_used": "demo.start", "display_name": "Start", "description": "Starts the branch example."},
      {
        "id": "work",
        "type_used": "demo.work",
        "display_name": "Work",
        "description": "Produces a value before routing.",
        "requires": [{"type": "value.in", "cardinality": "exactly_one", "display_name": "Value In"}],
        "provides": [{"key": "value.out", "type": "value.out", "display_name": "Value Out"}]
      },
      {
        "id": "route",
        "type_used": "demo.route",
        "display_name": "Route",
        "description": "Chooses the branch.",
        "requires": [{"type": "value.out", "cardinality": "exactly_one", "display_name": "Value Out"}],
        "provides": [{"key": "flow.route", "type": "flow.route", "display_name": "Route"}]
      },
      {"id": "left", "type_used": "demo.left", "display_name": "Left", "description": "Handles the left branch.", "requires": [{"type": "value.out", "cardinality": "exactly_one", "display_name": "Value Out"}]},
      {"id": "end", "type_used": "demo.end", "display_name": "End", "description": "Consumes the branch result.", "requires": [{"type": "value.out", "cardinality": "exactly_one", "display_name": "Value Out"}]}
    ],
    "edges": [
      ["start", "work"],
      ["work", "route"],
      {"from": "route", "to": "left", "when": "flow.route == 'left'"},
      {"from": "left", "to": "end"},
      {"from": "route", "to": "end", "when": "flow.route == 'done'"}
    ]
  }
}
```

`max_steps` 是运行时防护，不是架构语义。普通 `pipeline.edges` / nodeset 内部 `pipeline.edges` 不允许形成环；出现环会报 `GRAPH.CYCLE.FORBIDDEN`。

`decision` 只负责分支选择，不再承担 retry / again / done 循环语义。训练循环、批处理循环和 retry-until 循环都应使用一等 loop node。

## Mainline Analysis 与显式 edge 语义

只有用户写在 `pipeline.edges` 中的 edge 才是图结构。`requires/provides` 只用于校验和解释这些显式 edge，不会自动生成控制流、诊断 data edge 或 Mermaid/SVG 边。某个上游 provider 和下游 requirement 类型匹配，但用户没有写 edge，核心会认为这条图边不存在。

Health 会在显式 edge 中推断三类边：

- `mainline`：同步主线边，负责调度。Mermaid/SVG 中加粗。
- `data_bypass`：显式旁路数据边，source 和 target 已经由同步主线连接；只投递数据，不触发 target。Mermaid/SVG 中虚线。
- `async`：连接到 `async: "detached"` 或 `async: "result_key"` node / nodeset 调用的边；不进入同步主线。

普通同步节点应处于从 start 到 end 的主线或 decision 主线变体中。非 decision 同步 fan-out 只有在分支通过 `join_policy: "all"` 明确汇合、被识别为 data bypass，或分支目标显式 async 时才是合法语义。否则会产生：

- `GRAPH.MAINLINE.UNDECLARED_SYNC_FANOUT`
- `GRAPH.MAINLINE.AMBIGUOUS_SIDE_BRANCH`
- `GRAPH.MAINLINE.DATA_BYPASS_WITHOUT_MAINLINE_TRIGGER`
- `GRAPH.MAINLINE.DECISION_BRANCH_DEAD_END`

这些 finding 的 `details` 会包含 `owner`、`source`、`target`、`edge`、尝试分类、`mainline_path` / `mainline_variant`、`branch_nodes`、`branch_edges`、`async_nodes_seen`、`why_invalid` 和 `suggested_fixes`。按这些字段修改配置：删除无用边、把旁路节点或 nodeset 调用标成 async、把分支串回主线，或给真正的同步汇合 node 写 `join_policy: "all"`。

## 一等 loop node

系统 loop node 是运行时能力，不需要在 registry 中注册：

- `vibeflow.loop.while`：重复执行一个 nodeset body，直到固定轮数到达，或 body/state 输出的 bool 条件满足。

loop node 像普通 node 一样声明 `requires/provides`，并额外写顶层 `loop` 对象。`loop` 不进入运行时 `params`；如果业务 node 真需要同名参数，必须写到 `config`。body 必须指向同一 config 或已导入的 nodeset，可引用后面才声明的 nodeset；展开 SVG 时 loop body 会像 nodeset 一样展开。

```jsonc
{
  "id": "train_loop",
  "type_used": "vibeflow.loop.while",
  "display_name": "Training Loop",
  "description": "Runs a training body until it reports completion.",
  "requires": [
    {"type": "train.model", "cardinality": "exactly_one", "display_name": "Model"},
    {"type": "train.optimizer", "cardinality": "exactly_one", "display_name": "Optimizer"}
  ],
  "provides": [
    {"key": "train.model_after", "type": "train.model_after", "display_name": "Updated Model"},
    {"key": "train.loss_history", "type": "train.loss_history", "display_name": "Loss History"},
    {"key": "loop.iterations", "type": "loop.iterations", "display_name": "Loop Iterations"}
  ],
  "loop": {
    "body": "training.batch_step",
    "max_iterations": 1000,
    "stop_when": {"from": "loop.done", "equals": true},
    "carry": [
      {"from": "train.model", "as": "train.model", "update": "train.model_after"},
      {"from": "train.optimizer", "as": "train.optimizer", "update": "train.optimizer_after"}
    ],
    "collect": [{"from": "train.loss", "as": "train.loss_history"}],
    "outputs": [
      {"from": "train.model_after", "as": "train.model_after"},
      {"from": "train.loss_history", "as": "train.loss_history"},
      {"from": "loop.iterations", "as": "loop.iterations"}
    ]
  }
}
```

`carry` 把上一轮 body output 写回下一轮 body input；`collect` 把每轮 body output 追加成 list；`outputs` 决定 loop node 最终返回哪些 key。batch/epoch/遍历语义不要写成 `items` 或 `epochs`，而是在 body nodeset 内用 index/counter/batch selector 节点表达，并通过 `carry` 写回下一轮状态。

退出条件必须二选一：

- `stop_after`：固定执行 N 轮，必须是 `>= 1` 的整数，且不能大于 `max_iterations`。
- `stop_when`：从 body output 或 loop state 读取 bool，例如 `{"from": "loop.done", "equals": true}`；缺失或非 bool 会在运行时报明确错误。

固定轮数循环：

```jsonc
"loop": {
  "body": "loop.retry_step",
  "max_iterations": 10,
  "stop_after": 3,
  "carry": [{"from": "loop.current", "as": "loop.current", "update": "loop.next"}]
}
```

条件循环：

```jsonc
"loop": {
  "body": "loop.retry_step",
  "max_iterations": 10,
  "stop_when": {"from": "loop.done", "equals": true},
  "carry": [{"from": "loop.current", "as": "loop.current", "update": "loop.next"}],
  "outputs": [{"from": "loop.next", "as": "loop.next"}]
}
```

`vibeflow.loop.for_each`、`loop.items`、`loop.epochs`、`loop.until` 已移除。`max_iterations` 是 loop 的硬上限，超过会抛 runtime error。顶层 `runtime.step_count` 仍只统计顶层 node；包含 loop body 的总步数看 `runtime.total_step_count`，完整顺序看 `runtime.qualified_exec_order`。

`execution="block"` 和 `execution="compiled"` 会执行结构化 `LoopBlock`。如果 loop body 不能被 block compiler 编译，block/compiled 模式会报错，不会静默降级到普通 nested runtime。普通 execution 仍保留同语义的 nested runtime 兼容路径。

Mermaid/SVG 中 while loop 使用独立 trapezoid (`trap-b`) 形状和默认 `loopNode` 系统样式，label 会显示 `body:`、`stop:`、`max:`。`loopNode` 默认颜色属于系统保留色，不允许作为自定义 `style` 颜色；如需改 loop 颜色，应写其他非保留 hex 色。

## join_policy 与 safe OR join

默认 join 语义是 safe OR：目标 node 只要本轮 active incoming branch 提供了所需输入即可运行，但不会静默选择含糊输入。

- `join_policy: "safe_any"`：默认值。适合互斥分支汇入同一个消费 node；如果某条 conditional incoming 只是控制门、不提供目标所需数据，runtime 会等待该条件边激活，避免未选中分支提前运行。
- `join_policy: "any_active"`：显式 OR join。只有确认任一 active incoming 都足够触发目标时使用。
- `join_policy: "all"`：等待所有 incoming edge 在本轮都激活后才调度目标。

安全规则：

- 同一 `exactly_one` requirement 收到多个 active provider 时，runtime 报错。
- conditional provider 和 unconditional provider 同时可能满足同一 requirement 时，health 报 `GRAPH.JOIN.AMBIGUOUS_UNCONDITIONAL`。通常应改成显式 merge/select node、互斥分支，或 `join_policy: "all"`。
- 每次调度只消费本轮 edge activation 送进 inbox 的输入；不要依赖旧输出留在全局 context 触发后续 join。

## planned node

可用 planned node 先登记架构：

```jsonc
{
  "id": "classify",
  "status": "planned",
  "display_name": "Classify",
  "description": "Planned classifier branch.",
  "flow_kind": "decision"
}
```

planned 内容会在健康检查中给 warning；runtime 默认拒绝执行。只有 `planned_behavior.kind == "python_stub"` 且显式加 `--allow-planned-stub` 时，才可作为开发测试 stub 执行。

planned node 可以暂时不写 `type_used`，此时内核会用 `planned.<id>` 作为占位类型。planned node 必须写 `id`、`display_name`、`description` 和 `flow_kind`，因为图形审查需要知道它的流程图形状。implemented node 不能在 config 里写 `flow_kind`，必须来自 `NODE_INFO`。

planned node / planned nodeset 可选 `planned_behavior`：

```jsonc
{"planned_behavior": "blocking"}
{"planned_behavior": "transparent"}
{"planned_behavior": {"kind": "python_stub", "stub_module": "project/stubs/runtime_control_stub.py"}}
```

- 默认 `blocking`：保持传统 planned 行为，不参与主流程健康检查的连通性判断。
- `transparent`：仍产生 planned warning，但参与 start/end、reachability、orphan 等 flow health，适合设计期连接前后 implemented 节点。
- `python_stub`：仍产生 planned warning，并额外产生 `GRAPH.PLANNED.PYTHON_STUB_DEV_ONLY`；参与 flow health。只有运行命令显式加 `--allow-planned-stub` 时才可执行。
- `blocking` 和 `transparent` 永远不可执行；含 planned/python_stub 的配置不能视为 production ready。
- `stub_module` 必须是主项目相对路径，且落在 `project/stubs/*.py`。stub 文件必须暴露 `run_stub(inputs, params)`，不能做文件、网络、进程、线程、动态 import 等高风险操作。
- `run_stub` 只收到该节点声明的 `requires` 输入和合并后的 params；返回值必须是 mapping，key 必须严格等于该节点 `provides`。
- planned nodeset 若使用 `python_stub`，会按单个 stub 节点执行，不展开内部 pipeline；调用节点的 `requires/provides` 必须与 nodeset 声明匹配。

## async node

异步是显式配置能力，不会自动并行普通节点：

```jsonc
{
  "id": "metrics",
  "type_used": "demo.metrics",
  "display_name": "Metrics",
  "description": "Runs a detached metrics side task.",
  "async": "detached",
  "requires": [{"type": "batch", "cardinality": "exactly_one", "display_name": "Batch"}],
  "provides": [{"key": "metrics", "type": "metrics", "display_name": "Metrics"}]
}
{
  "id": "load",
  "type_used": "demo.load",
  "display_name": "Load",
  "description": "Runs an async load that produces a joinable result.",
  "async": "result_key",
  "result_key": "data.batch",
  "provides": [{"key": "data.batch", "type": "data.batch", "display_name": "Batch"}]
}
```

- `detached`：主流程不等待，run 结束时 flush；失败记录 trace warning，不默认中断主流程。
- `result_key`：下游直接 edge 上的节点按 `type` require 该异步结果时 join，结果写入 `result_key` 对应的 provider key。
- runtime 不自动 merge async context；共享对象的线程安全由业务对象负责。
- 复杂后台工作可以通过 `type_used` 调用 nodeset `type_key`，并在该调用点设置 `async`；nodeset 内部仍按自己的显式 edges 和契约运行。

CLI 中 `--runtime-profile train` 会自动启用偏训练场景的选项：`trace="boundary"`、`execution="compiled"`、run/block hooks 开启、node/nodeset hooks 关闭、async flush timeout 为 30 秒。`--runtime-profile debug` 会启用完整 trace 和所有 hook。

诊断 trace 保留兼容字段和嵌套字段两套视图：`runtime.exec_order`、`runtime.node_runs`、`runtime.edge_executions`、`runtime.step_count` 仍只描述顶层 pipeline；嵌套 nodeset/loop 的完整顺序看 `runtime.qualified_exec_order`、`runtime.qualified_node_runs`、`runtime.qualified_edge_executions` 和 `runtime.total_step_count`。完整事件流只写入 `runtime_trace.jsonl`，`RunResult.runtime.*` 和 runtime hook 的 `trace` 参数只包含 summary、`event_count`、`trace_path` 和 `events_streamed=true`，不包含 `events` 列表。每个 trace event 都带 `path` 数组、`qualified_node` 和 `depth`，例如 `["outer_call", "inner_call", "add"]` / `outer_call.inner_call.add`。机器读取应优先用 `path`，不要解析 dotted 字符串。

## 已移除字段

这些字段出现时会失败：

- `boundary`
- `pipeline.loops`
- edge `max_executions`
- edge `loop`
- pipeline/edge 级 `max_iterations`；loop 使用 `loop.max_iterations`
- node 调用字段 `name` / `type` / `registry_key`；改用 `id` / `type_used`
- 主 config 或 nodeset 文件中的内联 `nodesets`
- `nodeset_imports[].names`
- nodeset 字段 `name` / `category` / `version` / `purity` / `exports`
- nodeset 调用前缀 `nodeset.`；调用处直接把 nodeset `type_key` 写进 `type_used`

## policy

项目目录可放 `kernel_policy.jsonc` 或 `governance.jsonc`。也可以在 config 中写内联 `policy`，内联优先级最高。

```jsonc
{
  "policy": {
    "node_source": {
      "max_lines": 500,
      "max_bytes": 60000,
      "warn_lines": 450,
      "warn_bytes": 54000
    }
  }
}
```

通常不要放宽硬规则。确实需要临时放宽时，应写明 reason 和 expires。

policy 来源优先级：

1. 默认内核 policy。
2. config 文件同目录的 `kernel_policy.jsonc` 或 `governance.jsonc`。
3. 命令行 `--policy` 指定的文件。
4. config 内联 `policy`。
5. policy plugin 返回的 policy 更新。

后面的来源会覆盖或追加前面的设置。`rules.downgrades` 和 `rules.exemptions` 是追加列表，其他对象字段按深度合并。

## 常见拓扑问题

- `GRAPH.FLOW.MISSING_START`：没有 terminal start，或 start 有 incoming edge。
- `GRAPH.FLOW.MISSING_END`：没有 terminal end，或 end 有 outgoing edge。
- `GRAPH.FLOW.UNREACHABLE_FROM_START`：某个 implemented node 从 start 走不到。
- `GRAPH.FLOW.CANNOT_REACH_END`：某个 implemented node 不能到达 end。
- `GRAPH.DECISION.MISSING_BRANCH_VALUE`：decision 的 `output_schema` 声明了 enum/boolean 分支，但 edge 没覆盖。
- `GRAPH.CYCLE.FORBIDDEN`：普通 graph 中出现显式 edge 环；请改用 `vibeflow.loop.while`。
- `GRAPH.MAINLINE.UNDECLARED_SYNC_FANOUT`：非 decision 同步节点分出多条同步主线，但没有 data bypass、async 或 `join_policy: "all"` 汇合语义；看 `details.branch_nodes` / `branch_edges` 修改。
- `GRAPH.MAINLINE.AMBIGUOUS_SIDE_BRANCH`：某个同步旁路不在任何主线变体中；通常应接回主线、删除，或把它标成 async。
- `GRAPH.MAINLINE.DATA_BYPASS_WITHOUT_MAINLINE_TRIGGER`：一条旁路数据边的 target 没有独立主线触发；补主线 edge 或删除该旁路。
- `GRAPH.MAINLINE.DECISION_BRANCH_DEAD_END`：decision 的某个 `when` 分支不能到达 terminal end 或合法汇合；看 `details.edge.when` 和 `details.branch_nodes`。
- `GRAPH.DATA.MISSING_DIRECT_PROVIDER`：某个 require `type` 没有直接 incoming flow predecessor 或入口输入提供；检查 edge、`pipeline.inputs` 或中间 pass-through node。
- `GRAPH.DATA.TYPE_CARDINALITY_AMBIGUOUS`：某个 require `type` 的直接来源数量可能违反 `exactly_one` / `optional_one`。
- `GRAPH.DATA.UNCONSUMED_PROVIDER`：某个 provider `key/type` 没有直接下游消费；如果是预期最终产物，确保 `pipeline.outputs` 声明它，且必要时由 end/io/document 节点消费。
- `GRAPH.SMELL.DUPLICATE_LOGIC`：两个 config node 的 `run_pure` fingerprint 相同；报告 `details` 会列出具体 nodes、node_types、fingerprint、duplicate_group 和 `similar_to` 豁免提示。

所有健康 finding 都应先看 `object_id` 和 `details`。flow/data finding 的 `details.owner` 会标明顶层 `pipeline` 或 `nodeset:<name>`，并尽量列出 incoming/outgoing edge、direct sources、available provider types、entry input types 或 downstream required types，按这些对象修改配置。mainline finding 会给出 `source` / `target`、`branch_nodes`、`branch_edges`、`mainline_path` 和 `suggested_fixes`。如果 `details.aggregated == true`，说明同一个根因在 nested nodeset / loop body 静态展开中被重复发现并压缩；`occurrences` 是重复展开次数，不是独立 bug 数。
