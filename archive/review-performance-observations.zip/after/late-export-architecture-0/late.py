from pathlib import Path
Path(__file__).with_name('late.marker').write_text('imported')
class Late:
    def run_pure(self, inputs, params):
        return {}
