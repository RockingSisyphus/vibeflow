class Shared:
    def run_pure(self, inputs, params):
        print("shared output")
        return {}
