from pathlib import Path
from vibeflow.targets.python.sdk import Plugin, node, rule, ruleset, SourceLocator
from vibeflow.core.findings import HealthFinding
from vibeflow.core.rules import RuleRecord, RuleResult

def finding(context, code, message, severity="warning"):
    return HealthFinding(rule_id=code, severity=severity, object_type="node",
        object_id=context.subject["type_key"], message=message,
        source_location={"path": __file__, "line": 8, "column": 1})

@node(type_key="case.start", flow_kind="terminal", contract={}, rulesets=[])
class Start:
    def run_pure(self, inputs, params):
        return {}

@node(type_key="case.end", flow_kind="terminal", contract={}, rulesets=[])
class End:
    def run_pure(self, inputs, params):
        return {}

allowed = ruleset(id="case.allowed", calls=[{"id":"effect", "rule_id":"vibeflow.no_side_effects", "params":{"effect_scope":"terminal"}}], entrypoints={"static":["effect"]})
restricted = ruleset(id="case.restricted", calls=[{"id":"effect", "rule_id":"vibeflow.no_side_effects", "params":{"effect_scope":"none"}}], entrypoints={"static":["effect"]})
shared = SourceLocator("file", str(Path(__file__).with_name("shared.py")), "Shared")
wide = node(type_key="case.wide", contract={}, source=shared, rulesets=["case.allowed"])
narrow = node(type_key="case.narrow", contract={}, source=shared, rulesets=["case.restricted"])
plugin = Plugin(id="case.resources", resources=[Start, End, wide, narrow, allowed, restricted], declaration_rulesets=[])
