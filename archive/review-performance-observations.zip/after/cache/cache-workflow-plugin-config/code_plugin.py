from pathlib import Path
from vibeflow.targets.python.sdk import Plugin, node, rule, ruleset, SourceLocator
from vibeflow.core.findings import HealthFinding
from vibeflow.core.rules import RuleRecord, RuleResult

def finding(context, code, message, severity="warning"):
    return HealthFinding(rule_id=code, severity=severity, object_type="node",
        object_id=context.subject["type_key"], message=message,
        source_location={"path": __file__, "line": 8, "column": 1})

@node(type_key="case.start", flow_kind="terminal", contract={}, rulesets=[])
class Start:
    def run_pure(self, inputs, params):
        return {}

@node(type_key="case.end", flow_kind="terminal", contract={}, rulesets=[])
class End:
    def run_pure(self, inputs, params):
        return {}

@rule(id="case.config", scope="source")
def check_config(context, inputs, params):
    value = context.facts["plugins"]["case.resources"]["mode"]
    return RuleResult(findings=(finding(context, "CASE.CONFIG", f"mode {value}"),))
checks = ruleset(id="case.config", calls=[{"id":"check", "rule_id":"case.config"}], entrypoints={"static":["check"]})

@node(type_key="case.step", contract={}, rulesets=['case.config'])
class Step:
    def run_pure(self, inputs, params):
        return {}

plugin = Plugin(id="case.resources", resources=[Start, End, Step, check_config, checks],
    config_defaults={"mode": 1}, declaration_rulesets=[])
