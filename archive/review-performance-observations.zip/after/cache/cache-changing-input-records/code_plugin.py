from pathlib import Path
from vibeflow.targets.python.sdk import Plugin, node, rule, ruleset, SourceLocator
from vibeflow.core.findings import HealthFinding
from vibeflow.core.rules import RuleRecord, RuleResult

def finding(context, code, message, severity="warning"):
    return HealthFinding(rule_id=code, severity=severity, object_type="node",
        object_id=context.subject["type_key"], message=message,
        source_location={"path": __file__, "line": 8, "column": 1})

@node(type_key="case.start", flow_kind="terminal", contract={}, rulesets=[])
class Start:
    def run_pure(self, inputs, params):
        return {}

@node(type_key="case.end", flow_kind="terminal", contract={}, rulesets=[])
class End:
    def run_pure(self, inputs, params):
        return {}

@rule(id="case.changing_provider", scope="call", outputs={"data":"case.data.v1"})
def provide(context, inputs, params):
    value = context.require("call").params["record"]
    return RuleResult(records={"data":RuleRecord("case.data.v1", {"value":value})})
@rule(id="case.source_consumer", scope="source", inputs={"data":"case.data.v1"})
def consume(context, inputs, params):
    value = inputs["data"].value["value"]
    with Path(__file__).with_name("consumer.marker").open("a") as stream:
        stream.write(str(value) + "\n")
    return RuleResult(findings=(finding(context, "CASE.CHANGING_RECORD", f"consumed {value}"),))
checks = ruleset(id="case.changing_records", calls=[
    {"id":"provide", "rule_id":"case.changing_provider"}, {"id":"consume", "rule_id":"case.source_consumer"}],
    relations=[{"source":"consume", "target":"provide", "kind":"requires", "bindings":{"data":"data"}}],
    entrypoints={"static":["consume"]})

@node(type_key="case.step", contract={"params_schema":{"record":{"type":"integer"}},"params_defaults":{"record":0}}, rulesets=['case.changing_records'])
class Step:
    def run_pure(self, inputs, params):
        return {}

plugin = Plugin(id="case.resources", resources=[Start, End, Step, provide, consume, checks],
    config_defaults={"mode": 1}, declaration_rulesets=[])
