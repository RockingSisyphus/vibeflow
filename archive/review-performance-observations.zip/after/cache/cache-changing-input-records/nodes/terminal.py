from vibeflow.targets.python.sdk import node
@node(type_key='perf.start', flow_kind='terminal', contract={}, rulesets=['vibeflow.io'])
class Start:
    def run_pure(self, inputs, params):
        return {}
@node(type_key='perf.end', flow_kind='terminal', contract={}, rulesets=['vibeflow.io'])
class End:
    def run_pure(self, inputs, params):
        return {}
