from pathlib import Path
from vibeflow.targets.python.sdk import Plugin, node, rule, ruleset, SourceLocator
from vibeflow.core.findings import HealthFinding
from vibeflow.core.rules import RuleRecord, RuleResult

def finding(context, code, message, severity="warning"):
    return HealthFinding(rule_id=code, severity=severity, object_type="node",
        object_id=context.subject["type_key"], message=message,
        source_location={"path": __file__, "line": 8, "column": 1})

@node(type_key="case.start", flow_kind="terminal", contract={}, rulesets=[])
class Start:
    def run_pure(self, inputs, params):
        return {}

@node(type_key="case.end", flow_kind="terminal", contract={}, rulesets=[])
class End:
    def run_pure(self, inputs, params):
        return {}

from dataclasses import make_dataclass
First = make_dataclass("Payload", [("value",int)], frozen=True)
Second = make_dataclass("Payload", [("value",int)], frozen=True)
@rule(id="case.native_provider", scope="call", outputs={"data":"case.data.v1"})
def provide(context, inputs, params):
    kind = context.require("call").params["record_kind"]
    if 'dataclass' == "dataclass":
        value = First(7) if kind == "first" else Second(7) if kind == "second" else {"value":7}
    else:
        value = [7] if kind == "tuple" else frozenset({7})
    return RuleResult(records={"data":RuleRecord("case.data.v1",value)})
@rule(id="case.native_consumer", scope="source", inputs={"data":"case.data.v1"})
def consume(context, inputs, params):
    value = inputs["data"].value
    label = "first" if type(value) is First else "second" if type(value) is Second else "tuple" if type(value) is tuple else "frozenset" if type(value) is frozenset else "mapping"
    with Path(__file__).with_name("consumer.marker").open("a") as stream:
        stream.write(label + "\n")
    return RuleResult(findings=(finding(context,"CASE.NATIVE_RECORD","same warning"),))
checks = ruleset(id="case.native_records", calls=[
    {"id":"provide","rule_id":"case.native_provider"},{"id":"consume","rule_id":"case.native_consumer"}],
    relations=[{"source":"consume","target":"provide","kind":"requires","bindings":{"data":"data"}}],
    entrypoints={"static":["consume"]})

@node(type_key="case.step", contract={"params_schema":{"record_kind":{"type":"string"}},"params_defaults":{"record_kind":"mapping"}}, rulesets=['case.native_records'])
class Step:
    def run_pure(self, inputs, params):
        return {}

plugin = Plugin(id="case.resources", resources=[Start, End, Step, provide, consume, checks],
    config_defaults={"mode": 1}, declaration_rulesets=[])
