from vibeflow.targets.python.sdk import Plugin
from base_lib.lib0 import calculate0
from base_lib.lib1 import calculate1
from base_lib.lib2 import calculate2
from base_lib.lib3 import calculate3
from base_lib.lib4 import calculate4
from base_lib.lib5 import calculate5
from base_lib.lib6 import calculate6
from base_lib.lib7 import calculate7
from nodes.group0 import Step0, Step1, Step2, Step3, Step4, Step5, Step6, Step7
from nodes.terminal import Start, End
from vibeflow.targets.python.sdk import rule, ruleset
@rule(id='perf.call', scope='call')
def count_call(context, inputs, params):
    return {'state':'completed','records':{},'findings':[]}
call_rules = ruleset(id='perf.calls', calls=[{'id':'check','rule_id':'perf.call'}], entrypoints={'static':['check']})
plugin = Plugin(id='perf.resources', resources=[calculate0, calculate1, calculate2, calculate3, calculate4, calculate5, calculate6, calculate7, Start, End, Step0, Step1, Step2, Step3, Step4, Step5, Step6, Step7, count_call, call_rules],
                declaration_rulesets=['vibeflow.plugin_declaration'])
