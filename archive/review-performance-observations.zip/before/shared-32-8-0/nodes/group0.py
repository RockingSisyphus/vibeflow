from vibeflow.targets.python.sdk import node
from base_lib.lib0 import calculate0
from base_lib.lib1 import calculate1
from base_lib.lib2 import calculate2
from base_lib.lib3 import calculate3
from base_lib.lib4 import calculate4
from base_lib.lib5 import calculate5
from base_lib.lib6 import calculate6
from base_lib.lib7 import calculate7
@node(type_key='perf.step.0', contract={'provides': [{'key': 'value0', 'type': 'number', 'display_name': 'Value 0'}], 'output_semantics': {'value0': ['The computed value of step 0.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3', 'perf.library.4', 'perf.library.5', 'perf.library.6', 'perf.library.7'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step0:
    def run_pure(self, inputs, params):
        value = 0
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        value = calculate4(value)
        value = calculate5(value)
        value = calculate6(value)
        value = calculate7(value)
        if value != 36:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value0': value}

@node(type_key='perf.step.1', contract={'provides': [{'key': 'value1', 'type': 'number', 'display_name': 'Value 1'}], 'output_semantics': {'value1': ['The computed value of step 1.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3', 'perf.library.4', 'perf.library.5', 'perf.library.6', 'perf.library.7'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step1:
    def run_pure(self, inputs, params):
        value = 1
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        value = calculate4(value)
        value = calculate5(value)
        value = calculate6(value)
        value = calculate7(value)
        if value != 37:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value1': value}

@node(type_key='perf.step.2', contract={'provides': [{'key': 'value2', 'type': 'number', 'display_name': 'Value 2'}], 'output_semantics': {'value2': ['The computed value of step 2.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3', 'perf.library.4', 'perf.library.5', 'perf.library.6', 'perf.library.7'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step2:
    def run_pure(self, inputs, params):
        value = 2
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        value = calculate4(value)
        value = calculate5(value)
        value = calculate6(value)
        value = calculate7(value)
        if value != 38:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value2': value}

@node(type_key='perf.step.3', contract={'provides': [{'key': 'value3', 'type': 'number', 'display_name': 'Value 3'}], 'output_semantics': {'value3': ['The computed value of step 3.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3', 'perf.library.4', 'perf.library.5', 'perf.library.6', 'perf.library.7'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step3:
    def run_pure(self, inputs, params):
        value = 3
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        value = calculate4(value)
        value = calculate5(value)
        value = calculate6(value)
        value = calculate7(value)
        if value != 39:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value3': value}

@node(type_key='perf.step.4', contract={'provides': [{'key': 'value4', 'type': 'number', 'display_name': 'Value 4'}], 'output_semantics': {'value4': ['The computed value of step 4.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3', 'perf.library.4', 'perf.library.5', 'perf.library.6', 'perf.library.7'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step4:
    def run_pure(self, inputs, params):
        value = 4
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        value = calculate4(value)
        value = calculate5(value)
        value = calculate6(value)
        value = calculate7(value)
        if value != 40:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value4': value}

@node(type_key='perf.step.5', contract={'provides': [{'key': 'value5', 'type': 'number', 'display_name': 'Value 5'}], 'output_semantics': {'value5': ['The computed value of step 5.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3', 'perf.library.4', 'perf.library.5', 'perf.library.6', 'perf.library.7'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step5:
    def run_pure(self, inputs, params):
        value = 5
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        value = calculate4(value)
        value = calculate5(value)
        value = calculate6(value)
        value = calculate7(value)
        if value != 41:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value5': value}

@node(type_key='perf.step.6', contract={'provides': [{'key': 'value6', 'type': 'number', 'display_name': 'Value 6'}], 'output_semantics': {'value6': ['The computed value of step 6.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3', 'perf.library.4', 'perf.library.5', 'perf.library.6', 'perf.library.7'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step6:
    def run_pure(self, inputs, params):
        value = 6
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        value = calculate4(value)
        value = calculate5(value)
        value = calculate6(value)
        value = calculate7(value)
        if value != 42:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value6': value}

@node(type_key='perf.step.7', contract={'provides': [{'key': 'value7', 'type': 'number', 'display_name': 'Value 7'}], 'output_semantics': {'value7': ['The computed value of step 7.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3', 'perf.library.4', 'perf.library.5', 'perf.library.6', 'perf.library.7'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step7:
    def run_pure(self, inputs, params):
        value = 7
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        value = calculate4(value)
        value = calculate5(value)
        value = calculate6(value)
        value = calculate7(value)
        if value != 43:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value7': value}

