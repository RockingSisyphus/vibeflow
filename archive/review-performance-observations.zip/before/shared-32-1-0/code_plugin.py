from vibeflow.targets.python.sdk import Plugin
from base_lib.lib0 import calculate0
from nodes.group0 import Step0, Step1, Step2, Step3, Step4, Step5, Step6, Step7
from nodes.group1 import Step8, Step9, Step10, Step11, Step12, Step13, Step14, Step15
from nodes.group2 import Step16, Step17, Step18, Step19, Step20, Step21, Step22, Step23
from nodes.group3 import Step24, Step25, Step26, Step27, Step28, Step29, Step30, Step31
from nodes.terminal import Start, End
from vibeflow.targets.python.sdk import rule, ruleset
@rule(id='perf.call', scope='call')
def count_call(context, inputs, params):
    return {'state':'completed','records':{},'findings':[]}
call_rules = ruleset(id='perf.calls', calls=[{'id':'check','rule_id':'perf.call'}], entrypoints={'static':['check']})
plugin = Plugin(id='perf.resources', resources=[calculate0, Start, End, Step0, Step1, Step2, Step3, Step4, Step5, Step6, Step7, Step8, Step9, Step10, Step11, Step12, Step13, Step14, Step15, Step16, Step17, Step18, Step19, Step20, Step21, Step22, Step23, Step24, Step25, Step26, Step27, Step28, Step29, Step30, Step31, count_call, call_rules],
                declaration_rulesets=['vibeflow.plugin_declaration'])
