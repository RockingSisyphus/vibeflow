from vibeflow.targets.python.sdk import Plugin
from base_lib.lib0 import calculate0
from base_lib.lib1 import calculate1
from base_lib.lib2 import calculate2
from base_lib.lib3 import calculate3
from base_lib.lib4 import calculate4
from base_lib.lib5 import calculate5
from base_lib.lib6 import calculate6
from base_lib.lib7 import calculate7
from nodes.group0 import Step0, Step1, Step2, Step3, Step4, Step5, Step6, Step7
from nodes.group1 import Step8, Step9, Step10, Step11, Step12, Step13, Step14, Step15
from nodes.group2 import Step16, Step17, Step18, Step19, Step20, Step21, Step22, Step23
from nodes.group3 import Step24, Step25, Step26, Step27, Step28, Step29, Step30, Step31
from nodes.group4 import Step32, Step33, Step34, Step35, Step36, Step37, Step38, Step39
from nodes.group5 import Step40, Step41, Step42, Step43, Step44, Step45, Step46, Step47
from nodes.group6 import Step48, Step49, Step50, Step51, Step52, Step53, Step54, Step55
from nodes.group7 import Step56, Step57, Step58, Step59, Step60, Step61, Step62, Step63
from nodes.group8 import Step64, Step65, Step66, Step67, Step68, Step69, Step70, Step71
from nodes.group9 import Step72, Step73, Step74, Step75, Step76, Step77, Step78, Step79
from nodes.terminal import Start, End
from vibeflow.targets.python.sdk import rule, ruleset
@rule(id='perf.call', scope='call')
def count_call(context, inputs, params):
    return {'state':'completed','records':{},'findings':[]}
call_rules = ruleset(id='perf.calls', calls=[{'id':'check','rule_id':'perf.call'}], entrypoints={'static':['check']})
plugin = Plugin(id='perf.resources', resources=[calculate0, calculate1, calculate2, calculate3, calculate4, calculate5, calculate6, calculate7, Start, End, Step0, Step1, Step2, Step3, Step4, Step5, Step6, Step7, Step8, Step9, Step10, Step11, Step12, Step13, Step14, Step15, Step16, Step17, Step18, Step19, Step20, Step21, Step22, Step23, Step24, Step25, Step26, Step27, Step28, Step29, Step30, Step31, Step32, Step33, Step34, Step35, Step36, Step37, Step38, Step39, Step40, Step41, Step42, Step43, Step44, Step45, Step46, Step47, Step48, Step49, Step50, Step51, Step52, Step53, Step54, Step55, Step56, Step57, Step58, Step59, Step60, Step61, Step62, Step63, Step64, Step65, Step66, Step67, Step68, Step69, Step70, Step71, Step72, Step73, Step74, Step75, Step76, Step77, Step78, Step79, count_call, call_rules],
                declaration_rulesets=['vibeflow.plugin_declaration'])
