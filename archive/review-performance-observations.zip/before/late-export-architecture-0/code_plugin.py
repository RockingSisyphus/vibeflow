from vibeflow.targets.python.sdk import Plugin
from base_lib.lib0 import calculate0
from nodes.group0 import Step0, Step1, Step2, Step3, Step4, Step5, Step6, Step7
from nodes.terminal import Start, End
from vibeflow.targets.python.sdk import node, SourceLocator
late = node(type_key='perf.late', contract={}, rulesets=[], source=SourceLocator('file', '/tmp/vf-perf-before-final/late-export-architecture-0/late.py', 'Late'))
from vibeflow.targets.python.sdk import rule, ruleset
@rule(id='perf.call', scope='call')
def count_call(context, inputs, params):
    return {'state':'completed','records':{},'findings':[]}
call_rules = ruleset(id='perf.calls', calls=[{'id':'check','rule_id':'perf.call'}], entrypoints={'static':['check']})
plugin = Plugin(id='perf.resources', resources=[calculate0, Start, End, Step0, Step1, Step2, Step3, Step4, Step5, Step6, Step7, late, count_call, call_rules],
                declaration_rulesets=['vibeflow.plugin_declaration'])
