from vibeflow.targets.python.sdk import node
from base_lib.lib0 import calculate0
from base_lib.lib1 import calculate1
from base_lib.lib2 import calculate2
from base_lib.lib3 import calculate3
@node(type_key='perf.step.8', contract={'provides': [{'key': 'value8', 'type': 'number', 'display_name': 'Value 8'}], 'output_semantics': {'value8': ['The computed value of step 8.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step8:
    def run_pure(self, inputs, params):
        value = 8
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        if value != 18:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value8': value}

@node(type_key='perf.step.9', contract={'provides': [{'key': 'value9', 'type': 'number', 'display_name': 'Value 9'}], 'output_semantics': {'value9': ['The computed value of step 9.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step9:
    def run_pure(self, inputs, params):
        value = 9
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        if value != 19:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value9': value}

@node(type_key='perf.step.10', contract={'provides': [{'key': 'value10', 'type': 'number', 'display_name': 'Value 10'}], 'output_semantics': {'value10': ['The computed value of step 10.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step10:
    def run_pure(self, inputs, params):
        value = 10
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        if value != 20:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value10': value}

@node(type_key='perf.step.11', contract={'provides': [{'key': 'value11', 'type': 'number', 'display_name': 'Value 11'}], 'output_semantics': {'value11': ['The computed value of step 11.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step11:
    def run_pure(self, inputs, params):
        value = 11
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        if value != 21:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value11': value}

@node(type_key='perf.step.12', contract={'provides': [{'key': 'value12', 'type': 'number', 'display_name': 'Value 12'}], 'output_semantics': {'value12': ['The computed value of step 12.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step12:
    def run_pure(self, inputs, params):
        value = 12
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        if value != 22:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value12': value}

@node(type_key='perf.step.13', contract={'provides': [{'key': 'value13', 'type': 'number', 'display_name': 'Value 13'}], 'output_semantics': {'value13': ['The computed value of step 13.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step13:
    def run_pure(self, inputs, params):
        value = 13
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        if value != 23:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value13': value}

@node(type_key='perf.step.14', contract={'provides': [{'key': 'value14', 'type': 'number', 'display_name': 'Value 14'}], 'output_semantics': {'value14': ['The computed value of step 14.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step14:
    def run_pure(self, inputs, params):
        value = 14
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        if value != 24:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value14': value}

@node(type_key='perf.step.15', contract={'provides': [{'key': 'value15', 'type': 'number', 'display_name': 'Value 15'}], 'output_semantics': {'value15': ['The computed value of step 15.']}},
      rulesets=['vibeflow.process','perf.calls'], base_libs=['perf.library.0', 'perf.library.1', 'perf.library.2', 'perf.library.3'],
      presentation={'fill':'#d6eaff','shape':'rounded'})
class Step15:
    def run_pure(self, inputs, params):
        value = 15
        value = calculate0(value)
        value = calculate1(value)
        value = calculate2(value)
        value = calculate3(value)
        if value != 25:
            raise ValueError('Unexpected sandbox arithmetic')
        return {'value15': value}

