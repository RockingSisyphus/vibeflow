"""Exception handlers retain ownership at fallible expression evaluation sites."""

import ast
from textwrap import indent

import pytest

from vibeflow.core.rules import RuleContext, compile_ruleset, execute_rule_plan
from vibeflow.targets.python.quality.policy_parameters import complete_source_policy_plan
from vibeflow.targets.python.quality.source_context import (
    PythonSourceFile, PythonSourceNode, build_python_source_context,
)
from vibeflow.targets.python.sdk import node, ruleset
from vibeflow.targets.shared.bindings import native_binding
from vibeflow.tooling.project.descriptor_loader import load_builtin_plugins


# Keep the independent F05 review's eight expressions and expectations intact.
# Its direct/helper endpoints make the original sixteen cases.
ORIGINAL_CASES = (
    ('tuple_lookup', "((alias := inputs), params['missing'], (alias := {}))", True),
    ('list_lookup', "[(alias := inputs), params['missing'], (alias := {})]", True),
    ('dict_lookup', "{'a': (alias := inputs), 'b': params['missing'], 'c': (alias := {})}", True),
    ('assign_tuple_lookup', "unused = ((alias := inputs), params['missing'], (alias := {}))", True),
    ('tuple_call', "((alias := inputs), noop(), (alias := {}))", True),
    ('tuple_attribute', "((alias := inputs), params.missing, (alias := {}))", True),
    ('clear_before_lookup_control', "((alias := inputs), (alias := {}), params['missing'])", False),
    ('separate_statements_control', "alias = inputs\nparams['missing']\nalias = {}", True),
)

ARGUMENT_CASES = (
    ('positional_lookup', "combine((alias := inputs), params['missing'], (alias := {}))", True),
    ('keyword_lookup', "combine(first=(alias := inputs), missing=params['missing'], cleared=(alias := {}))", True),
    ('nested_argument_call', "combine((alias := inputs), noop(), (alias := {}))", True),
    ('clear_before_argument_lookup', "combine((alias := inputs), (alias := {}), params['missing'])", False),
)

ADJACENT_CASES = (
    ('nested_inner_handler',
     "alias = {}\ntry:\n    try:\n        ((alias := inputs), params['missing'], (alias := {}))\n    except Exception:\n        MUTATION\nexcept Exception:\n    pass", True),
    ('nested_inner_finally',
     "alias = {}\ntry:\n    try:\n        ((alias := inputs), params['missing'], (alias := {}))\n    finally:\n        MUTATION\nexcept Exception:\n    pass", True),
    ('nested_handler_propagates_outer',
     "alias = {}\ntry:\n    try:\n        params['first']\n    except Exception:\n        ((alias := inputs), params['missing'], (alias := {}))\nexcept Exception:\n    MUTATION", True),
    ('nested_else_propagates_outer',
     "alias = {}\ntry:\n    try:\n        pass\n    except Exception:\n        pass\n    else:\n        ((alias := inputs), params['missing'], (alias := {}))\nexcept Exception:\n    MUTATION", True),
    ('nested_finally_propagates_outer',
     "alias = {}\ntry:\n    try:\n        pass\n    finally:\n        ((alias := inputs), params['missing'], (alias := {}))\nexcept Exception:\n    MUTATION", True),
    ('nested_inner_handler_clears',
     "alias = {}\ntry:\n    try:\n        ((alias := inputs), params['missing'], (alias := {}))\n    except Exception:\n        alias = {}\nfinally:\n    MUTATION", False),
    ('nested_finally_clears_before_use',
     "alias = {}\ntry:\n    try:\n        ((alias := inputs), params['missing'], (alias := {}))\n    finally:\n        alias = {}\nexcept Exception:\n    MUTATION", False),
    ('outer_finally_uses_exceptional_state',
     "alias = {}\ntry:\n    ((alias := inputs), params['missing'], (alias := {}))\nfinally:\n    MUTATION", True),
    ('outer_finally_clears_before_use',
     "alias = {}\ntry:\n    ((alias := inputs), params['missing'], (alias := {}))\nfinally:\n    alias = {}\n    MUTATION", False),
    ('definition_body_not_executed',
     "alias = {}\ntry:\n    def later():\n        nonlocal alias\n        ((alias := inputs), params['missing'], (alias := {}))\nexcept Exception:\n    MUTATION", False),
    ('lambda_body_not_executed',
     "alias = {}\ntry:\n    later = lambda: ((alias := inputs), params['missing'], (alias := {}))\nexcept Exception:\n    MUTATION", False),
    ('definition_default_is_evaluated',
     "alias = {}\ntry:\n    def later(value=((alias := inputs), params['missing'], (alias := {}))):\n        return value\nexcept Exception:\n    MUTATION", True),
    ('definition_default_clear_control',
     "alias = {}\ntry:\n    def later(value=((alias := inputs), (alias := {}), params['missing'])):\n        return value\nexcept Exception:\n    MUTATION", False),
    ('called_nested_body_writes_before_error',
     "alias = {}\ntry:\n    def later():\n        nonlocal alias\n        ((alias := inputs), params['missing'], (alias := {}))\n    later()\nexcept Exception:\n    MUTATION", True),
    ('handler_clears_before_use',
     "alias = {}\ntry:\n    ((alias := inputs), params['missing'], (alias := {}))\nexcept Exception:\n    alias = {}\n    MUTATION", False),
)


@pytest.fixture(scope="module")
def native_effect_plan():
    catalog = load_builtin_plugins("python").catalogs
    definitions = {item.id: item for item in catalog.rules}
    handlers = {item.id: native_binding(catalog, "rule", item.id) for item in catalog.rules}
    selected = ruleset(id="probe.exception_effects", calls=[{
        "id": "effects", "rule_id": "vibeflow.no_side_effects",
        "params": {"effect_scope": "global_state"},
    }]).descriptor
    plan = complete_source_policy_plan(compile_ruleset(selected, rules=definitions,
        rulesets={selected.id: selected}), handlers=handlers)
    return plan, handlers


def _review(body, placement, native_effect_plan):
    source_path = "/virtual/input_exception_states.py"
    prefix = ('def sink(payload):\n    payload.pop("seed", None)\n'
              'def noop():\n    raise ValueError("probe")\n'
              'def combine(*args, **kwargs):\n    return args\n')
    if placement == "module_helper":
        text = prefix + "def inspected(inputs, params):\n" + indent(body + "\nreturn {}\n", "    ")
        text += "class Task:\n    def run_pure(self, inputs, params):\n        inspected(inputs, params)\n        return {}\n"
    else:
        text = prefix + "class Task:\n    def run_pure(self, inputs, params):\n" + indent(body + "\nreturn {}\n", "        ")
    compile(text, source_path, "exec")
    parsed = PythonSourceFile.parse(source_path, "input_exception_states", text)
    # A delayed canonical SDK declaration supplies the actual descriptor. The
    # inspected business definitions are parsed, never imported or executed.
    declared = node(type_key="probe.task", contract={}, rulesets=["probe.exception_effects"],
        source={"kind": "file", "ref": source_path, "export": "Task"})
    resource = PythonSourceNode(declared.descriptor, parsed.path, "Task")
    sources = build_python_source_context((resource,), (parsed,))
    context = RuleContext(subject={"kind": "node", "id": "probe.task", "type_key": "probe.task"},
        target="python", facts={"source_context": sources, "node_catalog": (), "source_owners": (
            {"kind": "node", "id": "probe.task", "role": "entry", "path": source_path, "symbol": "Task"},
        )})
    before = ast.dump(parsed._tree)
    plan, handlers = native_effect_plan
    result = execute_rule_plan(plan, context, handlers=handlers)
    assert result.results["effects"].state == "completed"
    assert result.results["effects"].records["effect_policy"].value["effect_scope"] == "global_state"
    assert ast.dump(parsed._tree) == before
    return tuple(item for item in result.findings if item.code == "NODE.PURITY.INPUT_MUTATION")


def _mutation(via_helper):
    return 'sink(alias)' if via_helper else 'alias.pop("seed", None)'


def _handled_expression(expression, via_helper):
    return ('alias = {}\ntry:\n' + indent(expression, "    ")
            + '\nexcept Exception:\n    ' + _mutation(via_helper))


@pytest.mark.parametrize("placement", ("method", "module_helper"))
@pytest.mark.parametrize("via_helper", (False, True), ids=("direct", "helper"))
@pytest.mark.parametrize("label,expression,owned", ORIGINAL_CASES, ids=[row[0] for row in ORIGINAL_CASES])
def test_original_exception_review_keeps_input_identity(label, expression, owned, via_helper, placement, native_effect_plan):
    findings = _review(_handled_expression(expression, via_helper), placement, native_effect_plan)
    assert bool(findings) == owned, (label, via_helper, placement, findings)


@pytest.mark.parametrize("placement", ("method", "module_helper"))
@pytest.mark.parametrize("via_helper", (False, True), ids=("direct", "helper"))
@pytest.mark.parametrize("label,expression,owned", ARGUMENT_CASES, ids=[row[0] for row in ARGUMENT_CASES])
def test_call_arguments_capture_intermediate_exception_state(label, expression, owned, via_helper, placement, native_effect_plan):
    findings = _review(_handled_expression(expression, via_helper), placement, native_effect_plan)
    assert bool(findings) == owned, (label, via_helper, placement, findings)


@pytest.mark.parametrize("placement", ("method", "module_helper"))
@pytest.mark.parametrize("via_helper", (False, True), ids=("direct", "helper"))
@pytest.mark.parametrize("label,body,owned", ADJACENT_CASES, ids=[row[0] for row in ADJACENT_CASES])
def test_nested_exception_regions_keep_execution_and_clearing_boundaries(label, body, owned, via_helper, placement, native_effect_plan):
    findings = _review(body.replace("MUTATION", _mutation(via_helper)), placement, native_effect_plan)
    assert bool(findings) == owned, (label, via_helper, placement, findings)


@pytest.mark.parametrize("placement", ("method", "module_helper"))
@pytest.mark.parametrize("via_helper", (False, True), ids=("direct", "helper"))
def test_catchall_handler_clearing_is_a_precise_negative_control(via_helper, placement, native_effect_plan):
    body = ("alias = {}\ntry:\n    try:\n"
            "        ((alias := inputs), params['missing'], (alias := {}))\n"
            "    except:\n        alias = {}\nfinally:\n    " + _mutation(via_helper))
    findings = _review(body, placement, native_effect_plan)
    assert findings == (), (via_helper, placement, findings)
