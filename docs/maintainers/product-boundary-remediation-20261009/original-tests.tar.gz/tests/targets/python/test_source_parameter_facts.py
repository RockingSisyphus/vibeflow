"""Parameter proofs use actual callers and lexical builtin identities."""

import ast
from textwrap import indent

import pytest

from vibeflow.core.rules import RuleContext, compile_ruleset, execute_rule_plan
from vibeflow.targets.python.quality.policy_parameters import complete_source_policy_plan
from vibeflow.targets.python.quality.source_analysis.parameter_facts import source_parameter_facts
from vibeflow.targets.python.quality.source_context import (
    PythonSourceFile, PythonSourceNode, build_python_source_context,
)
from vibeflow.targets.python.sdk import node, ruleset
from vibeflow.targets.shared.bindings import native_binding
from vibeflow.tooling.project.descriptor_loader import load_builtin_plugins


def _facts(text, *, helper_text=None):
    path = "/virtual/parameter_facts.py"
    compile(text, path, "exec")
    source = PythonSourceFile.parse(path, "parameter_facts", text)
    files = [source]
    if helper_text is not None:
        compile(helper_text, "/virtual/facts_helper.py", "exec")
        files.append(PythonSourceFile.parse("/virtual/facts_helper.py", "facts_helper", helper_text))
    declaration = node(type_key="probe.parameter_facts", contract={},
        source={"kind": "file", "ref": path, "export": "Task"})
    resource = PythonSourceNode(declaration.descriptor, path, "Task")
    sources = build_python_source_context((resource,), files)
    return sources, source_parameter_facts(sources, resource)


def _function(sources, name, path="/virtual/parameter_facts.py"):
    symbol = sources.symbol(path, name)
    assert symbol is not None
    return symbol


def test_cross_file_forwarding_keeps_input_and_dictionary_facts_distinct():
    text = ("from facts_helper import forward\nclass Task:\n"
            "    def run_pure(self, inputs, params):\n"
            "        forward(inputs, params)\n        return {}\n")
    helper = ("def forward(payload, settings):\n    mutate(payload, settings)\n"
              "def mutate(value, options):\n    value.pop('seed', None)\n    options['missing']\n")
    sources, (owned, dictionaries, _) = _facts(text, helper_text=helper)
    run = _function(sources, "Task.run_pure")
    forward = _function(sources, "forward", "/virtual/facts_helper.py")
    mutate = _function(sources, "mutate", "/virtual/facts_helper.py")
    assert owned[run.id] == {"inputs"}
    assert dictionaries[run._node] == {"params"}
    assert owned[forward.id] == {"payload"}
    assert dictionaries[forward._node] == {"settings"}
    assert owned[mutate.id] == {"value"}
    assert dictionaries[mutate._node] == {"options"}


@pytest.mark.parametrize("calls,expected", (
    ("inspect(inputs, params)", {"params"}),
    ("inspect(inputs, params)\n        inspect({}, [])", set()),
    ("inspect(inputs, [])", set()),
    ("settings = {}\n        inspect(inputs, settings)", {"params"}),
    ("settings = {}\n        settings = []\n        inspect(inputs, settings)", set()),
    ("params = []\n        inspect(inputs, params)", set()),
), ids=("canonical", "mixed-callers", "name-is-not-proof", "local-dict",
        "overwritten-local", "overwritten-runtime-parameter"))
def test_dictionary_proof_requires_every_actual_argument(calls, expected):
    text = ("def inspect(payload, params):\n    return params\nclass Task:\n"
            "    def run_pure(self, inputs, params):\n        " + calls + "\n        return {}\n")
    sources, (owned, dictionaries, _) = _facts(text)
    inspected = _function(sources, "inspect")
    assert dictionaries[inspected._node] == expected
    assert owned[inspected.id] == {"payload"}


def test_literal_default_and_keyword_forwarding_are_actual_dictionary_inputs():
    text = ("def inspect(payload, *, options={}):\n    return options\nclass Task:\n"
            "    def run_pure(self, inputs, params):\n"
            "        inspect(inputs)\n        inspect(inputs, options=params)\n        return {}\n")
    sources, (owned, dictionaries, _) = _facts(text)
    inspected = _function(sources, "inspect")
    assert dictionaries[inspected._node] == {"options"}
    assert owned[inspected.id] == {"payload"}


@pytest.mark.parametrize("prefix,body,name,expected", (
    ("", "pass", "Task.run_pure", True),
    ("Exception = ValueError\n", "pass", "Task.run_pure", False),
    ("", "Exception = ValueError", "Task.run_pure", False),
    ("", "def inner(Exception):\n            return Exception\n        inner(ValueError)",
     "Task.run_pure.inner", False),
    ("", "Exception = ValueError\n        def inner():\n            return Exception\n        inner()",
     "Task.run_pure.inner", False),
    ("", "Exception = ValueError\n        def inner():\n            global Exception\n            return Exception\n        inner()",
     "Task.run_pure.inner", True),
), ids=("builtin", "module-shadow", "body-shadow", "parameter-shadow", "cell-shadow", "global"))
def test_exception_builtin_proof_honors_declared_binding_owner(prefix, body, name, expected):
    text = prefix + ("class Task:\n    def run_pure(self, inputs, params):\n        "
                     + body + "\n        return {}\n")
    sources, (_, _, builtins) = _facts(text)
    function = _function(sources, name)
    assert ("Exception" in builtins[function._node]) is expected
    assert "BaseException" in builtins[function._node]
    assert "dict" in builtins[function._node]


@pytest.mark.parametrize("expression,expected", (
    ("lambda Exception: Exception", False),
    ("lambda value: Exception", True),
    ("[lambda: Exception for Exception in (ValueError,)]", False),
    ("[lambda: Exception for item in (ValueError,)]", True),
), ids=("parameter", "unshadowed", "comprehension-cell", "other-target"))
def test_lambda_and_comprehension_builtin_proof_is_lexical(expression, expected):
    text = ("class Task:\n    def run_pure(self, inputs, params):\n"
            "        callback = " + expression + "\n        return {}\n")
    sources, (_, _, builtins) = _facts(text)
    run = _function(sources, "Task.run_pure")
    callback = next(child for child in ast.walk(run._node) if isinstance(child, ast.Lambda))
    assert ("Exception" in builtins[callback]) is expected


@pytest.fixture(scope="module")
def native_effect_plan():
    catalog = load_builtin_plugins("python").catalogs
    definitions = {item.id: item for item in catalog.rules}
    handlers = {item.id: native_binding(catalog, "rule", item.id) for item in catalog.rules}
    selected = ruleset(id="probe.parameter_effects", calls=[{
        "id": "effects", "rule_id": "vibeflow.no_side_effects",
        "params": {"effect_scope": "global_state"},
    }]).descriptor
    plan = complete_source_policy_plan(compile_ruleset(selected, rules=definitions,
        rulesets={selected.id: selected}), handlers=handlers)
    return plan, handlers


EXCEPTION_CONTROLS = (
    ("generator-body-is-deferred",
     "alias = {}\ntry:\n    later = (((alias := inputs), params['missing'], (alias := {})) for item in (0,))\n"
     "except Exception:\n    MUTATION", False),
    ("dict-call-arguments-clear-before-call",
     "alias = {}\ntry:\n    dict((alias := inputs), (alias := {}))\nexcept Exception:\n    MUTATION", False),
    ("bound-noncallable-arguments-clear-before-call",
     "later = None\nalias = {}\ntry:\n    later((alias := inputs), (alias := {}))\n"
     "except Exception:\n    MUTATION", False),
    ("unbound-callee-errors-before-argument-clear",
     "alias = inputs\ntry:\n    later((alias := {}))\nexcept Exception:\n    MUTATION\nlater = None", True),
)


@pytest.mark.parametrize("via_helper", (False, True), ids=("direct", "helper"))
@pytest.mark.parametrize("label,body,expected", EXCEPTION_CONTROLS,
                         ids=[case[0] for case in EXCEPTION_CONTROLS])
def test_exception_controls_use_evaluation_and_binding_facts(label, body, expected, via_helper,
                                                            native_effect_plan):
    findings = _review_exception_control(body, via_helper, "method", native_effect_plan)
    assert bool(findings) is expected, (label, via_helper, findings)


def _review_exception_control(body, via_helper, placement, native_effect_plan):
    mutation = 'sink(alias)' if via_helper else 'alias.pop("seed", None)'
    path = "/virtual/parameter_exception_controls.py"
    prefix = "def sink(payload):\n    payload.pop('seed', None)\n"
    inspected = body.replace("MUTATION", mutation) + "\nreturn {}\n"
    if placement == "module_helper":
        text = prefix + "def inspected(inputs, params):\n" + indent(inspected, "    ")
        text += ("class Task:\n    def run_pure(self, inputs, params):\n"
                 "        inspected(inputs, params)\n        return {}\n")
    else:
        text = (prefix + "class Task:\n    def run_pure(self, inputs, params):\n"
                + indent(inspected, "        "))
    return _review_source_text(text, path, native_effect_plan)


def _review_source_text(text, path, native_effect_plan):
    compile(text, path, "exec")
    parsed = PythonSourceFile.parse(path, "parameter_exception_controls", text)
    declaration = node(type_key="probe.parameter_facts", contract={},
        rulesets=["probe.parameter_effects"],
        source={"kind": "file", "ref": path, "export": "Task"})
    resource = PythonSourceNode(declaration.descriptor, path, "Task")
    sources = build_python_source_context((resource,), (parsed,))
    context = RuleContext(subject={"kind": "node", "id": "probe.parameter_facts",
        "type_key": "probe.parameter_facts"}, target="python", facts={
            "source_context": sources, "node_catalog": (), "source_owners": (
                {"kind": "node", "id": "probe.parameter_facts", "role": "entry",
                 "path": path, "symbol": "Task"},)})
    before = ast.dump(parsed._tree)
    plan, handlers = native_effect_plan
    result = execute_rule_plan(plan, context, handlers=handlers)
    assert result.results["effects"].state == "completed"
    findings = tuple(item for item in result.findings if item.code == "NODE.PURITY.INPUT_MUTATION")
    assert ast.dump(parsed._tree) == before
    return findings


DELETED_CALLEE_CONTROLS = (
    ("deleted-callee",
     "callee = None\nalias = inputs\ndel callee\ntry:\n    callee((alias := {}))\n"
     "except Exception:\n    MUTATION", True),
    ("tuple-deleted-callee",
     "first = second = None\nalias = inputs\ndel first, second\ntry:\n    second((alias := {}))\n"
     "except Exception:\n    MUTATION", True),
    ("except-target-is-implicitly-deleted",
     "callee = None\nalias = inputs\ntry:\n    params['missing']\nexcept Exception as callee:\n"
     "    pass\ntry:\n    callee((alias := {}))\nexcept Exception:\n    MUTATION", True),
    ("bound-noncallable-negative",
     "callee = None\nalias = inputs\ntry:\n    callee((alias := {}))\n"
     "except Exception:\n    MUTATION", False),
    ("rebound-after-delete-negative",
     "callee = None\nalias = inputs\ndel callee\ncallee = None\ntry:\n    callee((alias := {}))\n"
     "except Exception:\n    MUTATION", False),
    ("rebound-after-except-negative",
     "callee = None\nalias = inputs\ntry:\n    params['missing']\nexcept Exception as callee:\n"
     "    pass\ncallee = None\ntry:\n    callee((alias := {}))\nexcept Exception:\n    MUTATION", False),
)


@pytest.mark.parametrize("placement", ("method", "module_helper"))
@pytest.mark.parametrize("via_helper", (False, True), ids=("direct", "helper"))
@pytest.mark.parametrize("label,body,expected", DELETED_CALLEE_CONTROLS,
                         ids=[case[0] for case in DELETED_CALLEE_CONTROLS])
def test_deleted_and_rebound_callees_keep_exception_evaluation_order(label, body, expected,
                                                                  via_helper, placement,
                                                                  native_effect_plan):
    findings = _review_exception_control(body, via_helper, placement, native_effect_plan)
    assert bool(findings) is expected, (label, via_helper, placement, findings)


BOUND_EVALUATION_CONTROLS = (
    ("later-comprehension-target-is-not-bound-yet",
     "alias = inputs\ntry:\n    [1 for item in (0,) if callee((alias := {})) for callee in (None,)]\n"
     "except Exception:\n    MUTATION", True),
    ("earlier-comprehension-target-is-bound",
     "alias = inputs\ntry:\n    [1 for item in (0,) for callee in (None,) if callee((alias := {}))]\n"
     "except Exception:\n    MUTATION", False),
    ("unbound-local-load-before-clear",
     "alias = inputs\ntry:\n    [later, (alias := {})]\nexcept Exception:\n    MUTATION\nlater = None", True),
    ("bound-local-load-before-clear-negative",
     "later = None\nalias = inputs\ntry:\n    [later, (alias := {})]\n"
     "except Exception:\n    MUTATION\nlater = None", False),
)


@pytest.mark.parametrize("via_helper", (False, True), ids=("direct", "helper"))
@pytest.mark.parametrize("label,body,expected", BOUND_EVALUATION_CONTROLS,
                         ids=[case[0] for case in BOUND_EVALUATION_CONTROLS])
def test_local_name_loads_use_actual_binding_before_argument_clear(label, body, expected,
                                                                 via_helper, native_effect_plan):
    findings = _review_exception_control(body, via_helper, "method", native_effect_plan)
    assert bool(findings) is expected, (label, via_helper, findings)


@pytest.mark.parametrize("via_helper", (False, True), ids=("direct", "helper"))
@pytest.mark.parametrize("arbitrary_params,expected", ((False, False), (True, True)),
                         ids=("captured-runtime-dictionary", "captured-arbitrary-object"))
def test_nested_actual_call_keeps_captured_parameter_provenance(arbitrary_params, expected,
                                                              via_helper, native_effect_plan):
    mutation = 'sink(alias)' if via_helper else 'alias.pop("seed", None)'
    text = ("def sink(payload):\n    payload.pop('seed', None)\n"
            "class RaisingLookup:\n    def __getitem__(self, key):\n        raise BaseException('probe')\n"
            "def queried(inputs, params):\n    alias = {}\n    try:\n        try:\n"
            "            ((alias := inputs), params['missing'], (alias := {}))\n"
            "        except Exception:\n            alias = {}\n    finally:\n        "
            + mutation + "\nclass Task:\n    def run_pure(self, inputs, params):\n")
    if arbitrary_params:
        text += "        params = RaisingLookup()\n"
    text += ("        def inner():\n            queried(inputs, params)\n"
             "        inner()\n        return {}\n")
    sources, (_, dictionaries, _) = _facts(text)
    queried = _function(sources, "queried")
    assert ("params" in dictionaries[queried._node]) is not arbitrary_params
    findings = _review_source_text(text, "/virtual/nested_parameter_capture.py", native_effect_plan)
    assert bool(findings) is expected, (arbitrary_params, via_helper, findings)


CAPTURED_DICTIONARY_CONTROLS = (
    ("late-rebind-to-arbitrary-object", "params = RaisingLookup()\n", True),
    ("unchanged-runtime-dictionary", "", False),
    ("nonlocal-setter-before-actual-call",
     "def replace():\n    nonlocal params\n    params = RaisingLookup()\nreplace()\n", True),
    ("unrelated-sibling-parameter-does-not-pollute-capture",
     "def sibling(params):\n    params = RaisingLookup()\nsibling({})\n", False),
)


@pytest.mark.parametrize("via_helper", (False, True), ids=("direct", "helper"))
@pytest.mark.parametrize("label,between,expected", CAPTURED_DICTIONARY_CONTROLS,
                         ids=[case[0] for case in CAPTURED_DICTIONARY_CONTROLS])
def test_captured_dictionary_proof_requires_stable_actual_binding(label, between, expected,
                                                                via_helper, native_effect_plan):
    mutation = 'sink(alias)' if via_helper else 'alias.pop("seed", None)'
    text = ("def sink(payload):\n    payload.pop('seed', None)\n"
            "class RaisingLookup:\n    def __getitem__(self, key):\n        raise BaseException('probe')\n"
            "def queried(inputs, params):\n    alias = {}\n    try:\n        try:\n"
            "            ((alias := inputs), params['missing'], (alias := {}))\n"
            "        except Exception:\n            alias = {}\n    finally:\n        "
            + mutation + "\nclass Task:\n    def run_pure(self, inputs, params):\n"
            "        def inner():\n            queried(inputs, params)\n"
            + indent(between, "        ") + "        inner()\n        return {}\n")
    sources, (owned, dictionaries, _) = _facts(text)
    queried = _function(sources, "queried")
    assert owned[queried.id] == {"inputs"}
    assert ("params" in dictionaries[queried._node]) is not expected
    findings = _review_source_text(text, "/virtual/captured_dictionary_stability.py", native_effect_plan)
    assert bool(findings) is expected, (label, via_helper, findings)
