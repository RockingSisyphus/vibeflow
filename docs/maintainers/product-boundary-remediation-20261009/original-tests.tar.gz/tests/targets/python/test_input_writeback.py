"""Direct input mutations consume the same lexical call-site facts as helpers."""
import ast
from textwrap import indent

import pytest

from vibeflow.core.descriptors import NodeContractDescriptor, NodeDescriptor
from vibeflow.core.rules import RuleContext
from vibeflow.targets.python.quality.rules.effects import no_side_effects
from vibeflow.targets.python.quality.source_analysis.input_tracking import (
    _input_call_facts, _input_reference_facts, source_input_parameters,
)
from vibeflow.targets.python.quality.source_context import (
    PythonSourceFile, PythonSourceNode, build_python_source_context,
)


CASES = (
    ("nonlocal_assign", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nbind()\nalias.pop('seed', None)", True),
    ("nonlocal_walrus", "alias = {}\ndef bind():\n    nonlocal alias\n    (alias := inputs)\nbind()\nalias.pop('seed', None)", True),
    ("nonlocal_get", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs.get('nested')\nbind()\nalias.pop('seed', None)", True),
    ("nonlocal_multilevel", "alias = {}\ndef middle():\n    def bind():\n        nonlocal alias\n        alias = inputs\n    bind()\nmiddle()\nalias.pop('seed', None)", True),
    ("nonlocal_nearest_local", "alias = {}\ndef middle():\n    alias = {}\n    def bind():\n        nonlocal alias\n        alias = inputs\n    bind()\nmiddle()\nalias.pop('seed', None)", False),
    ("global_assign", "def bind():\n    global alias\n    alias = inputs\nbind()\nalias.pop('seed', None)", True),
    ("global_walrus", "def bind():\n    global alias\n    (alias := inputs)\nbind()\nalias.pop('seed', None)", True),
    ("global_caller_local", "alias = {}\ndef bind():\n    global alias\n    alias = inputs\nbind()\nalias.pop('seed', None)", False),
    ("global_outer_closure", "global alias\nalias = inputs\ndef mutate():\n    alias.pop('seed', None)\nmutate()", True),
    ("global_middle_closure", "alias = {}\ndef middle():\n    global alias\n    alias = inputs\n    def mutate():\n        alias.pop('seed', None)\n    mutate()\nmiddle()", True),
    ("ordinary_child_local", "alias = {}\ndef bind():\n    alias = inputs\nbind()\nalias.pop('seed', None)", False),
    ("lambda_body_local", "alias = {}\nfn = lambda: (alias := inputs)\nfn()\nalias.pop('seed', None)", False),
    ("lambda_parameter", "(lambda inputs: inputs.pop('seed', None))({})", False),
    ("lambda_closure", "(lambda: inputs.pop('seed', None))()", True),
    ("function_default_walrus", "def bind(value=(alias := inputs)):\n    return value\nalias.pop('seed', None)", True),
    ("lambda_default_walrus", "fn = lambda value=(alias := inputs): value\nalias.pop('seed', None)", True),
    ("comp_default_walrus", "values = [lambda value=(alias := inputs): value for item in (0,)]\nalias.pop('seed', None)", True),
    ("comp_local_input_control", "alias = {}\nvalues = [lambda value=(alias := inputs): value for inputs in ({},)]\nalias.pop('seed', None)", False),
    ("nonlocal_comp", "alias = {}\ndef bind():\n    nonlocal alias\n    list(alias := inputs for item in (0,))\nbind()\nalias.pop('seed', None)", True),
    ("global_comp", "def bind():\n    global alias\n    values = [alias := inputs for item in (0,)]\nbind()\nalias.pop('seed', None)", True),
    ("nested_parameter_direct", "def mutate(payload):\n    payload.pop('seed', None)\nmutate(inputs)", True),
    ("nested_parameter_local_control", "def mutate(payload):\n    payload.pop('seed', None)\nmutate({})", False),
    ("nested_parameter_nonlocal_write", "alias = {}\ndef bind(payload):\n    nonlocal alias\n    alias = payload\nbind(inputs)\nalias.pop('seed', None)", True),
    ("nested_parameter_keyword_write", "alias = {}\ndef bind(*, payload):\n    nonlocal alias\n    alias = payload\nbind(payload=inputs)\nalias.pop('seed', None)", True),
    ("nested_parameter_global_write", "def bind(payload):\n    global alias\n    alias = payload\nbind(inputs)\nalias.pop('seed', None)", True),
    ("nested_parameter_fake_write", "alias = {}\ndef bind(payload):\n    nonlocal alias\n    alias = payload\nbind({})\nalias.pop('seed', None)", False),
    ("straight_overwrite", "alias = inputs\nalias = {}\nalias.pop('seed', None)", False),
    ("annotated_overwrite", "alias = inputs\nalias: dict = {}\nalias.pop('seed', None)", False),
    ("walrus_overwrite", "alias = inputs\n(alias := {})\nalias.pop('seed', None)", False),
    ("nonlocal_caller_overwrite", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nbind()\nalias = {}\nalias.pop('seed', None)", False),
    ("global_caller_overwrite", "global alias\ndef bind():\n    global alias\n    alias = inputs\nbind()\nalias = {}\nalias.pop('seed', None)", False),
    ("constant_false", "alias = {}\nif False:\n    alias = inputs\nalias.pop('seed', None)", False),
    ("constant_false_else_owned", "alias = {}\nif False:\n    alias = {}\nelse:\n    alias = inputs\nalias.pop('seed', None)", True),
    ("constant_true_else_dead", "alias = {}\nif True:\n    alias = {}\nelse:\n    alias = inputs\nalias.pop('seed', None)", False),
    ("branch_owned_first", "if params['flag']:\n    alias = inputs\nelse:\n    alias = {}\nalias.pop('seed', None)", True),
    ("branch_owned_else", "if params['flag']:\n    alias = {}\nelse:\n    alias = inputs\nalias.pop('seed', None)", True),
    ("branch_both_clear", "alias = inputs\nif params['flag']:\n    alias = {}\nelse:\n    alias = {}\nalias.pop('seed', None)", False),
    ("loop_possible_write", "alias = {}\nfor item in ():\n    alias = inputs\nalias.pop('seed', None)", True),
    ("loop_clear_keeps_zero_iterations", "alias = inputs\nfor item in ():\n    alias = {}\nalias.pop('seed', None)", True),
    ("while_false", "alias = {}\nwhile False:\n    alias = inputs\nalias.pop('seed', None)", False),
    ("loop_next_iteration", "alias = {}\nfor item in params['items']:\n    alias.pop('seed', None)\n    alias = inputs", True),
    ("comp_clear_keeps_zero_iterations", "alias = inputs\nvalues = [(alias := {}) for item in ()]\nalias.pop('seed', None)", True),
    ("comp_next_iteration", "alias = {}\nvalues = [(alias.pop('seed', None), (alias := inputs)) for item in params['items']]", True),
    ("late_closure", "alias = {}\ndef mutate():\n    alias.pop('seed', None)\nalias = inputs\nmutate()", True),
    ("closure_after_clear", "alias = inputs\nalias = {}\ndef mutate():\n    alias.pop('seed', None)\nmutate()", False),
    ("global_closure_after_clear", "global alias\nalias = inputs\nalias = {}\ndef mutate():\n    alias.pop('seed', None)\nmutate()", False),
    ("late_bind_call", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nalias = {}\ndef mutate():\n    alias.pop('seed', None)\nbind()\nmutate()", True),
    ("noncalled_binding_does_not_write", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nalias.pop('seed', None)", False),
    ("dead_binding_call_does_not_write", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nif False:\n    bind()\nalias.pop('seed', None)", False),
    ("noncalled_global_binding_does_not_write", "def bind():\n    global alias\n    alias = inputs\nalias.pop('seed', None)", False),
    ("late_bind_wrapper", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\ndef middle():\n    bind()\nalias = {}\ndef mutate():\n    alias.pop('seed', None)\nmiddle()\nmutate()", True),
    ("late_bind_mutual_definition", "alias = {}\ndef first():\n    second()\ndef second():\n    nonlocal alias\n    alias = inputs\nalias = {}\ndef mutate():\n    alias.pop('seed', None)\nfirst()\nmutate()", True),
    ("possible_bind_branch", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nif params['flag']:\n    bind()\nalias.pop('seed', None)", True),
    ("possible_bind_reverse_branch", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nif params['flag']:\n    pass\nelse:\n    bind()\nalias.pop('seed', None)", True),
    ("bind_branch_both_clear", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nbind()\nif params['flag']:\n    alias = {}\nelse:\n    alias = {}\nalias.pop('seed', None)", False),
    ("late_global_bind", "def bind():\n    global alias\n    alias = inputs\nglobal alias\nalias = {}\ndef mutate():\n    alias.pop('seed', None)\nbind()\nmutate()", True),
    ("ifexp_owned_first", "alias = {}\n(alias := inputs) if params['flag'] else (alias := {})\nalias.pop('seed', None)", True),
    ("ifexp_owned_else", "alias = {}\n(alias := {}) if params['flag'] else (alias := inputs)\nalias.pop('seed', None)", True),
    ("ifexp_both_clear", "alias = inputs\n(alias := {}) if params['flag'] else (alias := {})\nalias.pop('seed', None)", False),
    ("and_optional_clear", "alias = inputs\nparams['flag'] and (alias := {})\nalias.pop('seed', None)", True),
    ("or_optional_clear", "alias = inputs\nparams['flag'] or (alias := {})\nalias.pop('seed', None)", True),
    ("boolean_first_clear_executes", "alias = inputs\n(alias := {}) and params['flag']\nalias.pop('seed', None)", False),
    ("try_handler_clear", "alias = inputs\ntry:\n    params['flag']\nexcept KeyError:\n    alias = {}\nalias.pop('seed', None)", True),
    ("try_normal_clear_handler_preserves", "alias = inputs\ntry:\n    params['flag']\n    alias = {}\nexcept KeyError:\n    pass\nalias.pop('seed', None)", True),
    ("try_both_clear", "alias = inputs\ntry:\n    params['flag']\n    alias = {}\nexcept KeyError:\n    alias = {}\nalias.pop('seed', None)", False),
    ("try_late_handler_owned", "alias = {}\ntry:\n    params['flag']\nexcept KeyError:\n    alias = inputs\nexcept ValueError:\n    alias = {}\nalias.pop('seed', None)", True),
    ("try_finally_clear", "alias = inputs\ntry:\n    params['flag']\nfinally:\n    alias = {}\nalias.pop('seed', None)", False),
    ("try_body_intermediate_owned", "alias = {}\ntry:\n    alias = inputs\n    params['flag']\n    alias = {}\nexcept KeyError:\n    alias.pop('seed', None)", True),
    ("match_optional_clear", "alias = inputs\nmatch params['flag']:\n    case True:\n        alias = {}\nalias.pop('seed', None)", True),
    ("match_owned_first", "alias = {}\nmatch params['flag']:\n    case True:\n        alias = inputs\n    case False:\n        alias = {}\nalias.pop('seed', None)", True),
    ("match_owned_last", "alias = {}\nmatch params['flag']:\n    case True:\n        alias = {}\n    case False:\n        alias = inputs\nalias.pop('seed', None)", True),
    ("match_unconditional_clear", "alias = inputs\nmatch params['flag']:\n    case _:\n        alias = {}\nalias.pop('seed', None)", False),
    ("match_guard_write_reaches_later_case", "alias = {}\nmatch params['flag']:\n    case True if (alias := inputs) and False:\n        pass\n    case _:\n        alias.pop('seed', None)", True),
    ("captured_get_owned_receiver", "alias = inputs\nborrowed = alias.get((alias := 'seed'), {})\nborrowed.pop('seed', None)", True),
    ("captured_get_local_receiver", "alias = {}\nborrowed = alias.get((alias := inputs) and 'seed', {})\nborrowed.pop('seed', None)", False),
    ("captured_get_actual_argument", "def mutate(payload):\n    payload.pop('seed', None)\nalias = inputs\nmutate(alias.get((alias := 'seed'), {}))", True),
    ("nonlocal_write_then_clear", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\n    alias = {}\nbind()\nalias.pop('seed', None)", False),
    ("global_write_then_clear", "def bind():\n    global alias\n    alias = inputs\n    alias = {}\nbind()\nalias.pop('seed', None)", False),
    ("nonlocal_write_then_clear_helper", "def mutate(payload):\n    payload.pop('seed', None)\nalias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\n    alias = {}\nbind()\nmutate(alias)", False),
    ("global_write_then_clear_helper", "def mutate(payload):\n    payload.pop('seed', None)\ndef bind():\n    global alias\n    alias = inputs\n    alias = {}\nbind()\nmutate(alias)", False),
    ("nonlocal_mixed_clear", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\n    if params['flag']:\n        alias = {}\nbind()\nalias.pop('seed', None)", True),
    ("nonlocal_both_branch_clear", "alias = {}\ndef bind(flag):\n    nonlocal alias\n    alias = inputs\n    if flag:\n        alias = {}\n    else:\n        alias = {}\nbind(params['flag'])\nalias.pop('seed', None)", False),
    ("body_mutation_before_clear", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\n    alias.pop('seed', None)\n    alias = {}\nbind()\nalias.pop('seed', None)", True),
    ("return_before_clear", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\n    return\n    alias = {}\nbind()\nalias.pop('seed', None)", True),
    ("raise_before_clear", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\n    raise KeyError('seed')\n    alias = {}\ntry:\n    bind()\nexcept KeyError:\n    alias.pop('seed', None)", True),
    ("fallible_call_before_clear", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\n    fallible()\n    alias = {}\ntry:\n    bind()\nexcept Exception:\n    alias.pop('seed', None)", True),
    ("subscript_before_clear", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\n    params['flag']\n    alias = {}\ntry:\n    bind()\nexcept KeyError:\n    alias.pop('seed', None)", True),
    ("attribute_before_clear", "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\n    params.missing\n    alias = {}\ntry:\n    bind()\nexcept AttributeError:\n    alias.pop('seed', None)", True),
    ("noncalled_clear_does_not_erase", "alias = inputs\ndef clear():\n    nonlocal alias\n    alias = {}\nalias.pop('seed', None)", True),
)


def _source(body):
    text = ("alias = None\nclass Task:\n    def run_pure(self, inputs, params):\n"
            + indent(body + "\nreturn {}\n", "        "))
    compile(text, "/virtual/input_writeback.py", "exec")
    source = PythonSourceFile.parse("/virtual/input_writeback.py", "input_writeback", text)
    descriptor = NodeDescriptor(type_key="example.task", display_name="Task", description="Input writeback.",
        version="1", flow_kind="process", contract=NodeContractDescriptor())
    node = PythonSourceNode(descriptor, source.path, "Task")
    sources = build_python_source_context((node,), (source,))
    parameters = source_input_parameters(sources, node)
    seeds = {item._node: parameters.get(item.id, set()) for item in sources.helpers(node.type_key)}
    run = next(item for item in sources.symbols if item.name == "Task.run_pure")
    functions = {item.id: item._node for item in sources.symbols
        if isinstance(item._node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    call_targets = {(ref.line, ref.column): functions[ref.target] for ref in sources.references
        if ref.kind == "call" and ref.source.rpartition(":")[0] == source.path and ref.target in functions}
    return source, sources, run._node, seeds, call_targets


@pytest.mark.parametrize("label,body,owned", CASES, ids=[row[0] for row in CASES])
def test_direct_writeback_reference_facts_keep_real_binding_and_call_parameters(label, body, owned):
    source, _, run, seeds, call_targets = _source(body)
    before = ast.dump(source._tree)
    references = _input_reference_facts(run, {"inputs"}, parameter_seeds=seeds, call_targets=call_targets)
    receivers = [call.func.value for call in ast.walk(run)
                 if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "pop"]
    assert any(receiver in references for receiver in receivers) == owned, label
    assert ast.dump(source._tree) == before


@pytest.mark.parametrize("scope", ("global_state", "python_io"))
@pytest.mark.parametrize("label,body,owned", CASES, ids=[row[0] for row in CASES])
def test_formal_effects_direct_input_writeback_uses_shared_reference_facts(label, body, owned, scope):
    source, sources, _, _, _ = _source(body)
    before = ast.dump(source._tree)
    context = RuleContext(subject={"kind":"node", "type_key":"example.task"}, target="python",
        facts={"source_context":sources, "node_catalog":(), "source_owners":()})
    result = no_side_effects(context, {}, {"effect_scope":scope})
    assert result.state == "completed"
    assert any("mutate inputs" in item.message for item in result.findings) == owned, (label, scope, result.findings)
    assert ast.dump(source._tree) == before


@pytest.mark.parametrize("mutation", (
    "alias['seed'] = 1", "alias.seed = 1", "del alias['seed']", "del alias.seed",
    "alias['seed'] += 1", "alias.seed += 1", "alias.update({})", "alias.clear()",
    "[item for alias['seed'] in (0,)]", "{item for alias['seed'] in (0,)}",
    "{item: item for alias['seed'] in (0,)}", "list(item for alias['seed'] in (0,))",
    "(alias := inputs).pop('seed', None)",
))
def test_all_direct_mutation_consumers_use_owned_expression_sites(mutation):
    body = "alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nbind()\n" + mutation
    _, sources, _, _, _ = _source(body)
    result = no_side_effects(RuleContext(subject={"kind":"node", "type_key":"example.task"}, target="python",
        facts={"source_context":sources, "node_catalog":(), "source_owners":()}), {}, {"effect_scope":"global_state"})
    assert result.state == "completed"
    assert any("mutate inputs" in item.message for item in result.findings), (mutation, result.findings)


@pytest.mark.parametrize("body,owned", (
    ("alias = inputs\nalias = {}\nsink(alias)", False),
    ("if params['flag']:\n    alias = inputs\nelse:\n    alias = {}\nsink(alias)", True),
    ("if params['flag']:\n    alias = {}\nelse:\n    alias = inputs\nsink(alias)", True),
    ("alias = {}\nif False:\n    alias = inputs\nsink(alias)", False),
    ("alias = {}\ndef bind():\n    nonlocal alias\n    alias = inputs\nbind()\nsink(payload=alias)", True),
))
def test_argument_and_reference_outputs_are_recomputed_at_steady_state(body, owned):
    _, _, run, _, _ = _source(body)
    facts = _input_call_facts(run, {"inputs"})
    call = next(call for call in facts if isinstance(call.func, ast.Name) and call.func.id == "sink")
    assert any((*facts[call][0], *facts[call][1])) == owned


def test_nested_actual_parameter_seeds_do_not_taint_same_named_unrelated_function():
    body = ("def first():\n    def mutate(payload):\n        payload.pop('seed', None)\n    mutate(inputs)\n"
            "def second():\n    def mutate(payload):\n        payload.pop('seed', None)\n    mutate({})\nfirst()\nsecond()")
    _, _, run, seeds, call_targets = _source(body)
    references = _input_reference_facts(run, {"inputs"}, parameter_seeds=seeds, call_targets=call_targets)
    receivers = sorted((call.lineno, call.func.value in references) for call in ast.walk(run)
        if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "pop")
    assert [owned for _, owned in receivers] == [True, False]


def test_comprehension_outer_iterable_walrus_is_invalid_python_not_a_scope_exception():
    with pytest.raises(SyntaxError):
        compile("def run(inputs):\n    values = [item for item in (alias := {})]\n",
                "/virtual/invalid_writeback.py", "exec")


@pytest.mark.parametrize("body,owned", (
    ("alias = inputs\nborrowed = alias[(alias := 'seed')]\nborrowed.pop('seed', None)", True),
    ("alias = {}\nborrowed = alias[(alias := inputs) and 'seed']\nborrowed.pop('seed', None)", False),
    ("alias = inputs\nalias.pop((alias := 'seed'))", True),
    ("alias = {}\nalias.pop((alias := inputs) and 'seed')", False),
    ("def mutate(payload, key):\n    payload.pop(key, None)\nalias = inputs\nmutate(alias, (alias := 'seed'))", True),
    ("def mutate(payload, key):\n    payload.pop(key, None)\nalias = {}\nmutate(alias, (alias := inputs) and 'seed')", False),
))
def test_supported_expression_values_capture_receiver_and_arguments_before_later_writes(body, owned):
    _, sources, run, seeds, call_targets = _source(body)
    references = _input_reference_facts(run, {"inputs"}, parameter_seeds=seeds, call_targets=call_targets)
    receivers = [call.func.value for call in ast.walk(run)
        if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "pop"]
    assert any(receiver in references for receiver in receivers) == owned
    result = no_side_effects(RuleContext(subject={"kind":"node", "type_key":"example.task"}, target="python",
        facts={"source_context":sources, "node_catalog":(), "source_owners":()}), {}, {"effect_scope":"global_state"})
    assert any("mutate inputs" in item.message for item in result.findings) == owned
