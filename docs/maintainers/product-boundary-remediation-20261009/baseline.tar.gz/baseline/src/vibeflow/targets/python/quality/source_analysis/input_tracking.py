from __future__ import annotations

import ast
import builtins

from vibeflow.targets.python.quality.source_analysis.ast_rules import name_targets
from vibeflow.targets.python.quality.source_analysis.bindings import _comprehension_evaluation_steps, _function_definition_expressions, _function_scope_bindings
from vibeflow.targets.python.quality.source_analysis.helpers import _dict_literal_keys, _literal_subscript_key
from vibeflow.targets.python.quality.source_analysis.types import MUTATING_METHODS


def _reachable_module_helpers(node: ast.Module, node_class_name: str) -> set[str]:
    helpers = {
        stmt.name: stmt
        for stmt in node.body
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    target = next(
        (
            stmt
            for stmt in node.body
            if isinstance(stmt, ast.ClassDef) and stmt.name == node_class_name
        ),
        None,
    )
    if target is None or not helpers:
        return set()
    reachable: set[str] = set()
    pending = list(_called_module_helpers(target, helpers))
    while pending:
        name = pending.pop()
        if name in reachable:
            continue
        reachable.add(name)
        pending.extend(_called_module_helpers(helpers[name], helpers) - reachable)
    return reachable


def _trace_helper_input_parameters(
    node: ast.Module,
    node_class_name: str,
) -> dict[str, set[str]]:
    helpers = {
        stmt.name: stmt
        for stmt in node.body
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    target = next(
        (
            stmt
            for stmt in node.body
            if isinstance(stmt, ast.ClassDef) and stmt.name == node_class_name
        ),
        None,
    )
    tainted: dict[str, set[str]] = {name: set() for name in helpers}
    if target is None:
        return tainted
    sources: list[tuple[ast.FunctionDef | ast.AsyncFunctionDef, set[str]]] = [
        (stmt, {"inputs"})
        for stmt in target.body
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef))
        and any(
            arg.arg == "inputs"
            for arg in (*stmt.args.posonlyargs, *stmt.args.args, *stmt.args.kwonlyargs)
        )
    ]
    while sources:
        source, seeds = sources.pop()
        for call, input_arguments in _input_call_facts(source, seeds).items():
            if not isinstance(call.func, ast.Name) or call.func.id not in helpers:
                continue
            next_names = _tainted_helper_parameters(call, helpers[call.func.id], input_arguments)
            unseen = next_names - tainted[call.func.id]
            if unseen:
                tainted[call.func.id].update(unseen)
                sources.append((helpers[call.func.id], set(tainted[call.func.id])))
    return tainted


def source_input_parameters(sources, node) -> dict[str, set[str]]:
    """Compatibility facade for the shared source parameter facts."""
    from vibeflow.targets.python.quality.source_analysis.parameter_facts import source_parameter_facts
    return source_parameter_facts(sources, node)[0]


def _called_module_helpers(node: ast.AST, helpers: dict[str, ast.AST]) -> set[str]:
    return {
        child.func.id
        for child in ast.walk(node)
        if isinstance(child, ast.Call)
        and isinstance(child.func, ast.Name)
        and child.func.id in helpers
    }


def _input_call_facts(node: ast.FunctionDef | ast.AsyncFunctionDef, seeds: set[str]):
    """Possible input ownership of actual arguments within each lexical scope."""
    return _InputCallFacts(node, seeds).collect()


def _input_reference_facts(node: ast.FunctionDef | ast.AsyncFunctionDef, seeds: set[str], *, parameter_seeds=None,
                           call_targets=None, dictionary_parameters=None, builtin_names=None):
    """Borrowed expressions possibly referencing inputs in their actual scope."""
    facts = _InputCallFacts(node, seeds, parameter_seeds=parameter_seeds, reference_facts=True,
        call_targets=call_targets, dictionary_parameters=dictionary_parameters, builtin_names=builtin_names)
    facts.collect()
    return frozenset(facts.references)


class _ExceptionAliases:
    """Possible aliases at exceptional exits, projected to their lexical owners."""

    def __init__(self, frames):
        self.owners = tuple(frame[0] for frame in frames)
        self.states = {}

    def include(self, frames, state, kind="unknown"):
        projected = []
        for index in (0, 2, 4):
            by_owner = {frame[0]: names for frame, names in zip(frames, state[index])}
            projected.extend((tuple(set(by_owner[owner]) for owner in self.owners), set(state[index + 1])))
        projected = tuple(projected)
        previous = self.states.get(kind)
        self.states[kind] = projected if previous is None else _merge_states(previous, projected)


def _merge_states(*states):
    merged = []
    for index in (0, 2, 4):
        merge = set.union if index == 0 else set.intersection
        merged.extend((tuple(merge(*(state[index][i] for state in states))
                             for i in range(len(states[0][index]))),
                       merge(*(state[index + 1] for state in states))))
    return tuple(merged)


class _InputCallFacts(ast.NodeVisitor):
    def __init__(self, root, seeds, *, parameter_seeds=None, reference_facts=False, call_targets=None,
                 dictionary_parameters=None, builtin_names=None):
        self.root, self.seeds = root, set(seeds)
        self.parameter_seeds = parameter_seeds or {}
        self.dictionary_parameters = dictionary_parameters or {}
        self.builtin_names = builtin_names
        self.assigned = {}
        self.assigned_sites = {}
        self.writebacks = {}
        self.call_targets = call_targets
        self.nested_functions = {node for node in ast.walk(root)
            if node is not root and isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda))}
        self.bindings = {}
        self.comprehension_names = {}
        self.non_dictionary_writes = {}
        self.calls = {}
        self.references = set() if reference_facts else None

    def visit(self, node):
        if isinstance(node, ast.expr):
            self.dict_values[node] = False
        result = super().visit(node)
        if isinstance(node, ast.expr):
            owned = result is True
            self.values[node] = owned
            if self.references is not None and owned:
                self.references.add(node)
        return result

    def visit_Name(self, node):
        frame = self._declared_binding_frame(node.id)
        if (isinstance(node.ctx, ast.Load) and frame is not None
                and node.id not in self.bound.get(frame[0], ())):
            self._capture_exception_state("ordinary")
        self.dict_values[node] = self._has_binding_fact(node.id, self.dictionaries)
        return node.id in self.aliases

    def visit_Attribute(self, node):
        self.visit(node.value)
        self._capture_exception_state("ordinary" if self.dict_values[node.value] else "unknown")
        return self.values[node.value]

    def visit_Subscript(self, node):
        self.visit(node.value)
        owned = self.values[node.value]
        self.visit(node.slice)
        ordinary = self.dict_values[node.value] and isinstance(node.slice, ast.Constant)
        self._capture_exception_state("ordinary" if ordinary else "unknown")
        return owned

    def collect(self):
        # Keep assignment possibilities across branches, loops and closures.
        # Only aliases derived in the same lexical scope participate in this
        # finite fixed point; a comprehension target never becomes an alias.
        while True:
            self.changed = False
            self.aliases, self.frames = set(), []
            self.global_aliases = set(self.assigned.get(None, ()))
            self.calls = {}
            self.dict_calls = {}
            self.values = {}
            self.dict_values = {}
            self.bound, self.dictionaries = {None: set()}, {None: set()}
            self.function_writes, self.function_exits = [], []
            self.exception_states = []
            if self.references is not None:
                self.references.clear()
            self.visit(self.root)
            if not self.changed:
                return self.calls

    def visit_FunctionDef(self, node):
        for expression in _function_definition_expressions(node):
            self.visit(expression)
        bindings = self.bindings.get(node)
        if bindings is None:
            bindings = self.bindings[node] = _function_scope_bindings(node)
        local = bindings.names - bindings.global_names - bindings.nonlocal_names
        aliases = self.aliases - local - bindings.global_names
        aliases |= self.assigned.get(node, set())
        aliases |= self.parameter_seeds.get(node, set())
        if node is self.root:
            aliases |= self.seeds
        previous = self.aliases
        enclosing = self._alias_state()
        caller_exceptions = self.exception_states
        # Definition expressions execute in the caller; merely checking a
        # nested body cannot raise into a caller's active try statement.
        self.exception_states = []
        self.aliases = aliases
        self.frames.append((node, aliases, False))
        self.bound[node] = {arg.arg for arg in (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs)}
        self.bound[node].update(arg.arg for arg in (node.args.vararg, node.args.kwarg) if arg is not None)
        self.dictionaries[node] = set(self.dictionary_parameters.get(node, ()))
        # A closure reads its cell when called, not when defined. An exact
        # dictionary proof cannot survive a possible non-dictionary write to
        # that captured binding elsewhere in this selected function root.
        for owner, names in self.non_dictionary_writes.items():
            if owner is not node:
                self.dictionaries.get(owner, set()).difference_update(names)
        self.function_writes.append(set())
        self.function_exits.append(set())
        aliases.update(name for name in self.global_aliases
                       if self._declared_binding_frame(name) is None)
        if node is not self.root:
            # Bodies are checked at definition traversal, while a closure can
            # execute after a later enclosing assignment. Only histories for
            # the same lexical binding may supply that possible input value.
            for owner, names in self.assigned.items():
                for name in names:
                    frame = self._declared_binding_frame(name)
                    sites = self.assigned_sites.get((owner, name), ())
                    late = self.call_targets is None or any(
                        (site.lineno, site.col_offset) > (node.lineno, node.col_offset) for site in sites)
                    if (frame[0] if frame is not None else None) is owner and late:
                        aliases.add(name)
        try:
            if isinstance(node, ast.Lambda):
                self.visit(node.body)
            else:
                for statement in node.body:
                    self.visit(statement)
        finally:
            self._capture_writeback_exit()
            writes = self.writebacks.setdefault(node, set())
            unseen = self.function_exits.pop() - writes
            if unseen:
                writes.update(unseen)
                self.changed = True
            self.function_writes.pop()
            self.frames.pop()
            self.aliases = previous
            self.exception_states = caller_exceptions
            # Traversing a body is not proof that it has already executed.
            # Retain possible writes, but a nested overwrite cannot erase an
            # enclosing value on the caller's current path.
            if self.call_targets is None:
                self._join_alias_states(enclosing, self._alias_state())
            else:
                self._restore_alias_state(enclosing)
        if not isinstance(node, ast.Lambda):
            self._set_binding_facts(node.name, dictionary=False)

    visit_AsyncFunctionDef = visit_FunctionDef
    visit_Lambda = visit_FunctionDef

    def visit_ListComp(self, node, *, visit_iterable=True):
        steps = tuple(_comprehension_evaluation_steps(node))
        if visit_iterable:
            self.visit(steps[0][0])
        previous, enclosing = self.aliases, self._alias_state()
        bound = steps[1][1]
        self.aliases = self.aliases - bound
        self.comprehension_names[node] = bound
        self.frames.append((node, self.aliases, True))
        self.bound[node], self.dictionaries[node] = set(), set()
        targets = {generator.target for generator in node.generators}
        try:
            entry = self._alias_state()
            while True:
                before = self._alias_state()
                for expression, _ in steps[1:]:
                    self.visit(expression)
                    if expression in targets:
                        self._assign_value_facts(expression)
                self._join_alias_states(entry, self._alias_state())
                if self._alias_state() == before:
                    break
        finally:
            self.frames.pop()
            self.aliases = previous
            self._join_alias_states(enclosing, self._alias_state())

    visit_SetComp = visit_ListComp
    visit_DictComp = visit_ListComp
    def visit_GeneratorExp(self, node):
        # Only the outer iterable executes when a generator is created.
        # Review its deferred body without routing its errors to that try.
        self.visit(node.generators[0].iter)
        receivers = self.exception_states
        enclosing = self._alias_state()
        self.exception_states = []
        self.function_writes.append(set())
        self.function_exits.append(set())
        try:
            self.visit_ListComp(node, visit_iterable=False)
        finally:
            self.function_writes.pop()
            self.function_exits.pop()
            self._restore_alias_state(enclosing)
            self.exception_states = receivers

    def _has_binding_fact(self, name, facts):
        frame = self._declared_binding_frame(name)
        return name in facts.get(frame[0] if frame is not None else None, ())

    def _set_binding_facts(self, name, *, dictionary, containing=False):
        frame = self._declared_binding_frame(name, containing=containing)
        owner = frame[0] if frame is not None else None
        self.bound.setdefault(owner, set()).add(name)
        names = self.dictionaries.setdefault(owner, set())
        (names.add if dictionary else names.discard)(name)
        if not dictionary:
            writes = self.non_dictionary_writes.setdefault(owner, set())
            if name not in writes:
                writes.add(name)
                self.changed = True

    def _builtin_available(self, name):
        function = next((frame[0] for frame in reversed(self.frames) if not frame[2]), self.root)
        if self.builtin_names is not None:
            return name in self.builtin_names.get(function, ())
        # Function-only callers have no module snapshot. Preserve their
        # unshadowed builtin handling; full source rules supply exact proofs.
        return name in vars(builtins) and all(
            name not in self.bindings[frame[0]].names
            and name not in self.bindings[frame[0]].global_names
            and name not in self.bindings[frame[0]].nonlocal_names
            for frame in self.frames if not frame[2])

    def _name_can_be_unbound(self, name):
        frame = self._declared_binding_frame(name)
        if frame is not None:
            return name not in self.bound.get(frame[0], ())
        return not (self._has_binding_fact(name, self.bound) or self._builtin_available(name))

    def _declared_binding_frame(self, name, frames=None, *, containing=False):
        # None is the module owner. An external nonlocal cell can be represented
        # only inside the selected function root; never treat it as a global.
        external_nonlocal = None
        for frame in reversed(self.frames if frames is None else frames):
            node, _, comprehension = frame
            if comprehension:
                if not containing and name in self.comprehension_names[node]:
                    return frame
                continue
            bindings = self.bindings[node]
            if name in bindings.global_names:
                return None
            if name in bindings.nonlocal_names:
                if external_nonlocal is None:
                    external_nonlocal = frame
                continue
            if name in bindings.names:
                return frame
        return external_nonlocal

    def _record_alias(self, target, *, containing=False):
        if not isinstance(target, ast.Name) or not self.frames:
            return
        frame = self._declared_binding_frame(target.id, containing=containing)
        owner = frame[0] if frame is not None else None
        self._write_owned_binding(owner, target.id, target)

    def _write_owned_binding(self, owner, name, site):
        function = next(frame[0] for frame in reversed(self.frames) if not frame[2])
        deferred = self.call_targets is not None and function is not self.root and owner is not function
        if not deferred:
            known = self.assigned.setdefault(owner, set())
            sites = self.assigned_sites.setdefault((owner, name), set())
            if name not in known or site not in sites:
                known.add(name)
                sites.add(site)
                self.changed = True
        if owner is not function:
            self.function_writes[-1].add((owner, name))
        if owner is None:
            self.global_aliases.add(name)
        # A declared nonlocal/global write may escape its immediate function.
        # Preserve the possible alias only in scopes reading that same binding;
        # a sibling local, lambda parameter or comprehension target stays local.
        for index, active in enumerate(self.frames):
            frame = self._declared_binding_frame(name, self.frames[:index + 1])
            if (frame[0] if frame is not None else None) is owner:
                active[1].add(name)

    def _capture_writeback_exit(self):
        if not self.function_writes:
            return
        for owner, name in self.function_writes[-1]:
            if owner is None:
                owned = name in self.global_aliases
            else:
                frame = next((active for active in self.frames if active[0] is owner), None)
                # An external captured cell has no active containing frame.
                # Keep its existing possible ownership rather than inventing
                # a caller-local binding with the same name.
                owned = frame is None or name in frame[1]
            if owned:
                self.function_exits[-1].add((owner, name))

    def _capture_exception_state(self, kind="unknown"):
        if self.exception_states:
            self.exception_states[-1].include(self.frames, self._alias_state(), kind)
        else:
            # Only an exception escaping this function contributes a callee
            # writeback exit. A local handler/finally may still clear it.
            self._capture_writeback_exit()

    def visit_Return(self, node):
        if node.value is not None:
            self.visit(node.value)
        self._capture_writeback_exit()

    def visit_Raise(self, node):
        self.generic_visit(node)
        self._capture_exception_state()

    def _kill_alias(self, target, *, containing=False):
        if not isinstance(target, ast.Name) or not self.frames:
            return
        frame = self._declared_binding_frame(target.id, containing=containing)
        if frame is None:
            self.global_aliases.discard(target.id)
        for index, active in enumerate(self.frames):
            if self._declared_binding_frame(target.id, self.frames[:index + 1]) is frame:
                active[1].discard(target.id)

    def _alias_state(self):
        return (tuple(set(frame[1]) for frame in self.frames), set(self.global_aliases),
                tuple(set(self.bound[frame[0]]) for frame in self.frames), set(self.bound[None]),
                tuple(set(self.dictionaries[frame[0]]) for frame in self.frames), set(self.dictionaries[None]))

    def _restore_alias_state(self, state):
        frames, globals_ = state[:2]
        for frame, aliases in zip(self.frames, frames):
            frame[1].clear()
            frame[1].update(aliases)
        self.global_aliases.clear()
        self.global_aliases.update(globals_)
        for index, facts in ((2, self.bound), (4, self.dictionaries)):
            for frame, names in zip(self.frames, state[index]):
                facts[frame[0]] = set(names)
            facts[None] = set(state[index + 1])

    def _join_alias_states(self, *states):
        self._restore_alias_state(self._merged_alias_states(*states))

    def _merged_alias_states(self, *states):
        return _merge_states(*states)

    def visit_If(self, node):
        self.visit(node.test)
        if isinstance(node.test, ast.Constant):
            for statement in node.body if bool(node.test.value) else node.orelse:
                self.visit(statement)
            return
        before = self._alias_state()
        for statement in node.body:
            self.visit(statement)
        body = self._alias_state()
        self._restore_alias_state(before)
        for statement in node.orelse:
            self.visit(statement)
        self._join_alias_states(body, self._alias_state())

    def visit_IfExp(self, node):
        self.visit(node.test)
        before = self._alias_state()
        self.visit(node.body)
        body = self._alias_state()
        self._restore_alias_state(before)
        self.visit(node.orelse)
        self._join_alias_states(body, self._alias_state())

    def visit_BoolOp(self, node):
        self.visit(node.values[0])
        for expression in node.values[1:]:
            before = self._alias_state()
            self.visit(expression)
            self._join_alias_states(before, self._alias_state())

    def visit_Try(self, node):
        body_errors = self._visit_exception_region(node.body)
        # Exceptions from else/handlers cannot enter this try's own handlers.
        escaping = _ExceptionAliases(self.frames)
        self.exception_states.append(escaping)
        try:
            for statement in node.orelse:
                self.visit(statement)
            paths = [self._alias_state()]
            unmatched = dict(body_errors.states)
            for handler in node.handlers:
                if not unmatched:
                    break
                self._restore_alias_state(self._merged_alias_states(*unmatched.values()))
                self.visit(handler)
                paths.append(self._alias_state())
                if handler.type is None or self._handler_catches(handler.type, "BaseException"):
                    unmatched.clear()
                elif self._handler_catches(handler.type, "Exception"):
                    unmatched.pop("ordinary", None)
        finally:
            self.exception_states.pop()
        normal = self._merged_alias_states(*paths)
        for kind, state in unmatched.items():
            escaping.include(self.frames, state, kind)
        pending = escaping.states
        if node.finalbody:
            # Apply finally to normal and pending-exception paths separately.
            # Its clear must reach an outer handler, and an error in finally
            # must retain the state at that operation rather than its end.
            self._restore_alias_state(normal)
            final_errors = self._visit_exception_region(node.finalbody)
            normal = self._alias_state()
            continued = _ExceptionAliases(self.frames)
            for kind, state in pending.items():
                self._restore_alias_state(state)
                pending_errors = self._visit_exception_region(node.finalbody)
                continued.include(self.frames, self._alias_state(), kind)
                for error_kind, error_state in pending_errors.states.items():
                    final_errors.include(self.frames, error_state, error_kind)
            for kind, state in final_errors.states.items():
                continued.include(self.frames, state, kind)
            pending = continued.states
        for kind, state in pending.items():
            self._restore_alias_state(state)
            self._capture_exception_state(kind)
        self._restore_alias_state(normal)

    def _handler_catches(self, expression, name):
        if isinstance(expression, ast.Tuple):
            return any(self._handler_catches(item, name) for item in expression.elts)
        return isinstance(expression, ast.Name) and expression.id == name and self._builtin_available(name)

    def visit_ExceptHandler(self, node):
        if node.type is not None:
            self.visit(node.type)
        if node.name is not None:
            self._kill_alias(ast.Name(id=node.name, ctx=ast.Store()))
            self._set_binding_facts(node.name, dictionary=False)
        for statement in node.body:
            self.visit(statement)
        if node.name is not None:
            self._delete_binding(ast.Name(id=node.name, ctx=ast.Del()))

    def _visit_exception_region(self, statements):
        receiver = _ExceptionAliases(self.frames)
        self.exception_states.append(receiver)
        try:
            for statement in statements:
                self.visit(statement)
        finally:
            self.exception_states.pop()
        return receiver

    visit_TryStar = visit_Try

    def visit_Match(self, node):
        self.visit(node.subject)
        incoming = self._alias_state()
        paths = []
        exhaustive = False
        for case in node.cases:
            self._restore_alias_state(incoming)
            self.visit(case.pattern)
            if case.guard is not None:
                self.visit(case.guard)
                # A failed guard can still write a binding before a later
                # case is considered.
                incoming = self._merged_alias_states(incoming, self._alias_state())
            elif isinstance(case.pattern, ast.MatchAs) and case.pattern.pattern is None:
                exhaustive = True
            for statement in case.body:
                self.visit(statement)
            paths.append(self._alias_state())
        if not exhaustive:
            paths.append(incoming)
        self._join_alias_states(*paths)

    def _visit_loop_body(self, node):
        entry = self._alias_state()
        while True:
            before = self._alias_state()
            if isinstance(node, (ast.For, ast.AsyncFor)):
                self.visit(node.target)
                self._kill_alias(node.target)
                self._assign_value_facts(node.target)
            else:
                self.visit(node.test)
            for statement in node.body:
                self.visit(statement)
            self._join_alias_states(entry, self._alias_state())
            if self._alias_state() == before:
                break
        before_else = self._alias_state()
        for statement in node.orelse:
            self.visit(statement)
        self._join_alias_states(before_else, self._alias_state())

    def visit_For(self, node):
        self.visit(node.iter)
        self._capture_exception_state()
        self._visit_loop_body(node)

    visit_AsyncFor = visit_For

    def visit_While(self, node):
        if isinstance(node.test, ast.Constant) and not bool(node.test.value):
            self.visit(node.test)
            for statement in node.orelse:
                self.visit(statement)
            return
        self._visit_loop_body(node)

    def visit_Assign(self, node):
        self.visit(node.value)
        owned = self.values[node.value]
        for target in node.targets:
            self.visit(target)
            if owned:
                self._record_alias(target)
            else:
                self._kill_alias(target)
            self._assign_value_facts(target, self.dict_values[node.value])

    def visit_AnnAssign(self, node):
        if node.value is not None:
            self.visit(node.value)
            if self.values[node.value]:
                self._record_alias(node.target)
            else:
                self._kill_alias(node.target)
            self._assign_value_facts(node.target, self.dict_values[node.value])
        self.visit(node.target)

    def visit_NamedExpr(self, node):
        self.visit(node.value)
        owned = self.values[node.value]
        if owned:
            self._record_alias(node.target, containing=True)
        else:
            self._kill_alias(node.target, containing=True)
        self._assign_value_facts(node.target, self.dict_values[node.value], containing=True)
        self.dict_values[node] = self.dict_values[node.value]
        return owned

    def _assign_value_facts(self, target, dictionary=False, *, containing=False):
        if isinstance(target, ast.Name):
            self._set_binding_facts(target.id, dictionary=dictionary, containing=containing)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for element in target.elts:
                self._assign_value_facts(element, containing=containing)
        elif isinstance(target, ast.Starred):
            self._assign_value_facts(target.value, containing=containing)

    def _delete_binding(self, target):
        if isinstance(target, ast.Name):
            frame = self._declared_binding_frame(target.id)
            owner = frame[0] if frame is not None else None
            self._kill_alias(target)
            self.bound.setdefault(owner, set()).discard(target.id)
            self.dictionaries.setdefault(owner, set()).discard(target.id)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for element in target.elts:
                self._delete_binding(element)

    def visit_Delete(self, node):
        for target in node.targets:
            self.visit(target)
            self._delete_binding(target)

    def visit_Import(self, node):
        for item in node.names:
            self._set_binding_facts(item.asname or item.name.split(".")[0], dictionary=False)

    def visit_ImportFrom(self, node):
        for item in node.names:
            if item.name != "*":
                self._set_binding_facts(item.asname or item.name, dictionary=False)

    def visit_ClassDef(self, node):
        self.generic_visit(node)
        self._set_binding_facts(node.name, dictionary=False)

    def visit_BinOp(self, node):
        self.generic_visit(node)
        self._capture_exception_state()

    visit_UnaryOp = visit_BinOp
    visit_Await = visit_BinOp
    visit_Starred = visit_BinOp

    def visit_Compare(self, node):
        self.visit(node.left)
        for comparator in node.comparators:
            self.visit(comparator)
            self._capture_exception_state()

    def visit_Dict(self, node):
        for key, value in zip(node.keys, node.values):
            if key is not None:
                self.visit(key)
            self.visit(value)
            if key is None or not isinstance(key, ast.Constant):
                self._capture_exception_state()
        self.dict_values[node] = True

    def visit_Call(self, node):
        self.visit(node.func)
        target = (None if self.call_targets is None else
                  self.call_targets.get((node.lineno, node.col_offset + 1)))
        if (isinstance(node.func, ast.Name) and self._declared_binding_frame(node.func.id) is None
                and self._name_can_be_unbound(node.func.id)):
            self._capture_exception_state("ordinary")
        owned = (isinstance(node.func, ast.Attribute) and node.func.attr == "get"
                 and self.values[node.func.value])
        arguments, keywords, dict_arguments, dict_keywords = [], [], [], []
        for argument in node.args:
            self.visit(argument)
            arguments.append(self.values[argument])
            dict_arguments.append(self.dict_values[argument])
        for keyword in node.keywords:
            self.visit(keyword.value)
            keywords.append(self.values[keyword.value])
            dict_keywords.append(self.dict_values[keyword.value])
            if keyword.arg is None:
                self._capture_exception_state()
        previous = self.calls.get(node)
        if previous is not None:
            arguments = [current or earlier for current, earlier in zip(arguments, previous[0])]
            keywords = [current or earlier for current, earlier in zip(keywords, previous[1])]
        self.calls[node] = tuple(arguments), tuple(keywords)
        previous_dicts = self.dict_calls.get(node)
        if previous_dicts is not None:
            dict_arguments = [current and earlier for current, earlier in zip(dict_arguments, previous_dicts[0])]
            dict_keywords = [current and earlier for current, earlier in zip(dict_keywords, previous_dicts[1])]
        self.dict_calls[node] = tuple(dict_arguments), tuple(dict_keywords)
        if (isinstance(node.func, ast.Name) and node.func.id in {
                "list", "tuple", "set", "frozenset", "dict", "all", "any", "sum", "sorted"}
                and self._builtin_available(node.func.id)):
            for argument in node.args:
                if isinstance(argument, ast.GeneratorExp):
                    self.visit_ListComp(argument, visit_iterable=False)
        self._capture_exception_state()
        if self.call_targets is not None:
            if target in self.nested_functions:
                # SourceContext remains the authority for the actual callee.
                # Replay only nested writes whose binding owner belongs to
                # this same selected root; independent helpers retain their
                # separate parameter propagation and review.
                for owner, name in tuple(self.writebacks.get(target, ())):
                    self._write_owned_binding(owner, name, node)
        self._capture_exception_state()
        return owned


def _tainted_helper_parameters(call, helper, input_arguments, *, bound_method=False) -> set[str]:
    positional = (*helper.args.posonlyargs, *helper.args.args)
    arguments, keywords = input_arguments
    if bound_method:
        arguments = (False, *arguments)
    tainted = {positional[index].arg for index, owned in enumerate(arguments)
               if owned and index < len(positional)}
    parameters = {arg.arg for arg in (*positional, *helper.args.kwonlyargs)}
    for keyword, owned in zip(call.keywords, keywords):
        if keyword.arg in parameters and owned:
            tainted.add(str(keyword.arg))
    return tainted


class _NodeDataTrackingMixin:
    def _track_output_literal(self, node: ast.Assign) -> None:
        if not isinstance(node.value, ast.Dict):
            return
        keys, dynamic = _dict_literal_keys(node.value)
        if dynamic or keys is None:
            return
        for target in name_targets(node.targets):
            self._output_dicts[target.id] = keys

    def _track_output_key_assignment(self, node: ast.Assign) -> None:
        for target in node.targets:
            if isinstance(target, ast.Subscript) and isinstance(target.value, ast.Name) and target.value.id in self._output_dicts:
                self._record_output_key(target, node)

    def _record_output_key(self, target: ast.Subscript, node: ast.Assign) -> None:
        key = _literal_subscript_key(target)
        if key and isinstance(target.value, ast.Name):
            self._output_dicts[target.value.id].add(key)
        else:
            self._add("dynamic_output_key", "output dict assignment key must be a string literal", node, suggested_fix_type="fix_contract")

    def _check_input_mutation_call(self, node: ast.Call) -> None:
        if not isinstance(node.func, ast.Attribute):
            return
        if self._is_node_input_reference(node.func.value) and node.func.attr in MUTATING_METHODS:
            self._add("input_mutation", f"node must not mutate inputs via {node.func.attr}", node, suggested_fix_type="fix_node")

    def _check_params_get_call(self, node: ast.Call) -> None:
        if not isinstance(node.func, ast.Attribute) or not isinstance(node.func.value, ast.Name):
            return
        if node.func.value.id == "params" and node.func.attr == "get" and node.args:
            self._check_params_key_node(node.args[0], node)

    def _check_params_key_node(self, key_node: ast.AST, node: ast.Call) -> None:
        del key_node, node

    def _check_assignment_target(self, target: ast.AST, node: ast.AST) -> None:
        if self._target_mutates_node_input(target):
            self._add("input_mutation", "node must not mutate inputs", node, suggested_fix_type="fix_node")
        if self._ambient_target(target):
            return
        if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name) and target.value.id != "self":
            self._add("monkey_patch", "assigning to external object attributes is forbidden", node, suggested_fix_type="fix_node")

    def _target_mutates_node_input(self, target: ast.AST) -> bool:
        return isinstance(target, (ast.Subscript, ast.Attribute)) and self._is_node_input_reference(target.value)

    def _is_node_input_reference(self, node: ast.AST) -> bool:
        return self._is_owned_input_reference(node)

    def _return_keys(self, value: ast.AST | None) -> tuple[set[str] | None, bool]:
        if isinstance(value, ast.Dict):
            return _dict_literal_keys(value)
        if isinstance(value, ast.Name) and value.id in self._output_dicts:
            return set(self._output_dicts[value.id]), False
        return None, True


def _reference_root_name(node: ast.AST) -> str:
    while isinstance(node, (ast.Attribute, ast.Subscript)):
        node = node.value
    return node.id if isinstance(node, ast.Name) else ""
