"""Finite parameter proofs over the source snapshot's actual function calls."""

from __future__ import annotations

import ast
import builtins

from vibeflow.targets.python.quality.source_analysis.bindings import (
    _FunctionBindingCollector,
    _comprehension_evaluation_steps,
    _function_definition_expressions,
    _function_scope_bindings,
)
from vibeflow.targets.python.quality.source_analysis.input_tracking import (
    _InputCallFacts,
    _tainted_helper_parameters,
)


_FUNCTIONS = (ast.FunctionDef, ast.AsyncFunctionDef)


def source_parameter_facts(sources, node):
    """Return input, exact-dictionary and unshadowed-builtin parameter facts.

    Callees come exclusively from SourceContext references. Input ownership is
    a possible value (a union), whereas an exact dictionary is a proof required
    at every reviewed incoming call (an intersection). Dictionary forwarding
    uses a conservative least fixed point; an unsupported recursive proof stays
    unknown rather than becoming a type assumption.
    """
    symbols = {item.id: item for item in sources.helpers(node.type_key)
               if isinstance(item._node, _FUNCTIONS)}
    function_nodes = {symbol._node for symbol in symbols.values()}
    contained = {child for symbol in symbols.values() for child in ast.walk(symbol._node)
                 if child is not symbol._node and child in function_nodes}
    # A nested definition must be inspected with its enclosing lexical frames.
    # Replaying it independently would manufacture an extra unknown incoming
    # value for the same call site, losing captured dictionary proofs.
    roots = tuple(symbol for symbol in symbols.values() if symbol._node not in contained)
    builtin_names = _source_builtin_names(sources)
    input_seeds, dictionary_seeds = {}, {}
    implementation = sources.symbol(node.path, node.symbol)
    run_pure = (sources.class_members(implementation).get("run_pure")
                if implementation is not None else None)
    if run_pure is not None and run_pure.id in symbols:
        parameters = _parameter_names(run_pure._node)
        input_seeds[run_pure.id] = {"inputs"} & parameters
        # The canonical Node runtime supplies params as a fresh exact dict.
        # No other function parameter receives this proof from its spelling.
        dictionary_seeds[run_pure.id] = {"params"} & parameters

    references_by_path = {}
    for reference in sources.references:
        if reference.kind == "call" and reference.target in symbols:
            references_by_path.setdefault(reference.source.rpartition(":")[0], {})[
                (reference.line, reference.column)] = reference.target

    dictionaries = {identity: set() for identity in symbols}
    while True:
        incoming = {identity: [set(names)] for identity, names in dictionary_seeds.items()}
        dictionary_parameters = {symbol._node: dictionaries[identity]
                                 for identity, symbol in symbols.items()}
        for symbol in roots:
            references = references_by_path.get(symbol.path, {})
            facts = _InputCallFacts(symbol._node, set(),
                dictionary_parameters=dictionary_parameters, builtin_names=builtin_names,
                call_targets={site: symbols[target]._node for site, target in references.items()})
            facts.collect()
            for call, arguments in facts.dict_calls.items():
                target = symbols.get(references.get((call.lineno, call.col_offset + 1)))
                if target is not None:
                    incoming.setdefault(target.id, []).append(_dictionary_arguments(
                        call, target._node, arguments, bound_method=_bound_method(call)))
        following = {}
        for identity in symbols:
            sites = incoming.get(identity, ())
            proven = set.intersection(*sites) if sites else set()
            following[identity] = proven
        if following == dictionaries:
            break
        dictionaries = following

    dictionary_parameters = {symbol._node: dictionaries[identity]
                             for identity, symbol in symbols.items()}
    owned = {identity: set(input_seeds.get(identity, ())) for identity in symbols}
    while True:
        following = {identity: set(names) for identity, names in owned.items()}
        parameter_seeds = {symbol._node: owned[identity] for identity, symbol in symbols.items()}
        for symbol in roots:
            references = references_by_path.get(symbol.path, {})
            facts = _InputCallFacts(symbol._node, owned[symbol.id],
                parameter_seeds=parameter_seeds, dictionary_parameters=dictionary_parameters,
                builtin_names=builtin_names,
                call_targets={site: symbols[target]._node for site, target in references.items()})
            for call, arguments in facts.collect().items():
                target = symbols.get(references.get((call.lineno, call.col_offset + 1)))
                if target is not None:
                    following[target.id].update(_tainted_helper_parameters(
                        call, target._node, arguments, bound_method=_bound_method(call)))
        if following == owned:
            return owned, dictionary_parameters, builtin_names
        owned = following


def _parameter_names(function):
    return {argument.arg for argument in (*function.args.posonlyargs, *function.args.args,
                                         *function.args.kwonlyargs)}


def _bound_method(call):
    return (isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name)
            and call.func.value.id in {"self", "cls"})


def _dictionary_arguments(call, function, argument_facts, *, bound_method):
    """Prove ordinary parameters; unknown argument expansion proves nothing."""
    if any(isinstance(argument, ast.Starred) for argument in call.args) or any(
            keyword.arg is None for keyword in call.keywords):
        return set()
    positional = (*function.args.posonlyargs, *function.args.args)
    arguments, keywords = argument_facts
    if bound_method:
        arguments = (False, *arguments)
    supplied = {positional[index].arg: exact for index, exact in enumerate(arguments)
                if index < len(positional)}
    names = _parameter_names(function)
    supplied.update({keyword.arg: exact for keyword, exact in zip(call.keywords, keywords)
                     if keyword.arg in names})
    defaults = dict(zip((argument.arg for argument in positional[-len(function.args.defaults):]),
                        function.args.defaults)) if function.args.defaults else {}
    defaults.update({argument.arg: default for argument, default in zip(
        function.args.kwonlyargs, function.args.kw_defaults) if default is not None})
    return {name for name in names if supplied.get(name, isinstance(defaults.get(name), ast.Dict))}


class _BuiltinBindings(_FunctionBindingCollector):
    """Use the shared lexical collector, including uncertain wildcard imports."""

    def __init__(self):
        super().__init__()
        self.wildcard = False

    def visit_ImportFrom(self, node):
        self.wildcard |= any(alias.name == "*" for alias in node.names)
        super().visit_ImportFrom(node)

    def visit_MatchAs(self, node):
        if node.name is not None:
            self.names.add(node.name)
        self.generic_visit(node)

    visit_MatchStar = visit_MatchAs

    def visit_MatchMapping(self, node):
        if node.rest is not None:
            self.names.add(node.rest)
        self.generic_visit(node)


def _scope_bindings(node):
    collector = _BuiltinBindings()
    if isinstance(node, (*_FUNCTIONS, ast.Lambda)):
        shared = _function_scope_bindings(node)
        collector.names.update(shared.names)
        collector.global_names.update(shared.global_names)
        collector.nonlocal_names.update(shared.nonlocal_names)
        statements = (node.body,) if isinstance(node, ast.Lambda) else node.body
    else:
        statements = node.body
    for statement in statements:
        collector.visit(statement)
    return collector


def _source_builtin_names(sources):
    names = {}
    for source in sources.files:
        if source._tree is None:
            continue
        bindings = _scope_bindings(source._tree)
        shadowed = set(bindings.names)
        for child in ast.walk(source._tree):
            if isinstance(child, (*_FUNCTIONS, ast.Lambda)):
                declarations = _scope_bindings(child)
                # A source-visible write to a module binding invalidates its
                # builtin proof even when it appears in a nested function.
                shadowed.update(declarations.names & declarations.global_names)
        module_names = set() if bindings.wildcard else set(dir(builtins)) - shadowed
        collector = _BuiltinNames(module_names, names)
        collector.visit(source._tree)
    return names


class _BuiltinNames(ast.NodeVisitor):
    def __init__(self, module_names, names):
        self.module_names, self.names = module_names, names
        self.visible = self.closure_visible = module_names

    def visit_FunctionDef(self, node):
        for expression in _function_definition_expressions(node):
            self.visit(expression)
        bindings = _scope_bindings(node)
        visible = (set() if bindings.wildcard else
                   self.closure_visible - bindings.names - bindings.global_names)
        visible |= bindings.global_names & self.module_names
        self.names[node] = frozenset(visible)
        previous = self.visible, self.closure_visible
        self.visible = self.closure_visible = visible
        try:
            if isinstance(node, ast.Lambda):
                self.visit(node.body)
            else:
                for statement in node.body:
                    self.visit(statement)
        finally:
            self.visible, self.closure_visible = previous

    visit_AsyncFunctionDef = visit_FunctionDef
    visit_Lambda = visit_FunctionDef

    def visit_ClassDef(self, node):
        for expression in (*node.decorator_list, *node.bases,
                           *(keyword.value for keyword in node.keywords)):
            self.visit(expression)
        previous = self.visible
        bindings = _scope_bindings(node)
        self.visible = set() if bindings.wildcard else self.visible - bindings.names
        try:
            # Methods close over enclosing functions, never class locals.
            for statement in node.body:
                self.visit(statement)
        finally:
            self.visible = previous

    def visit_ListComp(self, node):
        steps = tuple(_comprehension_evaluation_steps(node))
        self.visit(steps[0][0])
        previous = self.visible, self.closure_visible
        self.visible = self.visible - steps[1][1]
        self.closure_visible = self.closure_visible - steps[1][1]
        try:
            for expression, _ in steps[1:]:
                self.visit(expression)
        finally:
            self.visible, self.closure_visible = previous

    visit_SetComp = visit_ListComp
    visit_DictComp = visit_ListComp
    visit_GeneratorExp = visit_ListComp
