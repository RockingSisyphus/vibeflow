from __future__ import annotations
from vibeflow.tooling.presentation.node_presentation import registry_descriptor, resolve_presentation

import textwrap
from typing import TYPE_CHECKING
from typing import Any, Mapping

from vibeflow.core.compiler import CompiledGraph
from vibeflow.core.contracts import providers_to_dicts, requirements_to_dicts
from vibeflow.tooling.application.python.presentation.helpers import effective_graph_for_render, compile_for_render, node_flow_kind, node_is_external, nodeset_for_node
from vibeflow.tooling.application.python.presentation.review_model import node_review_effect_scope

from vibeflow.tooling.application.python.presentation.mermaid.labels import (
    _async_semantic_lines,
    _comment_text,
    _edge_contract_text,
    _edge_style,
    _escape_edge_label,
    _escape_label,
    _expanded_nodeset_title,
    _health_findings,
    _join_label_lines,
    _join_label_sections,
    _loop_stop_text,
    _mapping_items,
    _node_metadata_lines,
    _node_shape,
    _nodeset_node_ids,
    _resource_label,
    _rendered_resources_payload,
    _resources_payload,
    _safe_id,
    _section_label,
    _source_lines,
)
from vibeflow.core.flow import GraphConfig, LOOP_NODE_TYPES, NodeSpec, NodesetSpec, STATUS_PLANNED
from vibeflow.core.constants import EFFECT_SCOPE_GLOBAL_STATE, EFFECT_SCOPE_NONE, FLOW_KIND_DATA_STORE, FLOW_KIND_DECISION, FLOW_KIND_DOCUMENT, FLOW_KIND_GLOBAL_STATE, FLOW_KIND_IO, FLOW_KIND_PREDEFINED, FLOW_KIND_PREPARATION, FLOW_KIND_PROCESS, FLOW_KIND_TERMINAL
from vibeflow.core.planned import effective_planned_behavior, planned_behavior_label
from vibeflow.targets.python.runtime.helpers import has_planned, planned_items
from vibeflow.tooling.application.python.presentation.style import MERMAID_MAIN_CLASS_ORDER, mermaid_class_def_lines

if TYPE_CHECKING:
    from vibeflow.targets.python.project.registry import NodeRegistry


MERMAID_LAYOUT_DEFAULT = "default"
MERMAID_LAYOUT_REVIEW_COLUMNS = "review-columns"
_MERMAID_LAYOUTS = {MERMAID_LAYOUT_DEFAULT, MERMAID_LAYOUT_REVIEW_COLUMNS}
_SECTION_SEPARATOR_WIDTH = 10
_MERMAID_CLOUD_NODE_CLASS = "vibeflowCloudNode"


def export_mermaid(
    graph: GraphConfig,
    *,
    expand_nodesets: bool = False,
    compiled: CompiledGraph | None = None,
    registry: NodeRegistry | None = None,
    health_report: object | None = None,
    resources: object | None = None,
    show_contract: bool = True,
    show_semantics: bool = True,
    show_findings: bool = True,
    mermaid_layout: str = MERMAID_LAYOUT_DEFAULT,
    prepared=None,
) -> str:
    from vibeflow.tooling.application.python.presentation.prepared import prepare_python_presentation

    prepared = prepared or prepare_python_presentation(graph, compiled=compiled, registry=registry, resources=resources)
    registry = prepared.registry
    # Shared facts do not opt workflow fragments into drawing resources.
    # The caller's resources selection controls this rendering only.
    graph, actual_compiled = effective_graph_for_render(
        graph,
        compiled,
        registry,
        prepared=prepared,
    )
    renderer = _MermaidRenderer(
        expand_nodesets=expand_nodesets,
        registry=registry,
        health_report=health_report,
        resources=resources,
        show_contract=show_contract,
        show_semantics=show_semantics,
        show_findings=show_findings,
        mermaid_layout=mermaid_layout,
    )
    renderer.prepared = prepared
    return renderer.render(graph, actual_compiled)


def compiled_graph_payload(graph: GraphConfig, compiled: CompiledGraph, *, resources: object | None = None) -> dict[str, object]:
    payload: dict[str, object] = {
        "nodes": [
            {
                "id": node.id,
                "type_used": node.type_used,
                "requires": requirements_to_dicts(node.requires),
                "provides": providers_to_dicts(node.provides),
                "status": node.status,
                "planned_behavior": node.planned_behavior.to_dict(),
                "flow_kind": node_flow_kind(node, compiled),
                "effect_scope": node_review_effect_scope(graph, node, None, compiled=compiled),
                "runtime_dispatch": _runtime_dispatch_label(node, compiled),
                "execution_lock": (
                    node.execution_lock.to_dict()
                    if node.execution_lock is not None
                    else None
                ),
                "effective_execution_lock": _effective_execution_lock_payload(
                    graph,
                    node,
                    graph_lock_scope="root",
                ),
                "metadata": node.metadata.to_dict(),
                "style": node.style.to_dict(),
                "similar_to": node.similar_to.to_dict(),
                "root_id": graph.root_id,
                "root_path": graph.root_path,
                "source_path": graph.source_path,
            }
            for node in graph.nodes
        ],
        "explicit_edges": [list(edge.pair) for edge in compiled.explicit_edges],
        "data_edges": [list(edge.pair) for edge in compiled.data_edges],
        "effective_edges": [{"from": edge.source, "to": edge.target, "when": edge.when} for edge in compiled.effective_edges],
        "mainline_edges": [list(edge.pair) for edge in compiled.mainline_edges],
        "data_bypass_edges": [list(edge.pair) for edge in compiled.data_bypass_edges],
        "async_edges": [list(edge.pair) for edge in compiled.async_edges],
        "schedule_edges": [list(edge.pair) for edge in compiled.schedule_edges],
        "transfer_edges": [list(edge.pair) for edge in compiled.transfer_edges],
        "providers": dict(compiled.providers),
        "consumers": {key: list(values) for key, values in compiled.consumers.items()},
        "nodesets": sorted(graph.nodesets),
        "nodeset_sources": [
            {
                "type_key": nodeset.type_key,
                "root_id": nodeset.root_id,
                "root_path": nodeset.root_path,
                "source_path": nodeset.source_path,
            }
            for nodeset in sorted(graph.nodesets.values(), key=lambda item: item.type_key)
        ],
        "planned": [dict(item) for item in planned_items(graph)],
        "production_ready": not has_planned(graph),
        "execution_lock": (
            graph.execution_lock.to_dict()
            if graph.execution_lock is not None
            else None
        ),
        "contains_global_state": compiled.contains_global_state,
    }
    if graph.root_id or graph.root_path or graph.source_path:
        payload["graph_source"] = {"root_id": graph.root_id, "root_path": graph.root_path, "source_path": graph.source_path}
    resource_payload = _resources_payload(resources)
    if _resource_payload_has_planned(resource_payload):
        payload["production_ready"] = False
    if resource_payload:
        payload["resources"] = resource_payload
    return payload


def _resource_payload_has_planned(
    payload: Mapping[str, object],
) -> bool:
    groups: list[object] = [
        payload.get("plugins", ()),
        payload.get("host_extensions", ()),
    ]
    base_lib = payload.get("base_lib", {})
    if isinstance(base_lib, Mapping):
        groups.append(base_lib.get("modules", ()))
    return any(
        isinstance(item, Mapping)
        and str(item.get("status", "implemented")) == STATUS_PLANNED
        for group in groups
        if isinstance(group, (list, tuple))
        for item in group
    )


class _MermaidRenderer:
    def __init__(
        self,
        *,
        expand_nodesets: bool,
        registry: NodeRegistry | None,
        health_report: object | None,
        resources: object | None,
        show_contract: bool,
        show_semantics: bool,
        show_findings: bool,
        mermaid_layout: str,
    ) -> None:
        if mermaid_layout not in _MERMAID_LAYOUTS:
            raise ValueError(f"unknown Mermaid layout: {mermaid_layout}")
        self.expand_nodesets = expand_nodesets
        self.registry = registry
        self.health_report = health_report
        self.resources = resources
        self.show_contract = show_contract
        self.show_semantics = show_semantics
        self.show_findings = show_findings
        self.mermaid_layout = mermaid_layout
        self.node_ids: dict[str, str] = {}
        self.nodeset_node_ids: dict[str, str] = {}
        self.node_classes: dict[str, str] = {}
        self.edge_index = 0

    def render(self, graph: GraphConfig, compiled: CompiledGraph) -> str:
        self.node_ids = {node.id: _safe_id(node.id) for node in graph.nodes}
        self.nodeset_node_ids = _nodeset_node_ids(graph, self.node_ids)
        self.node_classes = self._finding_classes(graph, compiled) if self.show_findings else {}
        self.edge_index = 0
        if self.mermaid_layout == MERMAID_LAYOUT_REVIEW_COLUMNS:
            return self._render_review_columns(graph, compiled)
        lines = [
            "flowchart TD",
            *(f"  {line}" for line in mermaid_class_def_lines(MERMAID_MAIN_CLASS_ORDER)),
        ]
        self._render_graph_body(lines, graph, compiled, prefix="", indent="  ", visited_nodesets=())
        self._render_edges(lines, graph, compiled, prefix="", indent="  ")
        self._render_resources(lines, graph=graph, indent="  ")
        if self.show_findings:
            self._render_findings(lines, graph, compiled, indent="  ")
        return "\n".join(lines) + "\n"

    def _render_review_columns(self, graph: GraphConfig, compiled: CompiledGraph) -> str:
        from vibeflow.tooling.application.python.presentation.mermaid.review import render_review_columns

        return render_review_columns(self, graph, compiled)

    def _render_graph_body(
        self,
        lines: list[str],
        graph: GraphConfig,
        compiled: CompiledGraph,
        *,
        prefix: str,
        indent: str,
        visited_nodesets: tuple[str, ...],
        expand_inline: bool | None = None,
        inherited_lock: tuple[str, str, bool] | None = None,
        graph_lock_scope: str = "root",
    ) -> None:
        should_expand = self.expand_nodesets if expand_inline is None else expand_inline
        graph_lock = (
            (graph.execution_lock.key, graph_lock_scope, False)
            if graph.execution_lock is not None
            else inherited_lock
        )
        for node in graph.nodes:
            node_id = _safe_id(f"{prefix}{node.id}")
            nodeset = nodeset_for_node(graph, node)
            effective_lock = (
                (
                    node.execution_lock.key,
                    "block" if nodeset is not None else "node",
                    False,
                )
                if node.execution_lock is not None
                else (
                    (graph_lock[0], graph_lock[1], True)
                    if graph_lock is not None
                    else None
                )
            )
            if nodeset is None:
                is_external = self._node_is_external(node)
                flow_kind = node_flow_kind(node, compiled) or FLOW_KIND_PROCESS
                preferred_class = self._preferred_class_for_node(flow_kind=flow_kind, is_external=is_external)
                class_name = self._class_for_node(node_id, preferred_class=preferred_class, planned=node.status == STATUS_PLANNED)
                presentation = self._presentation(node, node_id, native_class=preferred_class, status_class=class_name, flow_kind=flow_kind)
                lines.append(
                    f"{indent}{_node_shape(node_id, self._node_label(node, graph, compiled, effective_lock=effective_lock, is_external=is_external), flow_kind, shape=presentation.shape)}"
                )
                if class_name:
                    lines.append(f"{indent}class {node_id} {class_name};")
                if presentation.shape == "cloud":
                    lines.append(f"{indent}class {node_id} {_MERMAID_CLOUD_NODE_CLASS};")
                if is_external:
                    lines.append(f"{indent}class {node_id} externalBoundary;")
                lines.append(f"{indent}style {node_id} {presentation.mermaid_style()};")
                continue
            flow_kind = node_flow_kind(node, compiled) or nodeset.flow_kind
            is_loop = node.type_used in LOOP_NODE_TYPES
            native_class = "loopNode" if is_loop else "nodesetNode"
            class_name = self._class_for_node(node_id, preferred_class=native_class, planned=node.status == STATUS_PLANNED or nodeset.status == STATUS_PLANNED)
            presentation = self._presentation(node, node_id, native_class=native_class, status_class=class_name, flow_kind=flow_kind)
            label = (
                self._loop_label(
                    node,
                    nodeset,
                    graph,
                    compiled,
                    effective_lock=effective_lock,
                )
                if is_loop
                else self._nodeset_label(
                    node,
                    nodeset,
                    graph,
                    compiled,
                    effective_lock=effective_lock,
                )
            )
            lines.append(f"{indent}{_node_shape(node_id, label, flow_kind, shape=presentation.shape)}")
            if class_name:
                lines.append(f"{indent}class {node_id} {class_name};")
            if presentation.shape == "cloud":
                lines.append(f"{indent}class {node_id} {_MERMAID_CLOUD_NODE_CLASS};")
            lines.append(f"{indent}style {node_id} {presentation.mermaid_style()};")
            if not should_expand or not nodeset.expand:
                continue
            group_id = _safe_id(f"{prefix}{node.id}__expanded")
            group_title = _expanded_nodeset_title(node, nodeset)
            lines.append(f'{indent}subgraph {group_id}["{_escape_label(group_title)}"]')
            if nodeset.type_key in visited_nodesets:
                lines.append(f"{indent}  %% recursive nodeset expansion skipped: {nodeset.type_key}")
            else:
                nested_compiled = compile_for_render(nodeset.graph, None, self.registry, prepared=self.prepared)
                nested_prefix = f"{prefix}{node.id}__"
                self._render_graph_body(
                    lines,
                    nodeset.graph,
                    nested_compiled,
                    prefix=nested_prefix,
                    indent=f"{indent}  ",
                    visited_nodesets=(*visited_nodesets, nodeset.type_key),
                    expand_inline=True,
                    inherited_lock=(
                        (effective_lock[0], effective_lock[1], True)
                        if effective_lock is not None
                        else None
                    ),
                    graph_lock_scope="block",
                )
                self._render_edges(lines, nodeset.graph, nested_compiled, prefix=nested_prefix, indent=f"{indent}  ")
            lines.append(f"{indent}end")

    def _render_edges(self, lines: list[str], graph: GraphConfig, compiled: CompiledGraph, *, prefix: str, indent: str) -> None:
        for edge in compiled.effective_edges:
            source_id = _safe_id(f"{prefix}{edge.source}")
            target_id = _safe_id(f"{prefix}{edge.target}")
            label_text = self._edge_label(graph, edge)
            label = f'|"{_escape_edge_label(label_text)}"|' if label_text else ""
            self._append_edge_line(lines, f"{indent}{source_id} -->{label} {target_id}", style=_edge_style(compiled, edge))

    def _append_edge_line(self, lines: list[str], line: str, *, style: str = "") -> None:
        edge_index = self.edge_index
        lines.append(line)
        self.edge_index += 1
        if style:
            indent = line[: len(line) - len(line.lstrip())]
            lines.append(f"{indent}linkStyle {edge_index} {style};")

    def _render_resources(self, lines: list[str], *, graph: GraphConfig, indent: str) -> None:
        payload = _rendered_resources_payload(self.resources, graph, self.registry)
        if not payload:
            return
        base_lib = payload.get("base_lib", {})
        if isinstance(base_lib, Mapping):
            modules = _mapping_items(base_lib.get("modules", ()))
            self._render_resource_group(
                lines,
                root_id="resource_base_lib",
                root_label="base_lib",
                root_class="baseLibResource",
                child_class="baseLibResource",
                child_shape="fr-rect",
                resources=modules,
                label_kind="base_lib",
                indent=indent,
            )
        plugins = _mapping_items(payload.get("plugins", ()))
        self._render_resource_group(
            lines,
            root_id="resource_plugins",
            root_label="plugins",
            root_class="pluginResource",
            child_class="pluginResource",
            child_shape="hex",
            resources=plugins,
            label_kind="plugin",
            indent=indent,
        )
        host_extensions = _mapping_items(
            payload.get("host_extensions", ())
        )
        self._render_resource_group(
            lines,
            root_id="resource_host_extensions",
            root_label="host_extensions",
            root_class="hostExtensionResource",
            child_class="hostExtensionResource",
            child_shape="hex",
            resources=host_extensions,
            label_kind="host_extension",
            indent=indent,
        )

    def _render_resource_group(
        self,
        lines: list[str],
        *,
        root_id: str,
        root_label: str,
        root_class: str,
        child_class: str,
        child_shape: str,
        resources: tuple[Mapping[str, object], ...],
        label_kind: str,
        indent: str,
    ) -> None:
        if not resources:
            return
        lines.append(f'{indent}{root_id}@{{ shape: hex, label: "{_escape_label(root_label)}" }}')
        lines.append(f"{indent}class {root_id} {root_class};")
        for index, resource in enumerate(resources):
            resource_id = f"{root_id}_{index}"
            label = _resource_label(resource, kind=label_kind, show_semantics=self.show_semantics)
            status = str(resource.get("status", "implemented"))
            presentation = resolve_presentation(resource, native_class=child_class, resource_kind=label_kind,
                status_class="plannedResource" if status == STATUS_PLANNED else "", call_style=resource.get("style"))
            lines.append(f'{indent}{resource_id}@{{ shape: {presentation.shape}, label: "{_escape_label(label)}" }}')
            self._append_edge_line(lines, f"{indent}{root_id} -.-> {resource_id}")
            lines.append(f"{indent}class {resource_id} {'plannedResource' if status == STATUS_PLANNED else child_class};")
            lines.append(f"{indent}style {resource_id} {presentation.mermaid_style()}")

    def _render_findings(self, lines: list[str], graph: GraphConfig, compiled: CompiledGraph, *, indent: str) -> None:
        for finding in _health_findings(self.health_report):
            severity = str(finding.get("severity", "error"))
            rule_id = str(finding.get("rule_id", ""))
            object_type = str(finding.get("object_type", ""))
            object_id = str(finding.get("object_id", ""))
            message = str(finding.get("message", ""))
            lines.append(f"{indent}%% finding {severity} {rule_id} {object_type}:{object_id} {_comment_text(message)}")
            class_name = "healthWarning" if severity == "warning" else "healthError"
            for target_id in self._finding_targets(graph, compiled, object_type=object_type, object_id=object_id):
                self.node_classes.setdefault(target_id, class_name)

    def _finding_classes(self, graph: GraphConfig, compiled: CompiledGraph) -> dict[str, str]:
        classes: dict[str, str] = {}
        for finding in _health_findings(self.health_report):
            severity = str(finding.get("severity", "error"))
            object_type = str(finding.get("object_type", ""))
            object_id = str(finding.get("object_id", ""))
            class_name = "healthWarning" if severity == "warning" else "healthError"
            for target_id in self._finding_targets(graph, compiled, object_type=object_type, object_id=object_id):
                if classes.get(target_id) != "healthError":
                    classes[target_id] = class_name
        return classes

    def _class_for_node(self, node_id: str, *, preferred_class: str = "", planned: bool = False) -> str:
        finding_class = self.node_classes.get(node_id)
        if finding_class:
            return finding_class
        if planned:
            return "plannedNode"
        return preferred_class or "defaultNode"

    def _preferred_class_for_node(self, *, flow_kind: str, is_external: bool) -> str:
        if is_external:
            return "externalDependency"
        if flow_kind == FLOW_KIND_DOCUMENT:
            return "documentNode"
        return "defaultNode"


    def _presentation(self, node: NodeSpec, node_id: str, *, native_class: str, status_class: str, flow_kind: str):
        descriptor = registry_descriptor(self.registry, node.type_used)
        return resolve_presentation(descriptor, native_class=native_class, status_class=status_class if status_class in {"healthError", "healthWarning", "plannedNode"} else "", call_style=node.style, flow_kind=flow_kind)

    def _node_is_external(self, node: NodeSpec) -> bool:
        return node_is_external(node, self.registry)

    def _finding_targets(self, graph: GraphConfig, compiled: CompiledGraph, *, object_type: str, object_id: str) -> tuple[str, ...]:
        if object_type == "node" and object_id in self.node_ids:
            return (self.node_ids[object_id],)
        if object_type == "nodeset":
            target = self.nodeset_node_ids.get(object_id)
            return (target,) if target else ()
        if object_type == "contract_key":
            targets: list[str] = []
            provider = compiled.providers.get(object_id)
            if provider and provider in self.node_ids:
                targets.append(self.node_ids[provider])
            for consumer in compiled.consumers.get(object_id, ()):
                if consumer in self.node_ids:
                    targets.append(self.node_ids[consumer])
            return tuple(dict.fromkeys(targets))
        return ()

    def _node_label(
        self,
        node: NodeSpec,
        graph: GraphConfig,
        compiled: CompiledGraph,
        *,
        effective_lock: tuple[str, str, bool] | None,
        is_external: bool,
    ) -> str:
        sections: list[list[str]] = [[self._node_title(node, is_external=is_external)], [f"id: {node.id}", f"type_used: {node.type_used}"]]
        descriptor = registry_descriptor(self.registry, node.type_used)
        presentation = resolve_presentation(descriptor, call_style=node.style)
        icon = presentation.values.get("icon", "")
        if icon:
            sections[0][0] = f"{icon} {sections[0][0]}"
        if descriptor is not None:
            selections = self.registry.rulesets(node.type_used)
            sections.append([f"rulesets: {', '.join(selections) or 'unconstrained'}"])
            if descriptor.tags:
                sections.append([f"tags: {', '.join(descriptor.tags)}"])
        source_lines = _source_lines(graph.root_id, graph.root_path, graph.source_path)
        if source_lines:
            sections.append([_section_label("source"), *source_lines])
        if node.status == STATUS_PLANNED:
            planned_lines = [_section_label("status"), f"status: {planned_behavior_label(node.planned_behavior)}"]
            if node.planned_behavior.stub_module:
                planned_lines.append(f"stub: {node.planned_behavior.stub_module}")
            sections.append(planned_lines)
        if self.show_semantics:
            semantic_lines = self._node_semantic_lines(
                node,
                graph,
                compiled,
                effective_lock=effective_lock,
                is_external=is_external,
            )
            if semantic_lines:
                sections.append([_section_label("meta"), *semantic_lines])
        return _join_label_sections(sections)

    def _nodeset_label(
        self,
        node: NodeSpec,
        nodeset: NodesetSpec,
        graph: GraphConfig,
        compiled: CompiledGraph,
        *,
        effective_lock: tuple[str, str, bool] | None,
    ) -> str:
        title = node.metadata.display_name or nodeset.display_name or node.id
        sections: list[list[str]] = [[title], [f"id: {node.id}", f"type_used: {node.type_used}"]]
        source_lines = _source_lines(
            nodeset.root_id or graph.root_id,
            nodeset.root_path or graph.root_path,
            nodeset.source_path or graph.source_path,
        )
        if source_lines:
            sections.append([_section_label("source"), *source_lines])
        if node.status == STATUS_PLANNED or nodeset.status == STATUS_PLANNED:
            behavior = effective_planned_behavior(node, nodeset)
            planned_lines = [_section_label("status"), f"status: {planned_behavior_label(behavior)}"]
            if behavior.stub_module:
                planned_lines.append(f"stub: {behavior.stub_module}")
            sections.append(planned_lines)
        if self.show_semantics:
            call_lines = [
                f"flow_kind: {node_flow_kind(node, compiled) or nodeset.flow_kind}",
                f"rulesets: {', '.join(nodeset.graph.rulesets) or 'unconstrained'}",
                *_node_metadata_lines(node),
                *_async_semantic_lines(node),
            ]
            effect_scope = node_review_effect_scope(graph, node, self.registry, compiled=compiled)
            if effect_scope != EFFECT_SCOPE_NONE:
                call_lines.append(f"effect_scope: {effect_scope}")
            call_lines.append(
                f"runtime_dispatch: {_runtime_dispatch_label(node, compiled)}"
            )
            call_lines.extend(
                _execution_lock_lines(
                    effective_lock,
                    show_none=(node_flow_kind(node, compiled) == FLOW_KIND_GLOBAL_STATE),
                )
            )
            if call_lines:
                sections.append([_section_label("call"), *call_lines])
            sections.append(
                [
                    _section_label("nodeset"),
                    f"type_key: {nodeset.type_key}",
                    f"desc: {nodeset.description}",
                ]
            )
        return _join_label_sections(sections)

    def _loop_label(
        self,
        node: NodeSpec,
        nodeset: NodesetSpec,
        graph: GraphConfig,
        compiled: CompiledGraph,
        *,
        effective_lock: tuple[str, str, bool] | None,
    ) -> str:
        title = node.metadata.display_name or nodeset.display_name or node.id
        sections: list[list[str]] = [[title], [f"id: {node.id}", f"type_used: {node.type_used}"]]
        source_lines = _source_lines(
            nodeset.root_id or graph.root_id,
            nodeset.root_path or graph.root_path,
            nodeset.source_path or graph.source_path,
        )
        if source_lines:
            sections.append([_section_label("source"), *source_lines])
        spec = node.loop
        maximum = "unbounded" if spec.max_iterations is None else spec.max_iterations
        loop_lines = [_section_label("loop"), f"body: {nodeset.type_key}", f"stop: {_loop_stop_text(spec)}", f"max: {maximum}"]
        sections.append(loop_lines)
        if self.show_semantics:
            call_lines = [
                f"flow_kind: {node_flow_kind(node, compiled) or nodeset.flow_kind}",
                f"rulesets: {', '.join(nodeset.graph.rulesets) or 'unconstrained'}",
                *_node_metadata_lines(node),
                *_async_semantic_lines(node),
            ]
            effect_scope = node_review_effect_scope(graph, node, self.registry, compiled=compiled)
            if effect_scope != EFFECT_SCOPE_NONE:
                call_lines.append(f"effect_scope: {effect_scope}")
            call_lines.append(
                f"runtime_dispatch: {_runtime_dispatch_label(node, compiled)}"
            )
            call_lines.extend(
                _execution_lock_lines(
                    effective_lock,
                    show_none=(node_flow_kind(node, compiled) == FLOW_KIND_GLOBAL_STATE),
                )
            )
            if call_lines:
                sections.append([_section_label("meta"), *call_lines])
        return _join_label_sections(sections)

    def _node_title(self, node: NodeSpec, *, is_external: bool) -> str:
        title = ""
        if node.metadata.display_name:
            title = node.metadata.display_name
        elif self.registry is not None and node.status != STATUS_PLANNED:
            info = registry_descriptor(self.registry, node.type_used)
            display_name = str(getattr(info, "display_name", "")).strip() if info is not None else ""
            if display_name:
                title = display_name
        title = title or node.id
        if is_external and not title.startswith("[EXTERNAL]"):
            return f"[EXTERNAL] {title}"
        return title

    def _edge_label(self, graph: GraphConfig, edge: object) -> str:
        when = str(getattr(edge, "when", "")).strip()
        data_text = _edge_contract_text(graph, edge) if self.show_contract else ""
        sections: list[list[str]] = []
        if when:
            sections.append([_section_label("when"), f"when: {when}"])
        if data_text:
            sections.append([_section_label("data"), f"data: {data_text}"])
        return _join_label_sections(sections)

    def _node_semantic_lines(
        self,
        node: NodeSpec,
        graph: GraphConfig,
        compiled: CompiledGraph,
        *,
        effective_lock: tuple[str, str, bool] | None,
        is_external: bool,
    ) -> tuple[str, ...]:
        lines = list(_node_metadata_lines(node))
        lines.append(f"flow_kind: {node_flow_kind(node, compiled) or 'process'}")
        if self.registry is not None and node.status != STATUS_PLANNED:
            info = registry_descriptor(self.registry, node.type_used)
            if info is not None and not lines:
                for label, value in (
                    ("version", getattr(info, "version", "")),
                    ("desc", getattr(info, "description", "")),
                ):
                    text = str(value).strip()
                    if text:
                        lines.append(f"{label}: {text}")
        lines.extend(_async_semantic_lines(node))
        effect_scope = node_review_effect_scope(graph, node, self.registry, compiled=compiled)
        if effect_scope != EFFECT_SCOPE_NONE:
            lines.append(f"effect_scope: {effect_scope}")
        lines.append(
            f"runtime_dispatch: {_runtime_dispatch_label(node, compiled)}"
        )
        lines.extend(
            _execution_lock_lines(
                effective_lock,
                show_none=(effect_scope == EFFECT_SCOPE_GLOBAL_STATE),
            )
        )
        if is_external:
            lines.append("external: true")
        return tuple(lines)


def _execution_lock_lines(
    effective_lock: tuple[str, str, bool] | None,
    *,
    show_none: bool,
) -> tuple[str, ...]:
    if effective_lock is None:
        return ("execution_lock: none",) if show_none else ()
    key, scope, inherited = effective_lock
    suffix = f"{scope}, inherited" if inherited else scope
    return (f"execution_lock: {key} ({suffix})",)


def _runtime_dispatch_label(
    node: NodeSpec,
    compiled: CompiledGraph,
) -> str:
    if node.status == STATUS_PLANNED:
        return "unknown"
    value = getattr(compiled, "runtime_dispatches", {}).get(node.id)
    if value is True:
        return "detected"
    if value is False:
        return "none"
    return "unknown"


def _effective_execution_lock_payload(
    graph: GraphConfig,
    node: NodeSpec,
    *,
    graph_lock_scope: str,
) -> dict[str, object] | None:
    nodeset = nodeset_for_node(graph, node)
    if node.execution_lock is not None:
        return {
            "key": node.execution_lock.key,
            "scope": "block" if nodeset is not None else "node",
            "inherited": False,
        }
    if graph.execution_lock is not None:
        return {
            "key": graph.execution_lock.key,
            "scope": graph_lock_scope,
            "inherited": True,
        }
    return None
