# VibeFlow 职责边界与收缩建议（2026-10-09）

结论：保留当前统一 Descriptor／Catalog、Config／WorkflowPlan、Rule／Ruleset、SourceContext 和两个 Target 的主架构。需要收缩的是默认质量规则中对业务执行语义的推断，以及与架构无关的工具链资格检查。不是回滚为旧系统，也不是取消代码质量限制。

本文是源码审核与整改方案。用户明确的职责边界已记录；具体删改建议尚未实施。没有修改产品代码、现有测试，没有提交、发布或重建发行包。旧审核报告保留原有证据，本文重新界定其对当前产品目标的意义。

## 已确认的用户限制与本次建议的区别

用户明确：VibeFlow 只关注 Node 之间的关系和 Node 内的代码质量，是代码质量限制器、代码架构限制器；不负责代码正确性和代码安全性，不是业务语言编译器或安全检查器。

由此可以确认：

- 框架必须正确实现它自己承诺的配置解析、依赖边界、端口和调度协议。这不等于证明用户业务算法正确。
- 源码行数、函数复杂度、重复实现、依赖层级、显式 Node 耦合等仍属代码质量／架构限制，不因“不是编译器”而取消。
- 允许为查找实际资源、入口、导入和调用关系使用 AST／符号服务；不要求完整解释 Python／JS 的执行语义。
- 不能用“未证明无副作用”“没有穷尽异常出口”“可能绕过检查”等理由，自行扩大框架职责。
- 不建立恶意代码防护、运行时沙箱或业务正确性证明；项目测试、语言工具和实际业务环境负责其各自的检查。

以下实施细则是本次建议，不冒充用户已经逐项选择：硬错误主要用于确定的声明／协议冲突、确定的架构违例和已选择的质量上限；启发式健康度建议维持非阻塞；未知业务行为不转成默认错误。项目若需要特殊编码风格，复用现有显式 Ruleset，而非增加另一套分析或权限控制系统。

“不证明正确性”不能成为把明显识别错误保留下来的理由，例如把整数 `self.client = 1` 当成网络客户端。反过来，修这种误判也不应再引入完整类型推断。

## 审核对象与实际证据

HEAD 为 `5b9f9763ab7051fc964a4d83a1419d87a621b4c9`，审核包含当前未提交修复。335 个产品文件与上一轮审核快照一致，见 [source-state.json](product-boundary-audit-20261009/source-state.json)。本次使用当前源码，不把历史规则盘点中的“保留”当作新目标的授权。

检查范围包括内置规则装配、Core 图与质量算法、Python 源码分析／规则／编译适配／运行接口、JS 原生 driver／AOT 工具链／接口生成、公开文档及相关消费者。没有声称逐分支证明全部产品或任意第三方 Rule。

本轮实际执行：

- 13 项 Python SDK → Ruleset → 正式 `validate` CLI 案例，包含正向对照，每个子进程使用唯一当前源码。见 [CLI 结果](product-boundary-audit-20261009/cli-results.json)与 [脚本](product-boundary-audit-20261009/probe_boundaries.py)。只加载声明、检查源码，不执行业务 Node。
- 5 项 JS 原生 Rule driver 案例，借用现有本地 TypeScript 依赖；不是完整 JS workflow build。另有 3 项工具链 API 检查，确认 lock 门禁发生在启动实际工具链之前。见 [结果](product-boundary-audit-20261009/javascript-results.json)与 [脚本](product-boundary-audit-20261009/probe_javascript.py)。
- 4 项 Python 原生接口 Rule 案例，确认命名、命名空间与示例资料限制；没有把它们描述成完整 workflow 验收。见 [接口结果](product-boundary-audit-20261009/interface-results.json)与 [脚本](product-boundary-audit-20261009/probe_interface.py)。

没有运行全量 pytest、17 阶段门禁、浏览器业务或发行构建；本轮不修改产品，重点是实际限制行为与职责匹配。探针初次读取 JS 返回对象时有脚本错误，修正为 dataclass 属性后完整重跑；不将其计为产品缺陷。模块级递归初探未触发当前 Node 指标，最终用 Node 私有方法递归确认硬错误，未夸大现有检查范围。

## 应保留的主架构

| 部分 | 保留到什么程度 | 原因 |
|---|---|---|
| 唯一 Descriptor／Catalog 和固定插件贡献 | 保留资源身份、来源、冲突和实际绑定；不能重新引入旧 metadata 权威 | 直接保护 Node 和资源关系的一致性 |
| Config、显式边、Nodeset／Loop、公共计划 | 保留调度／传输角色、路由、合流、可达性、有限子图和任务消费关系 | 属于框架执行模型，不是业务算法正确性 |
| 源码归属、跨资源依赖 | 保留实际 symbol/import/reference 与声明关系；不靠目录名猜身份 | 防止 Node 绕过流程直接调用另一 Node，防止隐藏跨层耦合 |
| Rule／Ruleset 与局部覆盖 | 保留显式选择、有效参数、records 依赖和一致诊断；空选择不得暗中补回规则 | 已有可组合质量限制机制，不应另造权限系统 |
| 代码质量度量 | 保留行数、分支、嵌套、依赖链、调用链和重复结构；已选择上限可阻断，形似／命名／目录距离保持建议性质 | 这是用户明确要的限制器 |
| 原生 ABI 与端口接口 | 保留入口签名、同步／异步协议、返回 Mapping／声明输出键、实际输入 cardinality、显式 schema | 框架必须能调用和路由；不判定数值是否算对 |
| Target 构建／执行 | 保留 plan 编译、AOT 生成、原生 TypeScript／esbuild 和真实错误 | “不是编译器”指不自建业务语言语义证明，并不意味着删掉流程计划或目标构建 |
| 显式锁、异步生命周期、Capability／Host | 保留用户声明的协调关系、任务收尾和宿主接口 | 是跨 Node 的执行关系；不能扩展为预测性资源准入或自动全局串行化 |
| 架构图、状态与结果范围 | 保留生成与显式新鲜度命令；它们不是业务正确性／安全性证书，也不读取历史报告作运行资格 | 便于维护当前结构 |

JS 的 TypeScript 配置虽然严格，但 `toolchain_driver.mjs:2377` 的普通诊断仅用于生成的契约检查文件；没有证据证明框架在强制检查整个业务项目的类型正确性。不能仅凭 `strict: true` 删除这套原生接口检查。`core/rules/fingerprint.py` 的摘要用于本次规则缓存，planned stub 的摘要用于模块名称／记录；它们不等同于运行前完整性资格门禁，不按名字一并删除。

collaborative 的人工架构审批是该 profile 的开发协议；没有证据表明它是 Runtime 的第二套业务准入系统。本次不撤销 profile 协议。

## 需要修改／删除的部分与停止点

### B01：输入不可变检查——缩回清楚、有限的质量规则

位置：`targets/python/quality/source_analysis/input_tracking.py`（862 行）、`parameter_facts.py`（250 行）、`rules/effects.py:83`、`source_analysis/visitors.py:253`。

当前实现保存异常状态、精确字典事实、名称是否已绑定、builtin 是否被遮蔽、闭包写回、生成器创建与消费时点，并沿 helper 调用传播。这已经在建立一部分语言执行模型。维护者为了补一个漏检，必须理解更多执行细节，随后仍可能遇到新的语义组合。

建议保留：直接对 `inputs`／明显子引用的写入、删除、已知变异调用；若保留简单局部赋值别名，只做有明确范围的词法／赋值识别，重绑定与作用域不能按名字误判。可达 helper 的结构与依赖仍由 SourceContext 保留。

建议删除：逐表达式异常出口、异常类别／catch 匹配、精确字典与未绑定证明、跨函数输入污染固定点、闭包写回与生成器消费推演。删除相应参数、消费者、缓存和仅用于证明这些路径的测试。`parameter_facts.py` 当前全部服务于这些推断，消费者迁出后整文件退役；`input_tracking.py` 不能只关掉 handler 分支留下全套状态机，应收缩／重写为单一有限检查实现。

停止点：不追问任意对象在所有控制路径上是否始终共享输入，不遍历第三方函数以证明无副作用，不把未知当违例，不用永久污染所有历史别名的旧办法制造误报。F06 的 12 个漏检组合不再是必须补齐的验收项；简单、已承诺的直接输入检查仍需正确工作。

### B02：输出字典推断——保留端口合同，移除对构造方式的强制

位置：`source_analysis/visitors.py:631`，`input_tracking.py:798–856`。

正式 CLI：`return result()`，其中 helper 返回 `{}`，被 `NODE.PURITY.DYNAMIC_OUTPUT_KEY` 拒绝；`result = {}; return result` 则通过。这里要求的是特定代码构造方式，不是实际端口合同。

建议删除 `_output_dicts`、输出赋值／键累积、`_return_keys` 和“无法推断键就拒绝”的路径。直接字面量与声明明显不一致可留作非阻塞提示，但不继续加入 helper 返回值推断。Runtime 的 `_validate_outputs` 已检查真实 Mapping 和 provides 键集合，应保留；JS 原生生成 ABI 应保留。

停止点：可以通过 helper、组合函数或变量构造声明输出，不证明每条返回路径一定返回某个业务值。

### B03：动态分派分析——移出默认编译／检查链

位置：`source_analysis/runtime_dispatch.py`（919 行），`rules/effects.py:177`，`project/compiler.py:228`，Core／BlockPlan／Architecture 与 presenter 的 `runtime_dispatch` 元数据消费者。

当前分析追踪输入中的 callable、模块状态、闭包、参数绑定和局部调用；效果规则给 warning，编译适配器也执行分析。沿消费者核对后，没有发现它改变原生拓扑、锁权限或业务调度；不能误说它是自动锁机制。

建议默认删除这个推断器及两条调用入口；当前 SourceContext 的明确 Node 符号调用关系已足够支持架构耦合检查。`runtime_dispatch` 自动推断字段在内部模型、plan、展示和文档中一并退役；若涉及公开 ABI，做明确版本迁移，过渡最多只表达未分析，不能保留旧分析器暗中继续运行。

项目确实要限制“把回调藏在输入中”时，用已有领域 Rule 检查明确声明／直接调用，不在内核保留通用闭包解释器。停止点：发现真实 Node 耦合，不证明任意 callback 的行为。

### B04：算法循环／递归——解除默认硬禁令

位置：`source_analysis/visitors.py:614`，`builtin/implementation.py:85–87`。

正式 CLI：三次有限 `while` 被拒绝，等价有限 `for` 通过；Node 私有 factorial helper 的递归被维护性规则拒绝。

建议删除“所有 `run_pure` while 必须改为拓扑 Loop”的硬规则。Node 内算法重复不等于工作流多次调度；保留 Config 普通环禁止、显式 Loop body 和 Nodeset 递归限制。Node helper 的递归信息可保留为非阻塞质量提示，或由项目显式选中的风格 Rule 禁止；不再默认要求改造成跨 Node 流程。

停止点：仍度量复杂度、调用深度；不证明算法收敛／终止，不自动将内部循环展开成架构。图层 Nodeset 递归与函数递归不是同一件事。

### B05：资源字段与对象赋值——删除靠名称／对象位置作出的硬判断

位置：`source_analysis/helpers.py:37`、`types.py:60`、`visitors.py:584,654,760`、`input_tracking.py:837`。

正式 CLI：`self.client = 1` 被拒绝、`self.value = 1` 通过；函数中新建的 `Box` 上写 `box.count = 1` 或 `setattr(box, 'count', 1)` 都被当成 monkey patch。

建议删除资源字段名称黑名单、所有非 self 属性赋值禁令，以及对任意 `setattr`／`delattr` 的 blanket 禁令。保留真实另一 Node 的内部访问／直接调用，以及明确修改框架 Catalog、声明和调度对象的协议约束；有限直接输入写入仍交 B01。

停止点：不再为了证明本地对象“确实属于自己”建立完整对象所有权／类型分析。实际资源生命周期按显式资源／Host 声明约束，不靠字段名替代身份。

### B06：效果规则——从行为猜测和安全黑名单缩为显式边界

位置：`source_analysis/effects.py`（610 行）、`exit_stacks.py`（163 行）、共享效果 visitor；JS `auditHostIo`／`auditModuleStateWrites`。

正式 CLI：纯内存 `io.StringIO().write()` 因 `.write` 名称被拒绝；`python_io` 下只导入 `ctypes` 也被不可覆盖的效果分类拒绝。当前还含 `CDLL`／`dlopen` 叶名、`set*`／`reset*`、可疑容器名称、反射和 callback 等大量猜测。

建议保留：用户显式导入允许／禁止政策、明确的跨层依赖、已选择效果规则对已识别文件／网络／终端操作和显式共享模块状态的限制。简单导入别名与词法遮蔽识别有必要；不能把局部同名变量当宿主。

建议删除／收缩：

- 未知接收者仅凭 `.write`／`.close` 等名字就报 I/O；仅凭 `set*`／`reset*` 猜模块状态。
- ctypes／cffi／第三方 native loader 的统一硬禁令及叶名猜测；需要的资源依赖照常声明，effects 不充当 OS 安全政策。
- 为阻止“绕过分析”而全面禁止 reflection／动态命名空间；普通对象动态访问不等于隐藏 Node 关系。动态资源绑定／动态 Node 调用违反实际声明时仍受架构限制。
- 为修复未知 `.close` 误判而追踪 ExitStack 实例、partial 和延迟 callback 的专用语义分析。去掉名称猜测后，应一并删除其特殊豁免分析器，不能保留补偿状态机。

对显式影响共享状态、框架入口或进程生命周期的操作，按实际架构／执行协议检查；不要继续扩大“宿主关键状态”清单并宣称防恶意代码。未知第三方算法不等于违规；导入本身也不证明函数执行 I/O。动态源码若不受构建 profile／资源绑定的必要限制，不因“无法证明安全”默认拒绝；若项目要禁止 eval，可显式选择风格／依赖政策，而不做安全绕过穷举。

### B07：JS 时间／随机数——与宿主访问分开

位置：`resources/toolchain_driver.mjs:1821–2021`。

原生 Rule driver：`Math.max(1,2)` 通过；`Math[params.operation](1,2)`、`Date.now()`、`Math.random()` 在 none 下被宿主规则拒绝，Date 在 python_io 下通过。把算法确定性和宿主 I/O 混成同一个权限，会让用户为了普通计算放开更广的 I/O。

建议从默认 effects 移除时间／随机数／Math 对象或 computed member 的确定性推断。若某项目明确要求可重复计算，使用显式领域 Rule，最小识别其指定原语；不建第二套默认内核规则引擎。实际 fetch、fs、DOM／Host 关系和 Capability 接口保留。

停止点：默认不承诺确定性，不把动态 Math 成员当随机数，不为了确定性扫描第三方库内部。Python 当前没有等价时间／随机数禁令，统一的是两种 Target 的职责边界，不要求所有语法检测同形。

### B08：接口规则中的命名与示例限制——只留真实接口

位置：`quality/rules/node_interface.py:61–74`，Node schema 的 examples 定义。

4 项原生 Rule 对照确认：输入 type 与输出 key 字符串相同会报 overlap；Decision 用 `status.ok` 会因未命中 route／branch 等名称报错；示例带 outputs 被拒绝。中立 schema 明确允许 examples.outputs，资料本身不会执行业务验算。

建议删除这三项硬拒绝。type 与 key 不同命名空间，没有一般性的互斥理由；Decision 保留实际 `when`、输出引用和路由结构，不由名字推断业务含义；examples.outputs 仅作声明文档，不执行、不拿来证明结果正确。命名建议可由非阻塞风格规则表达。

保留入口签名、实现符号、受支持 completion、单一执行入口，以及声明字段／端口描述的结构一致性。不要把“合同需要正确解析”误扩展为“算法输出必须正确”。

### B09：npm lock 资格——从运行／构建前置条件移除

位置：`targets/javascript/build/toolchain.py:96,129,281–378`。

`probe_toolchain` 和 `run_build_driver` 在实际工具调用前要求唯一 package-lock，拒绝 yarn／pnpm；再要求安装版本与 lock 完全一致。API 探针确认无 lock、yarn lock、双 lock 立即失败，尚未尝试实际 Node。不能据此声称本次已经证明无 lock 的真实构建成功。

建议删除 `_lock_identity`／`_validate_lock_tool_versions` 及其构建前调用、专用报错、强制 lock 字段和相应拒绝测试。项目仍可自行保留 npm／yarn／pnpm lock；发行模板仍可选 npm ci，但不由 VibeFlow 重做包管理资格校验。依赖安装交原包管理器。

保留实际 Node／TypeScript／esbuild 能否解析、使用适配器必需的版本兼容范围、具体 Target／profile 支持和真实构建诊断。摘要若仅作可选日志无需扩展为资格链；已经不再有消费者的摘要字段一起删除。

### B10：默认规则职责拆分——消除一条 effects 承担所有事的耦合

目前 Python `no_side_effects` 的 visitor 同时处理效果、输入修改、输出键、资源字段、内部循环和 Node 耦合。取消 effects 会连带取消多个不同目的的检查。建议让消费者按现有规则职责归位：接口留 node_interface，指标留 maintainability，实际依赖／Node 耦合留架构／ownership，effects 只管显式效果政策；B02/B04/B05 的默认禁令直接删除，不是再拆成一批默认门禁。

复用同一 SourceContext 和 Rule 图，不能用新目录／新服务包装一套旧 visitor 并长期双跑。Core 不读业务 AST，Target 不另藏硬编码权限；选中规则产生意见，原生运行协议处理真实执行状态。

声明期质量规则可保留明确的“声明与初始化分开”约定，但不要证明任意 import 完全无副作用。当前直接导入的插件本来就是受信代码，文档已明确不是 OS 沙箱。注册声明允许例外保持局部，不扩展成任意 decorator／metaclass 的安全解释器。

### B11：死分支与测试／文档——按新目标同步清理

`input_tracking.py:828–835` 的 `_check_params_get_call` 最后调用一个只做 `del key_node, node` 的空方法。这条活调用没有判定效果，应连调用与方法一起删除。B01–B10 的实现退役后，导入、字段、flags、exports、记录消费者和仅验证旧硬禁令的测试同步删除，不留隐藏开关或旧回退实现。

旧版 parity 证明“曾经怎样”不证明“现在应该怎样”。保留历史报告原始反例；活动测试改为新职责验收。原 F01–F06 中真实架构身份错误、明确宿主操作识别和词法误判仍按其范围判断；复杂异常路径／输入污染／返回值证明不再作为强制补齐目标。不能为了延续旧 PASS 计数继续修解释器。

文档应明确 PASS 的范围：所选结构／质量规则通过，不证明业务正确、全部无副作用、代码安全或确定性。建议在公开 `not_checked` 资料加入代码安全性／通用程序行为证明的明确排除；不再增加资格证明输出。本文引用的边界更新已经写入维护者记录，产品报告尚未修改。

## 实施顺序与验收停止线

1. 先确定并记录本篇职责边界，更新活动验收。不要先给 F06 继续补出口，也不要将整个 quality 设为 warning 绕开问题。
2. 先移除明确误判／不必要前置：B04/B05/B08/B09，删除各自消费者和旧拒绝期待；保留架构反例。
3. 收缩 B01/B02/B03/B06/B07，按 B10 归位；真正替换旧实现后删除它，不永久共存。不要求删除本轮所有作用域／源码归属修复，因为其中有服务架构的共享事实。
4. 按实际变更跑相关最小测试；到公共模型／两个 Target 交付阶段再按仓库现有流程做一次适用完整验证，不用历史测试总数代替目标验证。

新的核心验收是：合法 Node 内算法与本地对象操作不会仅因上述猜测被拦；直接 Node 耦合、未声明资源关系、非法图和接口协议仍被拒绝；已选择的代码质量上限仍执行；明确未分析的业务行为不会伪装成正确性或安全性结论。框架自己的异常清理、调度、绑定、报告及资源释放仍需测试正确。

本次建议不以删除行数为目标。862／250／919／163 是当前分析模块体量的证据，不是已经删除的数量，也不能相加冒充净收益；共享词法和源码事实仍需要保留。重要的是每条维护中的规则都有明确质量／架构职责，且不依赖无限补齐语言语义才能成立。
