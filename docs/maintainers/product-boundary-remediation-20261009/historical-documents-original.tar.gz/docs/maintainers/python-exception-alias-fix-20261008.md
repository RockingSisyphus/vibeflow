# Python 异常出口中的输入别名修复

本记录跟进[别名事实修复独立审核](python-alias-facts-review-20261008.md)中的 F05。原 F03/F04 的具体案例已修复，但 after-source-03 丢失了表达式中途抛错时的输入别名，不能据此前的完整验收认定本轮没有回归。原审核、原脚本、历史期待及上一轮验收证据保持原样。

## 结果目标与根因

`((alias := inputs), params['missing'], (alias := {}))` 先将 alias 指向实际输入；查询抛出 KeyError 时，最后的清除尚未执行。except 中直接 `alias.pop(...)` 或调用 `sink(alias)` 都应报告输入突变。若先清除再查询，异常分支使用的是新字典，应继续允许。global_state 不取消输入不可突变合同。

修前冻结全部 334 个产品文件，与上一轮 after-source-03 一致。原静态16项及正式 CLI16项分别有12项漏检；其中6个 helper 案例是新回归，6个 direct 案例是既有遗漏。它们属于同一表达式异常状态缺失的根因，详见[修前结果](python-exception-alias-fix-20261008/before-replay-summary.json)。

## 实现与保留边界

统一输入采集器在属性／下标查询、调用与其他已分析操作的求值时点记录异常出口，交给最近的 try。正常结束、未匹配异常、handler／else 抛出的异常分开经过 finally，再传递给外层。函数定义的默认值仍在外层求值；仅静态检查函数体，不会把其中的异常当成定义时发生。

所有状态沿实际声明归属投影。可能指向输入的值取并集；名称已绑定和精确字典证明取交集。参数的输入身份与字典证明沿 SourceContext 的真实调用及函数 AST 传播；params 的字典种子来自 canonical Node runtime，其他参数不因名字叫 params 就获得证明。只对实际证明未被遮蔽的 builtin Exception／BaseException 消除相应已处理异常；未知对象的查询及调用仍保留保守出口。

每个选定的最外函数 AST 采集一次其嵌套调用，避免把丢失外层状态的重复遍历伪装成新实参来路。闭包实际调用可能发生在定义之后：若同一声明存在可能的非字典写入，不将定义时的字典值作为捕获值的稳定证明；该事实按声明归属收敛，不影响调用者当前路径的字典值，也不污染 sibling 的同名局部变量。

透明控制块中的函数加入现有 SourceContext 调用索引，不引入第二套按名称猜测 callee 的解析。真实函数定义、参数、赋值、循环目标及导入建立绑定；删除及异常变量退出时的隐式删除取消绑定。推导式的所有目标属于其局部声明，但只有已执行的目标赋值才建立可用值。生成器创建只求值外层 iterable；直接交给已证明的 builtin 消费函数时，才把延迟函数体的状态应用到当前路径。

本轮不新增资源权限，也不取消此前的局部来源标记、清除能力或函数写回判断。没有引入完整 Python 运行时解释器、动态反射分析、通用生成器消费者分析或 callee 确定清除摘要。此前 clear3 的一项既有保守误报与 raw36 的四项普通未知 write 期待差异继续单列，不能改写为原期待全部匹配。

## 验证状态

首轮定向为390 passed／11 failed，第二轮为428 passed／3 failed；原断言保留，后续修正表达式状态、实际调用索引、生成器消费及名称绑定。475项最终定向通过，涵盖原112项异常控制、293项写回控制及70项参数／绑定控制。闭包前后重绑定、nonlocal setter 和 sibling 隔离都同时断言参数事实与原生 Rule 的输入突变 finding。

首次335文件快照 after-F05 及其701项成功重放仍是中间证据：收尾复核揭示闭包重复采集及定义后重绑定的证明错误，因此不能作为最终接受版。最后快照 after-F05-02 的全部335文件已固定；原16项静态和正式 CLI 各16项、新旧核心矩阵共701次回归均匹配，另有164次独立异常控制通过，合计865次回归检查。新增控制读取冻结数据，通过 SDK、SourceContext 和原生 RulePlan 检查实际 finding、权限与参数证明，同时确认 AST 未变、加载来源唯一、335个产品文件前后相同。raw36与clear3的历史边界单列，见[源码重放摘要](python-exception-alias-fix-20261008/source-fixed-02-summary.json)。

本轮完整验收输入清单包含2355个文件：2340个 Git 可见源码、测试、工具及配置文件，以及15个10月5日已存在、被 Git 忽略的历史日志。相较上一轮2336文件清单，增加4个 Python 文件并扩大收集范围纳入这15个日志，没有新增15个产品文件。原始清单在[full-01-inputs-before.json](python-exception-alias-fix-20261008/full-01-inputs-before.json)。

先前全Python目录为2,933 passed／2 skipped，该批早于最后闭包修复，只记录其实际覆盖。新的正式完整验收 full-01 已17/17通过、退出码0：pytest 4,534 passed、Python业务sandbox 138/138、JS集成67/67，规则对照1,219项及适配207项均无不匹配。wheel与两种发行profile在新的隔离目录构建；全部2355个验收输入在全批次前后路径与字节均一致，见[完整验收结果](python-exception-alias-fix-20261008/full-01-result.json)。上一轮 full-03 与旧包只作历史对照，不作为 F05 的修后验收。

从本轮 wheel、collaborative kernel、autonomous kernel 分别完成18组、1,791次回归检查，共54组、5,373次，所有组退出码0。每个产品均包含原F05静态16项、正式CLI16项、164项异常控制，以及此前默认参数、推导式、写回、输入合同、效果及JS参数检查。另行保留的108次raw观察与每产品clear3的既有差异不冒充原期待全匹配。各组来源与结果见[包内验收汇总](python-exception-alias-fix-20261008/packaged-validation-summary.json)。

行为重放[之前](python-exception-alias-fix-20261008/product-byte-proof-before.json)和[之后](python-exception-alias-fix-20261008/product-byte-proof-after.json)，完整核对快照、安装wheel、whl、两个直接kernel及两份发行ZIP内嵌kernel共7集合，每份335个全部类型文件均与最终清单相同；归档、元数据及JS driver的整体字节也未变。模块来源必须指向各自的新包，不能回退仓库源码。独立quality自测49/49通过；本轮结论仅适用于记录的静态覆盖及保留边界。

本轮归档摘要、脚本与结果保存在 [python-exception-alias-fix-20261008/](python-exception-alias-fix-20261008/)；产品快照和隔离验收目录位于 dist 与用户缓存，具体路径由清单和重放记录注明。正式发布、覆盖默认发行目录、Git 提交及推送不包含在本轮操作中。
