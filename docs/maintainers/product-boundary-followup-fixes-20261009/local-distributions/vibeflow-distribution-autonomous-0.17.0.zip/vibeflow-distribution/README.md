# VibeFlow 0.17.0 无人值守开发包

本发行包包含相同内核下的最小 Python Runtime 与 JavaScript AOT 项目。先阅读 `AGENTS.md` 和 `kernel/docs/README.md`。
