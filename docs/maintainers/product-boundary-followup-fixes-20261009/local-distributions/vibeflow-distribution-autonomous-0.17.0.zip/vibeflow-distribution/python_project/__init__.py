"""Minimal Python VibeFlow project."""
