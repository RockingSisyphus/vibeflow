"""Judge declared source relationships using Target-supplied ownership facts."""

from collections.abc import Mapping, Sequence


def implementation_import_scopes(scopes, implementations):
    """Attach symbol import facts without merging the owners' permissions."""
    projections = {(item["kind"], item["type_key"], item["path"], item.get("export", "")):
                   item.get("import_lines") for item in implementations}
    return tuple({**scope, "owners": [
        {**owner, "import_lines": projections.get((owner["kind"], owner["id"], owner["path"], owner["symbol"]))}
        if owner["role"] == "entry" else owner for owner in scope["owners"]
    ]} for scope in scopes)


def resource_import_violations(source_path, target_path, sites, scopes):
    """Return each denying owner, or None when no declaration owns the source."""
    claimed = False
    violations = []
    for scope in scopes:
        owners = scope.get("owners", ())
        sources = [item for item in owners if item["path"] == source_path]
        targets = [item for item in owners if item["path"] == target_path]
        if not sources:
            continue
        claimed = True
        for owner in sources:
            selected = _selected_sites(owner, sites)
            if not selected or _allows(owner, targets):
                continue
            code = _code(owner["kind"])
            if code:
                violations.append((code, owner, selected, scope.get("id", "")))
    return violations if claimed else None


def _selected_sites(owner: Mapping, sites: Sequence):
    lines = owner.get("import_lines")
    if owner.get("role") != "entry" or lines is None:
        return sites
    return tuple(site for site in sites if site.get("line") in lines)


def _allows(source, targets):
    for target in targets:
        if (source["kind"], source["id"]) == (target["kind"], target["id"]):
            return True
        if target["kind"] == "base_lib":
            libraries = (*source.get("base_libs", ()),
                *(source.get("dependencies", ()) if source["kind"] == "base_lib" else ()))
            if target["id"] in libraries:
                return True
        if source["kind"] == "plugin_declaration" and target.get("plugin_id") == source["id"]:
            return True
    return False


def _code(kind):
    return {
        "node": "QUALITY.STRUCTURE.NODE_UNDECLARED_PROJECT_IMPORT",
        "base_lib": "QUALITY.STRUCTURE.BASE_LIB_UPWARD_IMPORT",
        "plugin": "QUALITY.STRUCTURE.PLUGIN_NODE_IMPORT",
        "plugin_declaration": "QUALITY.STRUCTURE.PLUGIN_NODE_IMPORT",
        "host_extension": "QUALITY.STRUCTURE.HOST_UNDECLARED_PROJECT_IMPORT",
    }.get(kind)
