from __future__ import annotations

from typing import Mapping

from vibeflow.core.contracts import (
    CARDINALITY_EXACTLY_ONE,
    CARDINALITY_OPTIONAL_ONE,
)
from vibeflow.core.flow import JOIN_POLICY_ALL, STATUS_PLANNED
from vibeflow.core.findings import HealthFinding
from vibeflow.core.constants import FLOW_KIND_TERMINAL
from vibeflow.core.quality.workflow_rules.helpers import _data_finding, _parse_when

def append_data_contract_warnings(
    graph,
    compiled,
    state,
    *,
    owner: str = "pipeline",
    runtime_flow_kinds: Mapping[str, str] | None = None,
) -> None:
    nodes_by_name = {node.name: node for node in graph.nodes}
    incoming = {node.name: [] for node in graph.nodes}
    outgoing = {node.name: [] for node in graph.nodes}
    for edge in compiled.resolved_transfer_edges:
        incoming.setdefault(edge.target, []).append(edge.source)
        outgoing.setdefault(edge.source, []).append(edge.target)
    condition_keys_by_source: dict[str, set[str]] = {node.name: set() for node in graph.nodes}
    for edge in compiled.resolved_transfer_edges:
        parsed = _parse_when(edge.when)
        if parsed is not None:
            condition_keys_by_source.setdefault(edge.source, set()).add(parsed[0])
    for node in graph.nodes:
        if node.status == STATUS_PLANNED:
            continue
        _append_missing_provider_warnings(node, graph, nodes_by_name, incoming, state, owner=owner)
        _append_unconsumed_provider_warnings(node, graph, compiled, outgoing, condition_keys_by_source, state, owner=owner)
    _append_runtime_requirement_findings(
        graph,
        compiled,
        nodes_by_name,
        state,
        owner=owner,
        runtime_flow_kinds=runtime_flow_kinds,
    )
    _append_data_bypass_payload_findings(compiled, nodes_by_name, state, owner=owner)


def _append_runtime_requirement_findings(
    graph,
    compiled,
    nodes_by_name,
    state,
    *,
    owner: str,
    runtime_flow_kinds: Mapping[str, str] | None = None,
) -> None:
    """Report required envelopes that the runtime can never place in a node inbox.

    Runtime input injection follows schedule edges, while output delivery follows all
    transfer edges.  Keeping those two edge sets separate is important: an explicit
    shortcut may be classified as transfer-only and therefore cannot make its target
    an initial-input node.
    """

    schedule_edges = tuple(compiled.resolved_schedule_edges)
    transfer_edges = tuple(compiled.resolved_transfer_edges)
    schedule_incoming = _edges_by_target(schedule_edges, nodes_by_name)
    transfer_incoming = _edges_by_target(transfer_edges, nodes_by_name)
    input_types = {item.type for item in graph.inputs}
    candidate_providers = _candidate_providers_by_type(nodes_by_name)
    flow_kinds = _runtime_flow_kinds(
        getattr(compiled, "flow_kinds", {}),
        runtime_flow_kinds,
    )

    for node in graph.nodes:
        if node.status == STATUS_PLANNED:
            continue
        accepts_initial = _runtime_accepts_initial_input(
            node.name,
            nodes_by_name,
            schedule_incoming,
            flow_kinds,
        )
        incoming = transfer_incoming.get(node.name, ())
        source_details = _provider_source_details(
            [nodes_by_name[edge.source] for edge in incoming if edge.source in nodes_by_name]
        )
        delivered_types = {
            provider.type
            for edge in incoming
            for provider in getattr(nodes_by_name.get(edge.source), "provides", ())
        }
        if accepts_initial:
            delivered_types.update(input_types)

        for requirement in node.requires:
            if requirement.cardinality != CARDINALITY_EXACTLY_ONE or requirement.type in delivered_types:
                continue
            state.errors.append(
                _data_finding(
                    "GRAPH.DATA.RUNTIME_REQUIREMENT_UNREACHABLE",
                    requirement.type,
                    (
                        f"node '{node.name}' requires type '{requirement.type}' exactly once, "
                        "but no runtime initial input or incoming transfer edge can deliver it"
                    ),
                    node=node.name,
                    severity="error",
                    details={
                        "owner": owner,
                        "required_type": requirement.type,
                        "required_cardinality": requirement.cardinality,
                        "accepts_initial_input": accepts_initial,
                        "entry_input_types": sorted(input_types),
                        "schedule_incoming": [_edge_details(edge) for edge in schedule_incoming.get(node.name, ())],
                        "transfer_incoming": [_edge_details(edge) for edge in incoming],
                        "incoming_provider_sources": source_details,
                        "candidate_providers": candidate_providers.get(requirement.type, []),
                        "suggestion": (
                            "Add a mainline or valid data-bypass edge from a node that actually provides "
                            f"type '{requirement.type}', or make '{node.name}' a true initial-input node."
                        ),
                    },
                )
            )


def _append_data_bypass_payload_findings(compiled, nodes_by_name, state, *, owner: str) -> None:
    for edge in getattr(compiled, "data_bypass_edges", ()):
        source = nodes_by_name.get(edge.source)
        target = nodes_by_name.get(edge.target)
        if source is None or target is None:
            continue
        source_types = sorted({provider.type for provider in source.provides})
        target_types = sorted({requirement.type for requirement in target.requires})
        matching_types = sorted(set(source_types) & set(target_types))
        if matching_types:
            continue
        state.errors.append(
            _data_finding(
                "GRAPH.DATA.NO_PAYLOAD_BYPASS",
                f"{edge.source}->{edge.target}",
                (
                    f"data-bypass edge {edge.source}->{edge.target} cannot deliver any payload "
                    "required by its target"
                ),
                node=edge.target,
                severity="error",
                details={
                    "owner": owner,
                    "source": edge.source,
                    "target": edge.target,
                    "edge": _edge_details(edge),
                    "source_provider_types": source_types,
                    "target_required_types": target_types,
                    "matching_types": matching_types,
                    "candidate_providers": {
                        requirement.type: _candidate_providers_by_type(nodes_by_name).get(requirement.type, [])
                        for requirement in target.requires
                    },
                    "suggestion": (
                        "Remove the shortcut, or originate the bypass at a node whose provides.type "
                        "matches a target requirement. Data-bypass edges transfer data only and never trigger the target."
                    ),
                },
            )
        )


def _edges_by_target(edges, nodes_by_name) -> dict[str, list[object]]:
    incoming: dict[str, list[object]] = {name: [] for name in nodes_by_name}
    for edge in edges:
        if edge.target in nodes_by_name:
            incoming[edge.target].append(edge)
    return incoming


def _runtime_accepts_initial_input(node_name: str, nodes_by_name, schedule_incoming, flow_kinds) -> bool:
    node = nodes_by_name[node_name]
    if not node.requires:
        return False
    incoming = schedule_incoming.get(node_name, ())
    if not incoming:
        return True
    return any(
        _is_empty_runtime_start(edge.source, nodes_by_name, schedule_incoming, flow_kinds)
        for edge in incoming
    )


def _is_empty_runtime_start(node_name: str, nodes_by_name, schedule_incoming, flow_kinds) -> bool:
    source = nodes_by_name.get(node_name)
    return bool(
        source is not None
        and flow_kinds.get(node_name) == FLOW_KIND_TERMINAL
        and not schedule_incoming.get(node_name)
        and not source.requires
        and not source.provides
    )


def _candidate_providers_by_type(nodes_by_name) -> dict[str, list[dict[str, str]]]:
    candidates: dict[str, list[dict[str, str]]] = {}
    for node in nodes_by_name.values():
        for provider in node.provides:
            candidates.setdefault(provider.type, []).append({"node": node.name, "key": provider.key})
    return {key: sorted(values, key=lambda item: (item["node"], item["key"])) for key, values in candidates.items()}


def _runtime_flow_kinds(
    compiled_flow_kinds,
    supplied_flow_kinds: Mapping[str, str] | None,
) -> dict[str, str]:
    kinds = {str(name): str(value) for name, value in dict(compiled_flow_kinds or {}).items() if value}
    for name, flow_kind in dict(supplied_flow_kinds or {}).items():
        if flow_kind and str(name) not in kinds:
            kinds[str(name)] = str(flow_kind)
    return kinds


def _edge_details(edge) -> dict[str, object]:
    return {
        "from": str(getattr(edge, "source", "")),
        "to": str(getattr(edge, "target", "")),
        "when": str(getattr(edge, "when", "")),
    }

def _append_missing_provider_warnings(node, graph, nodes_by_name, incoming, state, *, owner: str) -> None:
    direct = [nodes_by_name[name] for name in incoming.get(node.name, ()) if name in nodes_by_name]
    input_types = {item.type for item in graph.inputs} if _is_initial_input_node(node, graph, incoming, nodes_by_name) else set()
    direct_source_details = _provider_source_details(direct)
    direct_provider_types = sorted({provider["type"] for source in direct_source_details for provider in source["provides"]})
    for requirement in node.requires:
        matches = [provider for parent in direct for provider in parent.provides if provider.type == requirement.type]
        if requirement.type in input_types:
            matches.append(None)
        base_details = {
            "owner": owner,
            "required_type": requirement.type,
            "required_cardinality": requirement.cardinality,
            "direct_sources": [source["node"] for source in direct_source_details],
            "direct_source_providers": direct_source_details,
            "available_provider_types": direct_provider_types,
            "entry_input_types": sorted(input_types),
        }
        if not matches:
            state.errors.append(
                _data_finding(
                    "GRAPH.DATA.MISSING_DIRECT_PROVIDER",
                    requirement.type,
                    f"node '{node.name}' requires type '{requirement.type}' but no direct incoming flow predecessor or entry input provides it",
                    node=node.name,
                    severity="error",
                    details=base_details,
                )
            )
            continue
        if requirement.cardinality in {CARDINALITY_EXACTLY_ONE, CARDINALITY_OPTIONAL_ONE} and len(matches) > 1:
            matched_sources = [_source_name(item, direct) for item in matches]
            if _sources_are_mutually_exclusive(matched_sources, graph):
                continue
            finding = _data_finding(
                "GRAPH.DATA.TYPE_CARDINALITY_AMBIGUOUS",
                requirement.type,
                f"node '{node.name}' requires type '{requirement.type}' with {requirement.cardinality} but {len(matches)} direct sources may provide it",
                node=node.name,
                details={**base_details, "matched_sources": matched_sources},
            )
            if _sources_are_cyclic_alternatives(node.name, matched_sources, graph):
                state.warnings.append(finding)
            elif _direct_sources_are_unconditional(node.name, incoming.get(node.name, ()), graph):
                state.errors.append(_replace_severity(finding, "error"))
            else:
                state.warnings.append(finding)

def _append_unconsumed_provider_warnings(node, graph, compiled, outgoing, condition_keys_by_source, state, *, owner: str) -> None:
    nodes_by_name = {item.name: item for item in graph.nodes}
    downstream = [nodes_by_name[name] for name in outgoing.get(node.name, ()) if name in nodes_by_name]
    is_end = compiled.flow_kinds.get(node.name) == FLOW_KIND_TERMINAL and not outgoing.get(node.name)
    if is_end:
        return
    downstream_required_types = {
        child.name: sorted({requirement.type for requirement in child.requires})
        for child in downstream
    }
    exported_types = {output.type for output in graph.outputs}
    for provider in node.provides:
        if provider.key in condition_keys_by_source.get(node.name, set()):
            continue
        if provider.type in exported_types:
            continue
        if not any(provider.type == requirement.type for child in downstream for requirement in child.requires):
            state.warnings.append(
                _data_finding(
                    "GRAPH.DATA.UNCONSUMED_PROVIDER",
                    provider.key,
                    f"node '{node.name}' provides key '{provider.key}' type '{provider.type}' but no direct downstream flow successor requires that type",
                    node=node.name,
                    details={
                        "owner": owner,
                        "provider_key": provider.key,
                        "provider_type": provider.type,
                        "downstream_nodes": sorted(outgoing.get(node.name, ())),
                        "downstream_required_types": downstream_required_types,
                        "pipeline_output_types": sorted(exported_types),
                    },
                )
            )

def _incoming_sources_providing_type(edges: list[object], nodes_by_name: Mapping[str, object], data_type: str, *, conditional: bool) -> list[str]:
    sources: list[str] = []
    for edge in edges:
        if bool(edge.when) != conditional:
            continue
        source = nodes_by_name.get(edge.source)
        if source is None:
            continue
        if any(provider.type == data_type for provider in getattr(source, "provides", ())):
            sources.append(str(edge.source))
    return sorted(set(sources))

def _is_initial_input_node(node, graph, incoming, nodes_by_name) -> bool:
    if not node.requires:
        return False
    parents = [nodes_by_name[name] for name in incoming.get(node.name, ()) if name in nodes_by_name]
    if not parents:
        return True
    return any(not parent.requires and not parent.provides for parent in parents)

def _direct_sources_are_unconditional(node_name: str, sources: list[str], graph) -> bool:
    relevant = [edge for edge in graph.edges if edge.target == node_name and edge.source in sources]
    return bool(relevant) and all(not edge.when for edge in relevant)

def _sources_are_mutually_exclusive(sources: list[str], graph) -> bool:
    source_set = set(sources)
    if len(source_set) != len(sources) or len(source_set) <= 1 or "pipeline.input" in source_set:
        return False
    by_decision: dict[tuple[str, str], dict[str, set[object]]] = {}
    for source in source_set:
        for edge in graph.edges:
            if edge.target != source or not edge.when:
                continue
            parsed = _parse_when(edge.when)
            if parsed is None:
                continue
            key, operator, value = parsed
            if operator != "==":
                continue
            by_decision.setdefault((edge.source, key), {}).setdefault(source, set()).add(value)
    for by_source in by_decision.values():
        if set(by_source) != source_set:
            continue
        values = {value for source_values in by_source.values() for value in source_values}
        if len(values) >= len(source_set):
            return True
    return False

def _sources_are_cyclic_alternatives(node_name: str, sources: list[str], graph) -> bool:
    source_set = {source for source in sources if source != "pipeline.input"}
    if not source_set:
        return False
    outgoing: dict[str, list[str]] = {}
    for edge in graph.edges:
        outgoing.setdefault(edge.source, []).append(edge.target)
    reachable_from_node = _walk({node_name}, outgoing)
    return any(source in reachable_from_node and node_name in _walk({source}, outgoing) for source in source_set)

def _source_name(provider, direct) -> str:
    if provider is None:
        return "pipeline.input"
    for node in direct:
        if provider in node.provides:
            return node.name
    return str(getattr(provider, "key", provider))

def _provider_source_details(nodes) -> list[dict[str, object]]:
    return [
        {
            "node": node.name,
            "provides": [
                {
                    "key": provider.key,
                    "type": provider.type,
                }
                for provider in node.provides
            ],
        }
        for node in nodes
    ]

def _replace_severity(finding: HealthFinding, severity: str) -> HealthFinding:
    return HealthFinding(
        rule_id=finding.rule_id,
        severity=severity,
        object_type=finding.object_type,
        object_id=finding.object_id,
        source_location=finding.source_location,
        rule_source=finding.rule_source,
        failure_layer=finding.failure_layer,
        message=finding.message,
        suggested_fix_type=finding.suggested_fix_type,
        details=finding.details,
    )

def _walk(starts: set[str], adjacency: dict[str, list[str]]) -> set[str]:
    seen = set(starts)
    queue = list(starts)
    while queue:
        node = queue.pop(0)
        for target in adjacency.get(node, ()):
            if target in seen:
                continue
            seen.add(target)
            queue.append(target)
    return seen


__all__ = ["append_data_contract_warnings"]
