from __future__ import annotations

import importlib
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Mapping

from vibeflow.tooling.project.resource_helpers import _finding, _module_search_path, _resolve_paths
from vibeflow.tooling.project.host_extensions import (
    HostExtensionResource,
    host_extension_resources,
    resolve_host_extension_resources,
)
from vibeflow.core.findings import HealthFinding
from vibeflow.core.flow import STATUS_IMPLEMENTED, STATUS_PLANNED
from vibeflow.targets.python.project.resources import (
    BaseLibInfo,
    BaseLibRegistry,
    BaseLibResource,
    PluginInfo,
    PluginResource,
    PluginResourceRegistry,
    normalize_base_lib_info as _normalize_base_lib_info,
    normalize_plugin_config,
    normalize_plugin_info,
    plugin_status,
)


STATUSES = frozenset({STATUS_IMPLEMENTED, STATUS_PLANNED})


@dataclass(frozen=True)
class ConfigResources:
    global_config: Mapping[str, object] = field(default_factory=dict)
    base_lib_paths: tuple[str, ...] = ()
    base_libs: tuple[BaseLibResource, ...] = ()
    plugins: tuple[PluginResource, ...] = ()
    host_extensions: tuple[HostExtensionResource, ...] = ()

    @property
    def implemented_base_lib_modules(self) -> tuple[str, ...]:
        return tuple(item.module for item in self.base_libs if item.status == STATUS_IMPLEMENTED and item.module)

    @property
    def has_planned(self) -> bool:
        return any(
            item.status == STATUS_PLANNED
            for item in (
                *self.base_libs,
                *self.plugins,
                *self.host_extensions,
            )
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "global_config": dict(self.global_config),
            "base_lib": {
                "paths": list(self.base_lib_paths),
                "modules": [item.to_dict() for item in self.base_libs],
            },
            "plugins": [item.to_dict() for item in self.plugins],
            "host_extensions": [
                item.to_dict() for item in self.host_extensions
            ],
        }

def load_config_resources(
    config: Mapping[str, Any],
    *,
    base_path: Path,
    plugin_registry: object | None = None,
    base_lib_registry: BaseLibRegistry | None = None,
    plugin_resource_registry: PluginResourceRegistry | None = None,
    base_lib_paths: tuple[str, ...] = (),
) -> tuple[ConfigResources, tuple[HealthFinding, ...]]:
    findings: list[HealthFinding] = []
    global_config = _global_config(config, findings)
    base_lib_paths, base_libs = _base_lib_resources(
        config,
        base_path=base_path,
        findings=findings,
        base_lib_registry=base_lib_registry,
        default_paths=base_lib_paths,
    )
    from vibeflow.tooling.application.python.project.plugin_resources import plugin_resources

    plugins = plugin_resources(config, plugin_registry=plugin_registry, plugin_resource_registry=plugin_resource_registry, findings=findings)
    host_extensions = host_extension_resources(config, findings=findings)
    return (
        ConfigResources(
            global_config=global_config,
            base_lib_paths=base_lib_paths,
            base_libs=tuple(base_libs),
            plugins=tuple(plugins),
            host_extensions=tuple(host_extensions),
        ),
        tuple(findings),
    )


def config_base_lib_policy(config: Mapping[str, Any], *, base_path: Path) -> dict[str, tuple[str, ...]]:
    raw = config.get("base_lib")
    if not isinstance(raw, Mapping):
        return {}
    paths = _string_list(raw.get("paths", ()))
    modules = []
    for item in raw.get("modules", ()):
        if isinstance(item, str):
            modules.append(item)
            continue
        if isinstance(item, Mapping):
            status = str(item.get("status", STATUS_IMPLEMENTED)).strip() or STATUS_IMPLEMENTED
            if status != STATUS_IMPLEMENTED:
                continue
            module = str(item.get("module", item.get("name", item.get("id", "")))).strip()
            if module:
                modules.append(module)
    return {
        "allowed_paths": tuple(_resolve_paths(paths, base_path=base_path)),
        "allowed_modules": tuple(dict.fromkeys(modules)),
    }


def _global_config(config: Mapping[str, Any], findings: list[HealthFinding]) -> dict[str, object]:
    raw = config.get("global_config", {})
    if raw in (None, {}):
        return {}
    if not isinstance(raw, Mapping):
        findings.append(_finding("CONFIG.SCHEMA.GLOBAL_CONFIG", "global_config must be an object", "global_config", "config"))
        return {}
    return {str(key): value for key, value in raw.items()}


def _base_lib_resources(
    config: Mapping[str, Any],
    *,
    base_path: Path,
    findings: list[HealthFinding],
    base_lib_registry: BaseLibRegistry | None,
    default_paths: tuple[str, ...],
) -> tuple[tuple[str, ...], list[BaseLibResource]]:
    raw = config.get("base_lib")
    if raw in (None, {}):
        return (), []
    if not isinstance(raw, Mapping):
        findings.append(_finding("CONFIG.SCHEMA.BASE_LIB", "base_lib must be an object", "base_lib", "base_lib"))
        return (), []
    explicit_paths = tuple(_resolve_paths(_string_list(raw.get("paths", ())), base_path=base_path))
    paths = explicit_paths or tuple(str(Path(path).resolve()) for path in default_paths) or (str(base_path.resolve()),)
    modules = raw.get("modules", ())
    if modules in (None, ()):
        return paths, []
    if not isinstance(modules, list):
        findings.append(_finding("CONFIG.SCHEMA.BASE_LIB_MODULES", "base_lib.modules must be a list", "base_lib.modules", "base_lib"))
        return paths, []

    resources: list[BaseLibResource] = []
    for index, item in enumerate(modules):
        prefix = f"base_lib.modules[{index}]"
        planned = isinstance(item, Mapping) and item.get("status") == STATUS_PLANNED
        registered = _registered_base_lib_resource(item, registry=base_lib_registry, prefix=prefix, findings=findings)
        if registered is not None:
            resources.append(replace(registered, status=STATUS_IMPLEMENTED))
            continue
        if not planned:
            if not any(finding.object_id == prefix for finding in findings):
                findings.append(_finding("CONFIG.RESOURCE.REGISTRATION_REMOVED",
                    "base_lib entries must reference IDs contributed by selected SDK plugins; inline module registration was removed",
                    prefix, "base_lib"))
            continue
        spec = _base_lib_spec(item, prefix=prefix, findings=findings)
        if spec is None:
            continue
        module, status, metadata = spec
        _append_missing_resource_metadata_warnings(metadata, prefix, "base_lib", findings)
        info = None
        resources.append(
            BaseLibResource(
                id=str(item.get("id", "")).strip() if isinstance(item, Mapping) else "",
                module=module,
                status=status,
                display_name=metadata["display_name"],
                category=metadata["category"],
                description=metadata["description"],
                version=metadata["version"],
                info=info,
            )
        )
    return paths, resources


def _base_lib_spec(item: object, *, prefix: str, findings: list[HealthFinding]) -> tuple[str, str, dict[str, str]] | None:
    if isinstance(item, str):
        module = item.strip()
        if not module:
            findings.append(_finding("CONFIG.SCHEMA.BASE_LIB_MODULE", f"{prefix} must be a non-empty module string", prefix, "base_lib"))
            return None
        return module, STATUS_IMPLEMENTED, _empty_resource_metadata()
    if not isinstance(item, Mapping):
        findings.append(_finding("CONFIG.SCHEMA.BASE_LIB_MODULE", f"{prefix} must be a string or object", prefix, "base_lib"))
        return None
    module = str(item.get("module", item.get("name", ""))).strip()
    if not module:
        findings.append(_finding("CONFIG.SCHEMA.BASE_LIB_MODULE", f"{prefix}.module or name must be a non-empty string", f"{prefix}.module", "base_lib"))
        return None
    status = str(item.get("status", STATUS_IMPLEMENTED)).strip() or STATUS_IMPLEMENTED
    if status not in STATUSES:
        findings.append(_finding("CONFIG.SCHEMA.RESOURCE_STATUS", f"{prefix}.status must be implemented or planned", f"{prefix}.status", "base_lib"))
        status = STATUS_IMPLEMENTED
    return module, status, _resource_metadata(item)


def _registered_base_lib_resource(
    item: object,
    *,
    registry: BaseLibRegistry | None,
    prefix: str,
    findings: list[HealthFinding],
) -> BaseLibResource | None:
    if registry is None:
        return None
    resource_id = ""
    if isinstance(item, str):
        resource_id = item.strip()
    elif isinstance(item, Mapping) and "id" in item and "module" not in item and "name" not in item:
        resource_id = str(item.get("id", "")).strip()
    if not resource_id:
        return None
    registered = registry.get(resource_id)
    if registered is None:
        findings.append(_finding("CONFIG.RESOURCE.UNKNOWN_BASE_LIB", f"unknown base_lib resource id: {resource_id}", prefix, "base_lib"))
        return None
    return _overlay_base_lib_metadata(registered, item)


def _overlay_base_lib_metadata(resource: BaseLibResource, item: object) -> BaseLibResource:
    if not isinstance(item, Mapping):
        return resource
    metadata = _resource_metadata(item)
    return replace(
        resource,
        display_name=metadata["display_name"] or resource.display_name,
        category=metadata["category"] or resource.category,
        description=metadata["description"] or resource.description,
        version=metadata["version"] or resource.version,
    )


def _empty_resource_metadata() -> dict[str, str]:
    return {"display_name": "", "category": "", "description": "", "version": ""}


def _resource_metadata(spec: Mapping[str, object]) -> dict[str, str]:
    return {
        "display_name": str(spec.get("display_name", "")).strip(),
        "category": str(spec.get("category", "")).strip(),
        "description": str(spec.get("description", "")).strip(),
        "version": str(spec.get("version", "")).strip(),
    }


def _append_missing_resource_metadata_warnings(
    metadata: Mapping[str, str],
    object_id: str,
    resource_kind: str,
    findings: list[HealthFinding],
) -> None:
    label = "plugin" if resource_kind == "plugin" else "base_lib"
    for field, rule_id in (
        ("display_name", f"CONFIG.SMELL.MISSING_{label.upper()}_DISPLAY_NAME"),
        ("description", f"CONFIG.SMELL.MISSING_{label.upper()}_DESCRIPTION"),
    ):
        if str(metadata.get(field, "")).strip():
            continue
        findings.append(
            HealthFinding(
                rule_id=rule_id,
                severity="warning",
                object_type=label,
                object_id=object_id,
                failure_layer=resource_kind,
                message=f"config {label} declaration '{object_id}' should declare {field} for readable SVG diagrams",
                suggested_fix_type="fix_config",
                details={"field": field, "resource_kind": label},
            )
        )


def _string_list(value: object) -> tuple[str, ...]:
    if not isinstance(value, list):
        return ()
    return tuple(str(item).strip() for item in value if isinstance(item, str) and item.strip())


__all__ = [
    "BaseLibInfo",
    "BaseLibRegistry",
    "BaseLibResource",
    "ConfigResources",
    "HostExtensionResource",
    "PluginInfo",
    "PluginResource",
    "PluginResourceRegistry",
    "config_base_lib_policy",
    "host_extension_resources",
    "load_config_resources",
    "normalize_plugin_config",
    "normalize_plugin_info",
    "plugin_status",
    "resolve_host_extension_resources",
]
