from __future__ import annotations

from dataclasses import replace
from typing import Any, Mapping

from vibeflow.tooling.project.resource_helpers import _finding
from vibeflow.tooling.application.python.project.resources import (
    PluginResource,
    PluginResourceRegistry,
    _append_missing_resource_metadata_warnings,
    _resource_metadata,
    normalize_plugin_config,
)
from vibeflow.core.flow import STATUS_IMPLEMENTED, STATUS_PLANNED
from vibeflow.core.findings import HealthFinding


STATUSES = frozenset({STATUS_IMPLEMENTED, STATUS_PLANNED})


def plugin_resources(config: Mapping[str, Any], *, plugin_registry: object | None, plugin_resource_registry: PluginResourceRegistry | None, findings: list[HealthFinding]) -> list[PluginResource]:
    raw = config.get("plugins", [])
    if raw in (None, []):
        return []
    if not isinstance(raw, list):
        findings.append(_finding("CONFIG.SCHEMA.PLUGINS_LIST", "plugins must be a list", "plugins", "plugin"))
        return []
    registry_resources = plugin_registry.resource_map() if plugin_registry is not None and callable(getattr(plugin_registry, "resource_map", None)) else {}
    resources: list[PluginResource] = []
    for index, item in enumerate(raw):
        spec = _plugin_spec(item)
        if spec is None or spec.get("enabled", True) is False:
            continue
        prefix = f"plugins[{index}]"
        registered_resource = _registered_plugin_resource(spec, item, registry=plugin_resource_registry, prefix=prefix, findings=findings)
        if registered_resource is not None:
            resources.append(replace(registered_resource, config_keys=_plugin_config_keys(spec, prefix, findings) or registered_resource.config_keys,
                config=normalize_plugin_config(spec)))
            continue
        if spec.get("status") == STATUS_PLANNED:
            _append_missing_resource_metadata_warnings(_resource_metadata(spec), prefix, "plugin", findings)
            resources.append(_inline_plugin_resource(spec, module="", class_name="", plugin_type=str(spec.get("type", "runtime")), config_keys=_plugin_config_keys(spec, prefix, findings), targets=tuple(spec.get("targets", ())), priority=spec.get("priority",100)))
        else:
            findings.append(_finding("PLUGIN.SELECTION.MIGRATION", "select a fixed SDK plugin source; inline lifecycle registration was removed", prefix, "plugin"))
    return resources


def _plugin_spec(item: object) -> dict[str, object] | None:
    if isinstance(item, str):
        return {"module": item}
    if isinstance(item, Mapping):
        return {str(key): value for key, value in item.items()}
    return None


def _plugin_config_keys(spec: Mapping[str, object], prefix: str, findings: list[HealthFinding]) -> tuple[str, ...]:
    try:
        return tuple(sorted(normalize_plugin_config(spec).keys()))
    except ValueError as exc:
        findings.append(_finding("CONFIG.SCHEMA.PLUGIN_CONFIG", str(exc), f"{prefix}.config", "plugin"))
        return ()


def _registered_plugin_resource(spec: Mapping[str, object], item: object, *, registry: PluginResourceRegistry | None, prefix: str, findings: list[HealthFinding]) -> PluginResource | None:
    if registry is None or spec.get("status") == STATUS_PLANNED:
        return None
    resource_id = item.strip() if isinstance(item, str) else str(spec.get("id", "")).strip() if "id" in spec and "module" not in spec and "path" not in spec else ""
    if not resource_id:
        return None
    registered = registry.get(resource_id)
    if registered is None:
        findings.append(_finding("CONFIG.RESOURCE.UNKNOWN_PLUGIN", f"unknown plugin resource id: {resource_id}", prefix, "plugin"))
        return None
    return _overlay_plugin_metadata(registered, spec)


def _overlay_plugin_metadata(resource: PluginResource, spec: Mapping[str, object]) -> PluginResource:
    metadata = _resource_metadata(spec)
    status = str(spec.get("status", resource.status)).strip() or resource.status
    return replace(
        resource,
        name=str(spec.get("name", resource.name)).strip() or resource.name,
        plugin_type=str(spec.get("type", resource.plugin_type)).strip() or resource.plugin_type,
        status=status if status in STATUSES else resource.status,
        class_name=str(spec.get("class", spec.get("factory", resource.class_name))).strip() or resource.class_name,
        display_name=metadata["display_name"] or resource.display_name,
        category=metadata["category"] or resource.category,
        description=metadata["description"] or resource.description,
        version=metadata["version"] or resource.version,
    )


def _inline_plugin_resource(spec: Mapping[str, object], *, module: str, class_name: str, plugin_type: str, config_keys: tuple[str, ...], targets=(), priority=100) -> PluginResource:
    metadata = _resource_metadata(spec)
    status = str(spec.get("status", STATUS_IMPLEMENTED)).strip() or STATUS_IMPLEMENTED
    return PluginResource(
        id=str(spec.get("id", "")).strip(),
        name=str(spec.get("name", "")).strip() or str(spec.get("id", "")).strip() or module or class_name,
        plugin_type=plugin_type,
        status=status if status in STATUSES else STATUS_IMPLEMENTED,
        module=module,
        class_name=class_name,
        display_name=metadata["display_name"],
        category=metadata["category"],
        description=metadata["description"],
        version=metadata["version"],
        config_keys=config_keys,
        rulesets=spec.get("rulesets", ()), targets=targets, priority=priority, config=normalize_plugin_config(spec),
    )


__all__ = ["plugin_resources"]
