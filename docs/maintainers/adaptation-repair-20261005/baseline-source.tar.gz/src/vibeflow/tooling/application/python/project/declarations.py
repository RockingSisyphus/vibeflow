"""Read canonical declarations, then bind only selected Python symbols."""

from __future__ import annotations

import importlib.util
import inspect
import sys
from contextlib import contextmanager
from pathlib import Path

from vibeflow.core.descriptors.models import NodeDescriptor
from vibeflow.core.flow import GraphConfig, IO_NODE_TYPE, LOOP_NODE_TYPES, STATUS_PLANNED
from vibeflow.targets.python.project.registry import NodeRegistry, NodeRegistryError
from vibeflow.targets.python.quality.source_context import PythonSourceFile, PythonSourceNode, PythonSourceCall, build_python_source_context
from vibeflow.tooling.application.python.project.source_preflight import collect_python_source_facts, resolve_local_module_path
from vibeflow.tooling.project.descriptor_loader import load_workflow_plugins


def declared_python_registry(workspace, config_path=None, *, loaded_plugins=None) -> NodeRegistry:
    """Bind only resources contributed by this workflow's selected plugins."""
    from vibeflow.core.descriptors.contributions import builtin_contributions, compose_contributions
    from vibeflow.tooling.project.descriptor_loader import LoadedPlugins
    loaded = loaded_plugins or (load_workflow_plugins(workspace, config_path) if config_path else
        LoadedPlugins(compose_contributions((builtin_contributions(),)), {}, (), ()))
    registry = NodeRegistry()
    catalog = loaded.catalogs
    source_roots = tuple(root.path for root in workspace.roots if root.project_target == "python")
    locations = {}
    bindings = {(kind, key): value for (_, kind, key), value in loaded.bindings.items()}
    resource_roots = {}
    for group in ("nodes", "rules", "base_libs", "plugins"):
        for descriptor in getattr(catalog, group):
            origin = catalog.origins.get((group, descriptor.id))
            if origin is None or origin.plugin_id == "vibeflow.core":
                continue
            record = next(item for item in loaded.records if item.get("id") == origin.plugin_id)
            resource_roots[(group, descriptor.id)] = workspace.root_by_id(record["root"])
    for descriptor in catalog.nodes:
        implementations = tuple(item for item in descriptor.implementations if item.language == "python")
        if not implementations:
            continue
        if len(implementations) != 1:
            raise NodeRegistryError(f"node '{descriptor.type_key}' must select one Python implementation")
        root = resource_roots[("nodes", descriptor.id)]
        source = implementations[0].source
        path = _implementation_path(source.kind, source.ref, root.path, source_roots)
        symbol = str(source.export or "").strip()
        if not symbol:
            raise NodeRegistryError(f"node '{descriptor.type_key}' Python source must name its exported class")
        analysis_root = root.path if path.is_relative_to(root.path) else path.parent
        locations[descriptor.type_key] = (path, symbol, root.id, analysis_root)
        registry.register(descriptor, loader=lambda key=descriptor.type_key: _bind_node(registry, key, source_roots),
                          source=catalog.nodes.source_for(descriptor.type_key), source_line=catalog.origins[("nodes",descriptor.id)].line)
    registry.source_locations = locations
    registry.resource_roots = resource_roots
    registry.direct_bindings = bindings
    registry.loaded_plugins = loaded
    registry.source_root_ids = {root.path:root.id for root in workspace.roots}
    registry.source_roots = source_roots
    registry.source_context_loader = lambda key: collect_node_source_context(registry, (key,))
    registry.rule_handler_loader = lambda plan: _load_rule_handlers(registry, plan, workspace)
    registry.rule_catalogs = (catalog,)
    from vibeflow.targets.python.quality.rule_adapter import selected_effect_scope
    registry.rule_policy_resolver = lambda key: selected_effect_scope(registry, key)
    return registry


def workflow_node_types(graph: GraphConfig) -> tuple[str, ...]:
    """Follow actual Nodeset and Loop calls, not unused registered definitions."""
    selected: set[str] = set()
    visited: set[str] = set()

    def walk(current: GraphConfig, inherited: dict[str, object]) -> None:
        definitions = {**inherited, **current.nodesets}
        for node in current.nodes:
            if node.status == STATUS_PLANNED:
                continue
            nested = node.loop.body if node.type_used in LOOP_NODE_TYPES else node.type_used
            if nested in definitions:
                if nested not in visited:
                    visited.add(nested)
                    walk(definitions[nested].graph, definitions)
            elif node.type_used not in LOOP_NODE_TYPES and node.type_used != IO_NODE_TYPE:
                selected.add(node.type_used)

    walk(graph, {})
    return tuple(sorted(selected))


def collect_node_source_context(registry: NodeRegistry, type_keys: tuple[str, ...], *, calls=None):
    from vibeflow.targets.python.project.source_membership import resource_paths
    from vibeflow.targets.python.project.check_session import current_python_check
    session = current_python_check(registry)
    parsed = session.parsed_sources if session is not None else None
    parse_cache = session.parse_cache if session is not None else None

    nodes: list[PythonSourceNode] = []
    files: dict[str, PythonSourceFile] = {}
    source_facts = {}
    for key in type_keys:
        if key not in registry.available():
            continue
        descriptor = registry.descriptor(key)
        try:
            path, symbol, root_id, root = getattr(registry, "source_locations", {})[key]
        except KeyError:
            implementation = getattr(registry, "_registry", {}).get(key)
            filename = inspect.getsourcefile(implementation) if implementation is not None else None
            if filename is None:
                raise NodeRegistryError(f"node '{key}' has no available declared source location or bound source")
            path = Path(filename).resolve()
            symbol = implementation.__qualname__.replace(".<locals>", "")
            root_id = "bound"
            root = path.parent
            for _ in implementation.__module__.split(".")[:-1]:
                root = root.parent
        nodes.append(PythonSourceNode(descriptor, str(path), symbol, root_id, tuple((calls or {}).get(key, ()))))
        entries = (path, *(file for role,file,_ in resource_paths(descriptor, root, getattr(registry,"source_roots",(root,))) if role == "support"))
        for fact in (fact for entry in entries for fact in collect_python_source_facts(entry, project_root=root, source_roots=getattr(registry, "source_roots", (root,)), _facts=source_facts, _parsed=parsed, _parse_cache=parse_cache)):
            if fact.load_error:
                raise NodeRegistryError(fact.load_error)
            owner = Path(fact.root_path) if fact.root_path else next((item for item in getattr(registry, "source_roots", (root,)) if Path(fact.path).is_relative_to(item)), Path(fact.path).parent)
            relative = Path(fact.path).relative_to(owner)
            module = ".".join(relative.with_suffix("").parts)
            if module.endswith(".__init__"):
                module = module[:-9]
            files[fact.path] = PythonSourceFile(fact.path, module, fact.source, getattr(registry, "source_root_ids", {}).get(owner, root_id), fact._tree, fact.parse_error,fact.parse_line,fact.parse_column)
    # Inspect explicitly registered parts of libraries already in this scope.
    for catalog in getattr(registry,"rule_catalogs", ()) or ():
        for library in getattr(catalog, "base_libs", ()):
            root_object = getattr(registry,"resource_roots",{}).get(("base_libs",library.id))
            if root_object is None:
                continue
            members = tuple(resource_paths(library,root_object.path,registry.source_roots))
            if not any(str(path) in files for role,path,_ in members if role == "entry"):
                continue
            for role,path,_ in members:
                if role != "support":
                    continue
                for fact in collect_python_source_facts(path,project_root=root_object.path,source_roots=registry.source_roots,_facts=source_facts,_parsed=parsed,_parse_cache=parse_cache):
                    if fact.load_error:
                        raise NodeRegistryError(fact.load_error)
                    owner = Path(fact.root_path) if fact.root_path else root_object.path
                    module = ".".join(Path(fact.path).relative_to(owner).with_suffix("").parts).removesuffix(".__init__")
                    files[fact.path] = PythonSourceFile(fact.path,module,fact.source,root_object.id,fact._tree,
                        fact.parse_error,fact.parse_line,fact.parse_column)
    context = build_python_source_context(nodes, files.values())
    loaded_paths = {str(Path(filename).resolve()) for module in tuple(sys.modules.values())
                    if isinstance(filename := getattr(module, "__file__", None), str)}
    from types import MappingProxyType
    registry.source_load_states = MappingProxyType({path: "loaded" if path in loaded_paths else "not_loaded" for path in files})
    registry.source_context_snapshot = context
    from vibeflow.targets.python.project.check_session import current_python_check
    session = current_python_check(registry)
    if session is not None:
        session.sources = context
    return context


def collect_workflow_source_context(registry, graph):
    calls = {}
    call_facts = []
    def collect(current, inherited, prefix=(), owner="pipeline", active=()):
        definitions = {**inherited,**current.nodesets}
        for spec in current.nodes:
            path = (*prefix,spec.id)
            call_id = "/".join(path)
            calls.setdefault(spec.type_used, []).append((owner, call_id))
            call_facts.append(PythonSourceCall(owner,call_id,spec.type_used,spec.params,current.source_path,spec.id,path))
            key = spec.loop.body if spec.type_used in LOOP_NODE_TYPES else spec.type_used
            if spec.status != STATUS_PLANNED and key in definitions and key not in active:
                collect(definitions[key].graph,definitions,path,"nodeset:"+key,(*active,key))
    collect(graph,{})
    from dataclasses import replace
    context = collect_node_source_context(registry, workflow_node_types(graph), calls=calls)
    context = replace(context,calls=tuple(call_facts))
    registry.source_context_snapshot = context
    from vibeflow.targets.python.project.check_session import current_python_check
    session = current_python_check(registry)
    if session is not None:
        session.sources = context
    return context


def _load_rule_handlers(registry, plan, workspace):
    handlers = {}
    roots = tuple(root for root in workspace.roots if root.project_target == "python")
    for invocation in plan.invocations:
        rule = invocation.rule
        implementations = tuple(item for item in rule.implementations if item.language == "python")
        if not implementations:
            continue
        if len(implementations) != 1:
            raise NodeRegistryError(f"rule '{rule.id}' must select one Python implementation")
        source = implementations[0].source
        direct = getattr(registry, "direct_bindings", {}).get(("rule", rule.id))
        if direct is not None:
            handlers[rule.id] = direct
            continue
        owner = getattr(registry, "resource_roots", {}).get(("rules", rule.id))
        if owner is None:
            raise NodeRegistryError(f"rule '{rule.id}' has no contributing plugin")
        manifest = registry.rule_catalogs[0].rules.source_for(rule.id)
        symbol = source.export or rule.handler
        if not symbol:
            raise NodeRegistryError(f"rule '{rule.id}' must name its exported handler")
        path = None
        try:
            path = _implementation_path(source.kind, source.ref, owner.path, registry.source_roots)
            handlers[rule.id] = _load_rule_handler(path, symbol, owner, registry)
        except Exception as exc:
            implementation = {"kind":source.kind,"ref":source.ref,"export":symbol}
            if path is not None or source.kind == "file":
                implementation["path"] = str(path or (owner.path / source.ref).resolve())
            raise PythonRuleBindingError(rule.id, manifest, implementation, exc,
                registry.rule_catalogs[0].rules.location_for(rule.id)) from exc
    return handlers


def _load_rule_handler(path, symbol, owner, registry):
    with _source_paths((owner.path,*registry.source_roots)):
        name = f"_vibeflow_rule_{abs(hash(str(path)))}"
        module = sys.modules.get(name)
        if module is None:
            spec = importlib.util.spec_from_file_location(name,path)
            if spec is None or spec.loader is None:
                raise NodeRegistryError(f"cannot load rule source: {path}")
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            try:
                spec.loader.exec_module(module)
            except BaseException:
                sys.modules.pop(name,None)
                raise
        value = module
        for part in symbol.split("."):
            value = getattr(value,part)
    if not callable(value):
        raise NodeRegistryError("declared Rule handler must be callable")
    return value


class PythonRuleBindingError(NodeRegistryError):
    """A declaration-backed Rule implementation could not be loaded."""
    def __init__(self, rule_id, manifest, implementation, cause, location=None):
        from vibeflow.core.findings import HealthFinding
        symbol = implementation["export"]
        message = f"rule '{rule_id}' handler '{symbol}' could not be bound: {cause}"
        self.findings = (HealthFinding(rule_id="RULE.IMPLEMENTATION.LOAD", severity="error",
            object_type="rule", object_id=rule_id, definition_id=rule_id, failure_layer="rule",
            message=message, source_location=location or {"path":str(manifest)},
            details={"implementation":implementation}),)
        super().__init__(message)


def _implementation_path(kind: str, reference: str, root: Path, roots: tuple[Path, ...]) -> Path:
    if kind == "file":
        path = (root / reference).resolve()

    elif kind in {"module", "package"}:
        path = next((value for candidate in (root, *roots) if (value := resolve_local_module_path(reference, project_root=candidate)) is not None), None)
        if path is None:
            import importlib.util
            with _source_paths((root, *roots)):
                spec = importlib.util.find_spec(reference)
            if spec is None or not spec.origin:
                raise NodeRegistryError(f"cannot resolve declared Python module '{reference}'")
            path = Path(spec.origin).resolve()
    else:
        raise NodeRegistryError(f"Python implementation source kind '{kind}' is not supported")
    if not path.is_file():
        raise NodeRegistryError(f"declared Python source does not exist: {path}")
    return path


def _bind_node(registry: NodeRegistry, key: str, roots: tuple[Path, ...]) -> type:
    from vibeflow.targets.python.quality.rule_adapter import review_python_node_binding

    snapshot = getattr(registry, "source_context_snapshot", None)
    selected = tuple(node for node in snapshot.nodes if node.type_key == key) if snapshot is not None else ()
    # The checked workflow already supplied its actual calls and ownership.
    # Limit this binding check to its Node without replacing the full snapshot.
    context = snapshot if selected else collect_node_source_context(registry, (key,))
    results = review_python_node_binding(registry, context, key, **registry.rule_defaults())
    findings = tuple(item for item in results.findings if item.severity == "error")
    if findings:
        raise PythonSourceRuleError(findings)
    direct = getattr(registry, "direct_bindings", {}).get(("node", key))
    if direct is not None:
        return direct
    path, symbol, _, root = registry.source_locations[key]
    relative = path.relative_to(root).with_suffix("")
    module_name = ".".join(relative.parts)
    try:
        with _source_paths((root, *roots)):
            module = sys.modules.get(module_name)
            if module is None or Path(getattr(module, "__file__", "")).resolve() != path:
                specification = importlib.util.spec_from_file_location(module_name, path)
                if specification is None or specification.loader is None:
                    raise NodeRegistryError(f"cannot load declared Python source: {path}")
                module = importlib.util.module_from_spec(specification)
                sys.modules[module_name] = module
                try:
                    specification.loader.exec_module(module)
                except BaseException:
                    sys.modules.pop(module_name, None)
                    raise
            implementation = module
            for member in symbol.split("."):
                implementation = getattr(implementation, member)
        if not isinstance(implementation, type):
            raise NodeRegistryError(f"declared Python symbol '{symbol}' must be a class")
    except Exception as exc:
        from vibeflow.core.findings import HealthFinding
        error = NodeRegistryError(f"node '{key}' implementation '{symbol}' could not be bound: {exc}")
        error.findings = (HealthFinding(rule_id="NODE.IMPLEMENTATION.BINDING",severity="error",
            object_type="node",object_id=key,failure_layer="implementation",message=str(error),
            source_location={"path":registry.source_info(key).path, **({"line":registry.source_info(key).line} if registry.source_info(key).line else {})},
            details={"implementation":{"path":str(path),"export":symbol}}),)
        raise error from exc
    return implementation


class PythonSourceRuleError(NodeRegistryError):
    def __init__(self, findings):
        self.findings = tuple(findings)
        super().__init__("; ".join(item.message for item in self.findings))


@contextmanager
def _source_paths(roots: tuple[Path, ...]):
    additions = [str(root) for root in dict.fromkeys(roots) if str(root) not in sys.path]
    sys.path[:0] = additions
    try:
        yield
    finally:
        for value in additions:
            sys.path.remove(value)


__all__ = ["declared_python_registry", "workflow_node_types", "collect_node_source_context", "collect_workflow_source_context", "PythonSourceRuleError"]
